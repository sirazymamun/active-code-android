// Turns the freshly generated Capacitor Android project into the tv2u native-player app.
// Safe to run more than once. Runs automatically after `npx cap sync` (see package.json) and from the GitHub workflow.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const androidDir = path.join(root, "android");
const log = (m) => console.log("[tv2u] " + m);
const warn = (m) => console.log("[tv2u] WARNING: " + m);

if (!fs.existsSync(androidDir)) {
  log("android/ folder not found yet - nothing to patch.");
  process.exit(0);
}

/* Android 7 minimum; compile/target API 36. No maxSdkVersion restriction. */
const variablesPath = path.join(androidDir, "variables.gradle");
if (fs.existsSync(variablesPath)) {
  let variables = fs.readFileSync(variablesPath, "utf8");
  variables = variables.replace(/(minSdkVersion\s*=\s*)\d+/, "$1" + "24");
  variables = variables.replace(/(compileSdkVersion\s*=\s*)\d+/, "$1" + "36");
  variables = variables.replace(/(targetSdkVersion\s*=\s*)\d+/, "$1" + "36");
  fs.writeFileSync(variablesPath, variables);
  log("configured minSdk 24, compileSdk 36 and targetSdk 36");
} else {
  warn("variables.gradle not found; SDK versions will be checked in app/build.gradle");
}

const cfg = JSON.parse(fs.readFileSync(path.join(root, "capacitor.config.json"), "utf8"));
const pkg = cfg.appId;

/* Keep the Android Gradle Plugin new enough to compile against API 36. */
const rootGradlePath = path.join(androidDir, "build.gradle");
if (fs.existsSync(rootGradlePath)) {
  let rootGradle = fs.readFileSync(rootGradlePath, "utf8");
  rootGradle = rootGradle.replace(/com\.android\.tools\.build:gradle:[0-9.]+/, "com.android.tools.build:gradle:8.10.1");
  rootGradle = rootGradle.replace(/com\.android\.application['\"]\s+version\s+['\"][0-9.]+['\"]/, "com.android.application' version '8.10.1'");
  fs.writeFileSync(rootGradlePath, rootGradle);
  log("checked Android Gradle Plugin for API 36 compatibility");
}

/* 1. Java sources (MainActivity + native player plugin) */
const javaDir = path.join(androidDir, "app", "src", "main", "java", ...pkg.split("."));
fs.mkdirSync(javaDir, { recursive: true });
for (const f of ["MainActivity.java", "NativePlayerPlugin.java", "HttpFetch.java", "StreamFormatDetector.java", "BigStore.java", "XtreamImport.java", "VlcFallback.java", "FrameHold.java", "RecordingSaver.java", "TrialIdentityPlugin.java"]) {
  const tpl = fs.readFileSync(path.join(here, "java", f + ".tpl"), "utf8").replaceAll("__PACKAGE__", pkg);
  fs.writeFileSync(path.join(javaDir, f), tpl);
  log("wrote " + path.relative(root, path.join(javaDir, f)));
}

/* 2. Media3 (ExoPlayer) dependencies */
const gradlePath = path.join(androidDir, "app", "build.gradle");
let gradle = fs.readFileSync(gradlePath, "utf8");
const appVersion = fs.readFileSync(path.join(root,"apk-version.txt"),"utf8").trim();
if(!/^\d{1,3}\.\d{1,2}(?:\.\d{1,3})?$/.test(appVersion)) throw new Error("apk-version.txt must be MAJOR.MINOR.PATCH, e.g. 2.1.3");
const [major,minor,patch=0]=appVersion.split('.').map(Number);
const versionCode=major*1000000+minor*1000+patch;
if(!Number.isSafeInteger(versionCode) || versionCode<1 || versionCode>2100000000) throw new Error("Version code must be positive");
if(!/versionCode\s+\d+/.test(gradle) || !/versionName\s+["'][^"']+["']/.test(gradle)) throw new Error("Missing Android version fields");
gradle=gradle.replace(/versionCode\s+\d+/,`versionCode ${versionCode}`).replace(/versionName\s+["'][^"']+["']/,`versionName "active-code-v${appVersion}"`);
fs.writeFileSync(gradlePath,gradle);
const wrapper=path.join(androidDir,"gradle/wrapper/gradle-wrapper.properties");
if(fs.existsSync(wrapper)) fs.writeFileSync(wrapper,fs.readFileSync(wrapper,"utf8").replace(/gradle-[0-9.]+-(all|bin)\.zip/,"gradle-8.11.1-bin.zip"));
const MARK = "// tv2u-native-player";
if (!gradle.includes(MARK)) {
  gradle += `
${MARK}
dependencies {
    implementation "androidx.media3:media3-exoplayer:1.11.1"
    implementation "androidx.media3:media3-exoplayer-hls:1.11.1"
    implementation "androidx.media3:media3-exoplayer-dash:1.11.1"
    implementation "androidx.media3:media3-exoplayer-rtsp:1.11.1"
    implementation "androidx.media3:media3-exoplayer-smoothstreaming:1.11.1"
    implementation "androidx.media3:media3-datasource-okhttp:1.11.1"
    implementation "androidx.media3:media3-ui:1.11.1"
    implementation "com.squareup.okhttp3:okhttp:4.12.0"
}
`;
  fs.writeFileSync(gradlePath, gradle);
  log("added Media3 dependencies to app/build.gradle");
} else {
  log("Media3 dependencies already present");
}

/* 2b. VLC engine (second player, used only when ExoPlayer cannot play a channel). Deliver ARM APKs; x86_64 is opt-in for internal emulator testing only. */
gradle = fs.readFileSync(gradlePath, "utf8");
if (!gradle.includes("libvlc-all")) {
  gradle += `
// tv2u-vlc-fallback
dependencies {
    implementation "org.videolan.android:libvlc-all:3.7.7"
}
android {
    defaultConfig {
        ndk { abiFilters "arm64-v8a", "armeabi-v7a" }
    }
}
`;
  fs.writeFileSync(gradlePath, gradle);
  log("added the VLC fallback engine");
} else {
  log("VLC fallback engine already present");
}

// Also upgrade an already-generated Android project, not only a fresh one.
let upgraded=fs.readFileSync(gradlePath,'utf8');
upgraded=upgraded.replace(/androidx\.media3:(media3-[\w-]+):[^"']+/g,'androidx.media3:$1:1.11.1');
upgraded=upgraded.replace(/org\.videolan\.android:libvlc-all:[^"']+/g,'org.videolan.android:libvlc-all:3.7.7');
upgraded=upgraded.replace(/abiFilters\s+["'][^\n}]+/g,'abiFilters "arm64-v8a", "armeabi-v7a" ');
fs.writeFileSync(gradlePath,upgraded);

// One sideload APK contains both ARM ABIs. x86_64 is an opt-in CI-only build.
if (!upgraded.includes('// active-code-arm-apk')) fs.appendFileSync(gradlePath, `
// active-code-arm-apk
def activeCodeAbis = project.hasProperty("activeCodeEmulator") ? ["x86_64"] : ["arm64-v8a", "armeabi-v7a"]
android {
    defaultConfig { ndk { abiFilters.clear(); abiFilters.addAll(activeCodeAbis) } }
}
`);

/* 3. AndroidManifest: http streams, Android TV launcher, landscape */
const manifestPath = path.join(androidDir, "app", "src", "main", "AndroidManifest.xml");
let m = fs.readFileSync(manifestPath, "utf8");

if (!/android:largeHeap=/.test(m)) {
  m = m.replace(/<application\b/, '<application android:largeHeap="true"');
}
if (!/android:usesCleartextTraffic=/.test(m)) {
  m = m.replace(/<application\b/, '<application android:usesCleartextTraffic="true"');
  log("allowed http (cleartext) traffic");
}
if (!/android:banner=/.test(m)) {
  m = m.replace(/<application\b/, '<application android:banner="@drawable/tv_banner"');
  log("added TV banner");
}
if (!m.includes("android.software.leanback")) {
  m = m.replace(
    /<application\b/,
    '<uses-feature android:name="android.software.leanback" android:required="false" />\n' +
      '    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />\n' +
      '    <application'
  );
  log("declared Android TV (leanback) support");
}
if (!m.includes("LEANBACK_LAUNCHER")) {
  const re = /<category\s+android:name="android\.intent\.category\.LAUNCHER"\s*\/>/;
  if (re.test(m)) {
    m = m.replace(re, (s) => s + '\n                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />');
    log("added Android TV launcher entry");
  } else {
    warn("LAUNCHER category not found in the manifest; the app may not appear on Android TV.");
  }
}
if (!/android:screenOrientation=/.test(m)) {
  m = m.replace(/<activity\b/, '<activity android:screenOrientation="sensorLandscape"');
  log("locked to landscape");
} else {
  m = m.replace(/android:screenOrientation="[^"]*"/, 'android:screenOrientation="sensorLandscape"');
}
// Preserve the existing TV-style Back-key behavior while using the legacy callback on API 33+.
if (!/android:enableOnBackInvokedCallback=/.test(m)) {
  m = m.replace(/<application\b/, '<application android:enableOnBackInvokedCallback="false"');
}
fs.writeFileSync(manifestPath, m);

/* 4. Icons + TV banner */
const resSrc = path.join(here, "res");
const resDst = path.join(androidDir, "app", "src", "main", "res");
if (fs.existsSync(resSrc)) {
  fs.cpSync(resSrc, resDst, { recursive: true, force: true });
  log("copied icons and TV banner");
}

log("done");

// Optional persistent signing key. Required by the release workflow.
let signedGradle=fs.readFileSync(gradlePath,"utf8").replaceAll("TV2U_KEYSTORE_PATH","ACTIVE_CODE_KEYSTORE_PATH").replaceAll("TV2U_STORE_PASSWORD","ACTIVE_CODE_STORE_PASSWORD").replaceAll("TV2U_KEY_ALIAS","ACTIVE_CODE_KEY_ALIAS").replaceAll("TV2U_KEY_PASSWORD","ACTIVE_CODE_KEY_PASSWORD");
fs.writeFileSync(gradlePath,signedGradle);
if(!signedGradle.includes('// tv2u-release-signing')) {
 signedGradle+=`
// tv2u-release-signing
if (System.getenv("ACTIVE_CODE_KEYSTORE_PATH")) {
    android {
        signingConfigs {
            tv2uRelease {
                storeFile file(System.getenv("ACTIVE_CODE_KEYSTORE_PATH"))
                storePassword System.getenv("ACTIVE_CODE_STORE_PASSWORD")
                keyAlias System.getenv("ACTIVE_CODE_KEY_ALIAS")
                keyPassword System.getenv("ACTIVE_CODE_KEY_PASSWORD")
            }
        }
        buildTypes { release { signingConfig signingConfigs.tv2uRelease; debuggable false } }
    }
}
`;
 fs.writeFileSync(gradlePath,signedGradle);
}

// The same generated app is exercised on Android 7 and Android 17 in CI.
const testDir=path.join(androidDir,'app/src/androidTest/java',...pkg.split('.'));
fs.mkdirSync(testDir,{recursive:true});
fs.writeFileSync(path.join(testDir,'AndroidCompatTest.java'),fs.readFileSync(path.join(here,'test/AndroidCompatTest.java.tpl'),'utf8').replaceAll('__PACKAGE__',pkg));
if(!fs.readFileSync(gradlePath,'utf8').includes('// active-code-compat-tests'))fs.appendFileSync(gradlePath,`
// active-code-compat-tests
dependencies {
 androidTestImplementation "androidx.test:core:1.6.1"
 androidTestImplementation "androidx.test:runner:1.6.2"
}
`);

// Capacitor's sample test asserts a template package name; it is not an app test.
const templateTest=path.join(androidDir,'app/src/androidTest/java/com/getcapacitor/myapp/ExampleInstrumentedTest.java');
if(fs.existsSync(templateTest))fs.unlinkSync(templateTest);
