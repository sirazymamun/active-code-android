package __PACKAGE__;
import android.webkit.WebView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;

/** Real WebView/native-bridge smoke tests; provider codecs need separate device tests. */
@RunWith(AndroidJUnit4.class)
public class AndroidCompatTest {
 @Test public void vlcNativeLibraryLoads() {
  android.content.Context context=androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().getTargetContext();
  org.videolan.libvlc.LibVLC engine=new org.videolan.libvlc.LibVLC(context,new java.util.ArrayList<String>());
  engine.release();
 }
 @Test public void firstRunAndCodeDialogRender() throws Exception {
  android.content.Context context=androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().getTargetContext();
  String agent=android.webkit.WebSettings.getDefaultUserAgent(context);
  java.util.regex.Matcher chrome=java.util.regex.Pattern.compile("(?:Chrome|Chromium)/(\\d+)").matcher(agent);
  // Android 7 images may expose an old WebView UA without a Chrome/Chromium
  // version.  Unknown must not be treated as modern: the production app needs
  // WebView 60+, while the independent VLC native-library test still runs.
  boolean supportedWebView=chrome.find() && Integer.parseInt(chrome.group(1))>=60;
  org.junit.Assume.assumeTrue("UI coverage pending: update the emulator WebView to Chrome 60+",supportedWebView);

  try(ActivityScenario<MainActivity> scenario=ActivityScenario.launch(MainActivity.class)) {
   String result="";
   for(int i=0;i<30;i++) {
    CountDownLatch latch=new CountDownLatch(1);String[] value={""};
    scenario.onActivity(activity->{
     WebView web=activity.getBridge().getWebView();
     web.evaluateJavascript("(function(){var b=document.getElementById('btnWelcomeAdd');if(!b)return 'not-ready';var a=document.getElementById('app').getBoundingClientRect();if(a.width<innerWidth*.98||a.height<innerHeight*.98)return 'layout-error: app does not fill viewport';var overlay=document.getElementById('overlay'),wasHidden=overlay.hidden,wasEmpty=document.body.classList.contains('empty');overlay.hidden=false;document.body.classList.remove('empty');var g=document.querySelector('.groups').getBoundingClientRect(),c=document.querySelector('.channels').getBoundingClientRect();var font=parseFloat(getComputedStyle(document.documentElement).fontSize),m=document.querySelector('.bar').getBoundingClientRect(),logo=document.querySelector('.title img').getBoundingClientRect();overlay.hidden=wasHidden;if(wasEmpty)document.body.classList.add('empty');if(g.width<Math.min(innerWidth*.24,font*13)*.9||c.width<Math.min(innerWidth*.32,font*19)*.9||g.height<innerHeight*.9||c.height<innerHeight*.9)return 'layout-error: category/channel columns collapsed';if(m.x<0||m.right>innerWidth+1||m.y<0||m.y>font*3)return 'layout-error: menu not at top right';if(logo.width<=0)return 'not-ready';if(logo.x<innerWidth*.5||logo.right>innerWidth+1||logo.y<innerHeight*.5||logo.bottom>innerHeight+1)return 'layout-error: tv2u logo not at bottom right';b.click();var d=document.getElementById('dlg');return d&&d.open&&document.getElementById('activationCode')?'ready':'not-ready';})()",v->{value[0]=v;latch.countDown();});
    });
    assertTrue("WebView response timed out",latch.await(5,TimeUnit.SECONDS));result=value[0];
    if("\"ready\"".equals(result))break;
    Thread.sleep(1000);
   }
   assertEquals("App viewport, category/channel columns and activation dialog must render; inspect returned layout error", "\"ready\"", result);
  }
 }
}
