package __PACKAGE__;

import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Reads a bounded prefix already received by the player; never opens another connection. */
public final class StreamFormatDetector {
    public static final int UNKNOWN=0, HLS=1, PROGRESSIVE=2, DASH=3, TEXT_ERROR=4, EMPTY_RESPONSE=5;
    public static final int AUTO=0;
    private volatile int kind=UNKNOWN;
    public int kind() { return kind; }
    public void observeEmpty() { if(kind==UNKNOWN)kind=EMPTY_RESPONSE; }
    public void observe(byte[] bytes, int length) {
        int detected=classify(bytes,length);
        if(detected!=UNKNOWN) kind=detected;
    }
    public static int classify(byte[] bytes, int length) {
        int n=Math.max(0,Math.min(length,bytes.length));
        if(n==0)return UNKNOWN;
        int start=0;
        if(n>=3 && (bytes[0]&255)==239 && (bytes[1]&255)==187 && (bytes[2]&255)==191)start=3;
        while(start<n && (bytes[start]==' ' || bytes[start]=='\r' || bytes[start]=='\n' || bytes[start]=='\t'))start++;
        String head=new String(bytes,start,n-start,StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
        if(head.startsWith("#extm3u"))return HLS;
        if(head.startsWith("<mpd") || (head.startsWith("<?xml") && head.contains("<mpd")))return DASH;
        if(head.startsWith("<!doctype html") || head.startsWith("<html") || head.startsWith("<head")
                || head.startsWith("<body") || head.startsWith("{") || head.startsWith("["))return TEXT_ERROR;
        for(int i=0;i<Math.min(188,n);i++)
            if(i+376<n && bytes[i]==0x47 && bytes[i+188]==0x47 && bytes[i+376]==0x47)return PROGRESSIVE;
        if(n>=8) {
            String box=new String(bytes,4,4,StandardCharsets.US_ASCII);
            if(box.equals("ftyp") || box.equals("styp") || box.equals("moof"))return PROGRESSIVE;
        }
        if(n>=4 && ((bytes[0]&255)==0x1a && (bytes[1]&255)==0x45 && (bytes[2]&255)==0xdf && (bytes[3]&255)==0xa3))return PROGRESSIVE;
        if(head.startsWith("flv") || head.startsWith("oggs") || head.startsWith("id3"))return PROGRESSIVE;
        return UNKNOWN;
    }
    /** Only a detected format may select a new source; each format is attempted once. */
    public static int nextMode(int kind,int triedModes) {
        if(kind!=HLS && kind!=PROGRESSIVE && kind!=DASH)return -1;
        return (triedModes & (1<<kind))==0 ? kind : -1;
    }
}
