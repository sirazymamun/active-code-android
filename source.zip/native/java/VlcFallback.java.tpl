package __PACKAGE__;

import android.content.Context;
import android.net.Uri;
import android.view.ViewGroup;

import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

/**
 * Second player (VLC's engine). Used only when ExoPlayer cannot play a channel: VLC has its own software decoders
 * (HEVC / H.264 / MPEG-2 / AV1 ... in any container), and falls back to software by itself when the hardware cannot cope.
 * The picture is stretched to fill the whole screen, like the main player.
 */
final class VlcFallback {

    interface Listener {
        default void onStarting() {}
        default void onFirstFrame() {}
        void onPlaying(boolean vod);
        void onBuffering();
        void onError();
        void onEnded();
        void onAudio(JSONArray tracks);
    }

    private final Context context;
    private final ViewGroup parent;
    private VLCVideoLayout layout;
    private LibVLC libVlc;
    private MediaPlayer mp;
    private Media outputMedia;
    private Runnable firstFrameProbe;
    private boolean playing = false;
    private boolean preferredAudioApplied = false;
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());
    private final java.util.concurrent.ExecutorService cleanup = java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "vlc-cleanup"); t.setDaemon(true); return t;
    });
    private int retiring = 0;
    private long session = 0;
    private Runnable pendingStart;
    private boolean shuttingDown = false;

    VlcFallback(Context context, ViewGroup parent) {
        this.context = context;
        this.parent = parent;
    }

    android.view.View videoView() { return layout; }

    boolean isActive() { return mp != null || pendingStart != null; }

    /** The VLC engine is created once and kept (starting it from scratch takes a noticeable moment). */
    private synchronized LibVLC lib() {
        if (libVlc == null) {
            ArrayList<String> args = new ArrayList<>();
            args.add("--drop-late-frames");        // avoid unbounded catch-up work on high-resolution streams
            args.add("--skip-frames");
            args.add("--avcodec-skiploopfilter=3"); // lighter software decoding of big pictures (4K), barely visible
            args.add("--avcodec-threads=2");        // cap decoder threads to avoid CPU/memory spikes on TV boxes
            args.add("--stats");
            args.add("--network-caching=1000");     // short start-up delay
            args.add("--live-caching=1000");
            libVlc = new LibVLC(context, args);
        }
        return libVlc;
    }

    /** App is closing: free the engine for good. */
    void shutdown() {
        shuttingDown = true;
        release();
        if (retiring == 0) finishShutdown();
    }

    private void finishShutdown() {
        final LibVLC oldLib = libVlc; libVlc = null;
        if (cleanup.isShutdown()) return;
        cleanup.execute(() -> { try { if (oldLib != null) oldLib.release(); } catch (Throwable ignored) { } });
        cleanup.shutdown();
    }

    void start(String url, String userAgent, Map<String, String> headers, final Listener listener) {
        release();
        if (shuttingDown) return;
        final long ticket = session;
        Runnable begin = () -> {
            if (ticket != session || shuttingDown) return;
            pendingStart = null;
            try { listener.onStarting(); startNow(url, userAgent, headers, listener); }
            catch (RuntimeException | LinkageError error) { release(); listener.onError(); }
        };
        // At most one pending start; a newer channel cancels it. Do not create
        // another VLC decoder until the previous one has actually been released.
        if (retiring > 0) pendingStart = begin;
        else begin.run();
    }

    private void startNow(String url, String userAgent, Map<String, String> headers, final Listener listener) {
        libVlc = lib();
        mp = new MediaPlayer(libVlc);
        final MediaPlayer active = mp;
        final long ticket = session;

        layout = new VLCVideoLayout(context);
        layout.setFocusable(false);
        layout.setFocusableInTouchMode(false);
        layout.setKeepScreenOn(true);
        parent.addView(layout, 0, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mp.attachViews(layout, null, false, false);
        mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_FILL);

        mp.setEventListener(new MediaPlayer.EventListener() {
            @Override
            public void onEvent(MediaPlayer.Event event) {
                if (mp != active || ticket != session || shuttingDown) return;
                switch (event.type) {
                    case MediaPlayer.Event.Buffering:
                        // Buffer completion is not proof that a decoder has started.
                        if (!playing) listener.onBuffering();
                        break;
                    case MediaPlayer.Event.Playing:
                        markPlaying(listener);
                        break;
                    case MediaPlayer.Event.EncounteredError:
                        listener.onError();
                        break;
                    case MediaPlayer.Event.EndReached:
                        if (playing) listener.onEnded(); else listener.onError();
                        break;
                    default:
                        break;
                }
            }
        });

        Media media = new Media(libVlc, Uri.parse(url));
        // Reference v2.1.14: automatic acceleration, with software fallback permitted.
        media.setHWDecoderEnabled(true, false);
        if (userAgent != null && !userAgent.isEmpty()) media.addOption(":http-user-agent=" + userAgent);
        if (headers != null) {
            for (Map.Entry<String, String> e : headers.entrySet()) {
                String k = e.getKey();
                if ("referer".equalsIgnoreCase(k) || "referrer".equalsIgnoreCase(k)) media.addOption(":http-referrer=" + e.getValue());
            }
        }
        media.addOption(":http-reconnect");
        mp.setMedia(media);
        outputMedia = media;
        playing = false;
        preferredAudioApplied = false;
        mp.play();
        final long started = android.os.SystemClock.elapsedRealtime();
        firstFrameProbe = new Runnable() {
            @Override public void run() {
                if (mp != active || ticket != session || shuttingDown) return;
                boolean reveal = false;
                try {
                    org.videolan.libvlc.interfaces.IMedia.Stats stats = media.getStats();
                    reveal = stats != null && stats.displayedPictures > 0;
                    // Radio: no picture will arrive. Require real output audio
                    // and a parsed audio track before abandoning the old picture.
                    if (!reveal && stats != null && stats.playedAbuffers > 0) {
                        boolean audio = false, video = false;
                        for (int i=0; i<media.getTrackCount(); i++) {
                            org.videolan.libvlc.interfaces.IMedia.Track track = media.getTrack(i);
                            if (track != null) { audio |= track.type == 0; video |= track.type == 1; }
                        }
                        reveal = audio && !video;
                    }
                } catch (RuntimeException ignored) { }
                if (reveal) { firstFrameProbe = null; listener.onFirstFrame(); return; }
                if (android.os.SystemClock.elapsedRealtime()-started >= 45000) {
                    firstFrameProbe = null; listener.onError(); return;
                }
                ui.postDelayed(this, 50);
            }
        };
        ui.postDelayed(firstFrameProbe, 50);
    }

    private void markPlaying(Listener listener) {
        if (playing) return;
        // Apply the preferred track once VLC exposes its real audio-track list.
        // Do not infer channel count from list position; use explicit labels only.
        selectPreferredVlcAudio();
        playing = true;
        listener.onPlaying(isVod());
        listener.onAudio(audioTracks());
    }

    /** Prefer an explicitly labelled stereo track over an explicitly labelled surround track. */
    private boolean selectPreferredVlcAudio() {
        try {
            if (mp == null || preferredAudioApplied) return false;
            MediaPlayer.TrackDescription[] list = mp.getAudioTracks();
            if (list == null || list.length == 0) return false;
            int current = mp.getAudioTrack();
            int stereoId = -1;
            int surroundId = -1;
            for (MediaPlayer.TrackDescription td : list) {
                if (td.id < 0 || td.name == null) continue;
                String n = td.name.toLowerCase(java.util.Locale.ROOT);
                boolean stereo = n.contains("stereo") || n.contains("2.0") || n.contains("2 ch") || n.contains("2ch") || n.contains("2-channel") || n.contains("2 channel") || n.contains("2 channels") || n.matches(".*\\b2\\s*ch\\b.*");
                boolean surround = n.contains("5.1") || n.contains("6 ch") || n.contains("6ch") || n.contains("6-channel") || n.contains("6 channel") || n.contains("surround");
                if (stereo && stereoId < 0) stereoId = td.id;
                if (surround && surroundId < 0) surroundId = td.id;
            }
            int wanted = stereoId >= 0 ? stereoId : (surroundId >= 0 ? surroundId : current);
            if (wanted < 0) return false;
            // Do not mark as applied until VLC accepts the requested track.
            if (wanted == current || mp.setAudioTrack(wanted)) {
                preferredAudioApplied = true;
                return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    /** Audio tracks of the current channel: {id, lang, label, channels, selected, supported}. */
    JSONArray audioTracks() {
        JSONArray arr = new JSONArray();
        try {
            if (mp == null) return arr;
            // A second attempt is useful because some streams expose audio tracks only
            // after playback has started. This only runs before the first preferred
            // selection succeeds; explicit user selections are left untouched.
            selectPreferredVlcAudio();
            MediaPlayer.TrackDescription[] list = mp.getAudioTracks();
            int cur = mp.getAudioTrack();
            if (list == null) return arr;
            java.util.ArrayList<MediaPlayer.TrackDescription> ordered = new java.util.ArrayList<>();
            for (MediaPlayer.TrackDescription td : list) if (td.id >= 0) ordered.add(td);
            java.util.Collections.sort(ordered, (a, b) -> Integer.compare(vlcAudioPriority(a), vlcAudioPriority(b)));
            for (MediaPlayer.TrackDescription td : ordered) {
                JSONObject o = new JSONObject();
                o.put("id", td.id);
                o.put("lang", "");
                o.put("label", td.name == null ? "" : td.name);
                o.put("channels", vlcAudioPriority(td) == 0 ? 2 : (vlcAudioPriority(td) == 1 ? 6 : 0));
                o.put("selected", td.id == cur);
                o.put("supported", true);
                arr.put(o);
            }
        } catch (Throwable ignored) { }
        return arr;
    }

    private static int vlcAudioPriority(MediaPlayer.TrackDescription td) {
        String n = td == null || td.name == null ? "" : td.name.toLowerCase(java.util.Locale.ROOT);
        if (n.contains("stereo") || n.contains("2.0") || n.contains("2 ch") || n.contains("2ch") || n.contains("2-channel") || n.contains("2 channel") || n.contains("2 channels") || n.matches(".*\\b2\\s*ch\\b.*")) return 0;
        if (n.contains("5.1") || n.contains("6 ch") || n.contains("6ch") || n.contains("6-channel") || n.contains("6 channel") || n.contains("surround")) return 1;
        return 2;
    }

    /** Records what is being played (original container, usually .ts) into a folder. Uses reflection so the build never depends on it. */
    boolean startRecord(String directory) {
        try {
            if (mp == null) return false;
            Object r = mp.getClass().getMethod("record", String.class).invoke(mp, directory);
            return !(r instanceof Boolean) || (Boolean) r;
        } catch (Throwable t) { return false; }
    }

    void stopRecord() {
        try { if (mp != null) mp.getClass().getMethod("record", String.class).invoke(mp, (Object) null); } catch (Throwable ignored) { }
    }

    boolean setAudio(int id) {
        try { return mp != null && mp.setAudioTrack(id); } catch (Throwable t) { return false; }
    }

    private boolean isVod() {
        try { return mp != null && mp.isSeekable() && mp.getLength() > 60000; } catch (Throwable t) { return false; }
    }

    /** Returns {position seconds, duration seconds} or null when not seekable. */
    long[] seekBy(long ms) {
        if (mp == null || !isVod()) return null;
        long dur = mp.getLength();
        long target = Math.max(0, mp.getTime() + ms);
        if (dur > 0 && target > dur - 1000) target = dur - 1000;
        mp.setTime(target);
        return new long[]{target / 1000, dur > 0 ? dur / 1000 : 0};
    }

    boolean isPlaying() { try { return mp!=null && mp.isPlaying(); } catch(Throwable ignored) { return false; } }
    void pause() { try { if (mp != null) mp.pause(); } catch (Throwable ignored) { } }
    void resume() { try { if (mp != null) mp.play(); } catch (Throwable ignored) { } }

    /** Stop decoded output without waiting for a provider connection to close on Android's UI thread. */
    void haltForAccessCheck() {
        playing = false;
        try { if (mp != null) { mp.setEventListener(null); mp.pause(); } } catch (Throwable ignored) { }
        release();
    }

    String describe() {
        StringBuilder sb = new StringBuilder("Player: VLC engine (fallback)");
        try {
            if (mp != null) {
                Object vt = mp.getCurrentVideoTrack();
                if (vt != null) {
                    int w = vt.getClass().getField("width").getInt(vt);
                    int h = vt.getClass().getField("height").getInt(vt);
                    if (w > 0 && h > 0) sb.append("\nPicture: ").append(w).append("x").append(h);
                }
                sb.append("\nPlayed: ").append(mp.getTime() / 1000).append(" s");
            }
        } catch (Throwable ignored) { }
        return sb.toString();
    }

    void release() {
        if (firstFrameProbe != null) { ui.removeCallbacks(firstFrameProbe); firstFrameProbe = null; }
        final Media oldMedia = outputMedia; outputMedia = null;
        if (oldMedia != null) oldMedia.release();
        ++session;
        pendingStart = null;
        final MediaPlayer old = mp;
        final VLCVideoLayout oldLayout = layout;
        mp = null;
        layout = null;
        playing = false;
        if (old == null) return;
        try { old.setEventListener(null); } catch (Throwable ignored) { }
        ++retiring;
        cleanup.execute(() -> {
            // libVLC stop/release can wait for a stalled provider socket or
            // decoder. Neither operation may block Android's input/UI thread.
            try { old.stop(); } catch (Throwable ignored) { }
            ui.post(() -> {
                // View detachment stays on main, after native playback stopped.
                try { old.detachViews(); } catch (Throwable ignored) { }
                try { if (oldLayout != null) parent.removeView(oldLayout); } catch (Throwable ignored) { }
                cleanup.execute(() -> {
                    try { old.release(); } catch (Throwable ignored) { }
                    ui.post(() -> {
                        --retiring;
                        if (shuttingDown && retiring == 0) finishShutdown();
                        else if (retiring == 0 && pendingStart != null) pendingStart.run();
                    });
                });
            });
        });
    }
}
