package __PACKAGE__;

import android.provider.Settings;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

@CapacitorPlugin(name = "TrialIdentity")
public class TrialIdentityPlugin extends Plugin {
    @PluginMethod
    public void getId(PluginCall call) {
        String id = Settings.Secure.getString(getContext().getContentResolver(), Settings.Secure.ANDROID_ID);
        if (id == null || id.trim().isEmpty() || "9774d56d682e549c".equals(id)) {
            call.reject("Android ID unavailable"); return;
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(("active-code-device-v1:" + id).getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format(java.util.Locale.US, "%02x", b & 0xff));
            JSObject result = new JSObject();
            result.put("deviceId", hex.substring(0, 32));
            call.resolve(result);
        } catch (Exception e) { call.reject("Could not derive device identifier"); }
    }
}
