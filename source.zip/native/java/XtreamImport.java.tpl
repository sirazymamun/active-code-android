package __PACKAGE__;

import android.util.JsonReader;
import android.util.JsonToken;
import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Stream Xtream API JSON from disk into an M3U file, never materializing the full JSON in WebView. */
public final class XtreamImport {
    private XtreamImport() {}
    private static final String[] USER_AGENTS = {
        "IPTVSmartersPro",
        "Mozilla/5.0 (Linux; Android 13; TV) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
        "VLC/3.0.18 LibVLC/3.0.18"
    };
    private static final long IMPORT_BUDGET_MS = 600000;
    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8").replace("+", "%20"); }
    private static String field(String s) { return s == null ? "" : s.replace('\n',' ').replace('\r',' ').replace('"','\''); }
    private static String value(JsonReader r) throws Exception {
        JsonToken t = r.peek();
        if (t == JsonToken.NULL) { r.nextNull(); return ""; }
        if (t == JsonToken.STRING || t == JsonToken.NUMBER) return r.nextString();
        if (t == JsonToken.BOOLEAN) return Boolean.toString(r.nextBoolean());
        r.skipValue(); return "";
    }
    private static Map<String,String> nextObject(JsonReader r) throws Exception {
        Map<String,String> m = new HashMap<>();
        r.beginObject();
        while (r.hasNext()) { String k=r.nextName(); m.put(k,value(r)); }
        r.endObject(); return m;
    }
    private static boolean isJsonArray(File file) {
        try (Reader in = new BufferedReader(new InputStreamReader(new FileInputStream(file),StandardCharsets.UTF_8))) {
            int c;
            do { c = in.read(); } while (c >= 0 && (c==0xFEFF || Character.isWhitespace((char)c)));
            return c == '[';
        } catch (Exception ignored) { return false; }
    }
    private static void get(String base, String user, String pass, String action, File dest,
                            long importDeadline, long endpointBudgetMs) throws Exception {
        String url=base + "/player_api.php?username=" + enc(user) + "&password=" + enc(pass) + "&action=" + action;
        long endpointDeadline = Math.min(importDeadline,
                android.os.SystemClock.elapsedRealtime() + endpointBudgetMs);
        Exception last = new IOException("Xtream endpoint timed out: " + action);
        for (int i=0;i<USER_AGENTS.length;i++) {
            long remaining = endpointDeadline - android.os.SystemClock.elapsedRealtime();
            if (remaining < 1000) break;
            int attemptsLeft = USER_AGENTS.length - i;
            long reserve = Math.max(0, attemptsLeft - 1) * 1000L;
            long attemptBudget = Math.max(1000, Math.min(endpointBudgetMs, remaining - reserve));
            try {
                HttpFetch.toFile(url,USER_AGENTS[i],dest,null,attemptBudget);
                if (!isJsonArray(dest)) throw new IOException("Xtream endpoint returned non-list data: " + action);
                return;
            } catch (Exception e) { last = e; }
        }
        throw last;
    }
    private static Map<String,String> categories(File file) throws Exception {
        Map<String,String> m=new HashMap<>();
        try (JsonReader r=new JsonReader(new InputStreamReader(new FileInputStream(file),StandardCharsets.UTF_8))) {
            r.beginArray();
            while (r.hasNext()) {
                Map<String,String> row=nextObject(r);
                m.put(row.getOrDefault("category_id",""),row.getOrDefault("category_name",""));
            }
            r.endArray();
            if(r.peek()!=JsonToken.END_DOCUMENT)throw new IOException("Invalid trailing catalogue data");
        }
        return m;
    }
    /** Fast category-only lookup used to classify an already downloaded M3U. */
    public static Map<String,Set<String>> mediaCategories(String base, String user, String pass,
                                                          File cacheDir) throws Exception {
        if (!base.startsWith("http://") && !base.startsWith("https://")) throw new IOException("Invalid server URL");
        File json=File.createTempFile("xtream_categories_",".json",cacheDir);
        Map<String,Set<String>> result=new HashMap<>();
        result.put("movie",new HashSet<>());
        result.put("series",new HashSet<>());
        long deadline=android.os.SystemClock.elapsedRealtime()+10000;
        Exception last=null;
        try {
            String[] types={"movie","series"};
            String[] actions={"get_vod_categories","get_series_categories"};
            for (int i=0;i<types.length;i++) {
                try {
                    get(base,user,pass,actions[i],json,deadline,5000);
                    for (String name : categories(json).values())
                        if (name != null && !name.trim().isEmpty()) result.get(types[i]).add(name);
                } catch (Exception e) { last=e; }
            }
            if (result.get("movie").isEmpty() && result.get("series").isEmpty() && last!=null) throw last;
            return result;
        } finally { json.delete(); }
    }
    private static long append(File file, BufferedWriter out, String base, String user, String pass,
                               String type, Map<String,String> groups, String output) throws Exception {
        long count=0;
        try (JsonReader r=new JsonReader(new InputStreamReader(new FileInputStream(file),StandardCharsets.UTF_8))) {
            r.beginArray();
            while (r.hasNext()) {
                Map<String,String> row=nextObject(r);
                String id=row.getOrDefault(type.equals("series")?"series_id":"stream_id","");
                if (id.isEmpty()) throw new IOException(type+" catalogue entry is missing its id");
                String name=row.getOrDefault("name", "Item " + id);
                String group=groups.getOrDefault(row.getOrDefault("category_id",""),
                        type.equals("live")?"Live TV":type.equals("movie")?"Movies":"Series");
                String extension=type.equals("live")?(("m3u8".equalsIgnoreCase(output)||"hls".equalsIgnoreCase(output))?"m3u8":"ts"):type.equals("movie")?row.getOrDefault("container_extension","mp4"):"";
                if (extension.isEmpty()) extension="mp4";
                String url=base + "/" + type + "/" + enc(user) + "/" + enc(pass) + "/" + enc(id)
                        + (type.equals("series")?"?tv2u_series=1":"."+extension.replaceAll("[^A-Za-z0-9]",""));
                out.write("#EXTINF:-1 group-title=\""+field(group)+"\","+field(name)+"\n");
                out.write(url); out.newLine(); count++;
            }
            r.endArray();
            if(r.peek()!=JsonToken.END_DOCUMENT)throw new IOException("Invalid trailing catalogue data");
        }
        return count;
    }
    private static final class ImportedType {
        final String type;
        final File json;
        final Map<String,String> groups;
        ImportedType(String type, File json, Map<String,String> groups) {
            this.type=type; this.json=json; this.groups=groups;
        }
    }
    public static BigStore build(String base, String user, String pass, File cacheDir, File storeDir,
                                 BigStore.Progress progress) throws Exception {
        return build(base,user,pass,cacheDir,storeDir,progress,"ts");
    }
    public static BigStore build(String base,String user,String pass,File cacheDir,File storeDir,BigStore.Progress progress,String output) throws Exception {
        if (!base.startsWith("http://") && !base.startsWith("https://")) throw new IOException("Invalid server URL");
        File m3u=File.createTempFile("xtream_playlist_",".m3u",cacheDir);
        java.util.concurrent.ExecutorService workers=java.util.concurrent.Executors.newFixedThreadPool(3);
        java.util.List<java.util.concurrent.Future<ImportedType>> pending=new ArrayList<>();
        final long deadline=android.os.SystemClock.elapsedRealtime()+IMPORT_BUDGET_MS;
        try {
            // Independent catalogues share one deadline. A slow/large Movies
            // response must not consume the time available to Live and Series.
            for (String type : new String[]{"live","movie","series"}) {
                pending.add(workers.submit(() -> {
                    File data=File.createTempFile("xtream_"+type+"_",".json",cacheDir);
                    File cats=null;
                    boolean keep=false;
                    try {
                        String apiType=type.equals("movie")?"vod":type;
                        get(base,user,pass,type.equals("series")?"get_series":"get_"+apiType+"_streams",
                                data,deadline,480000);
                        Map<String,String> groups=new HashMap<>();
                        try {
                            cats=File.createTempFile("xtream_categories_",".json",cacheDir);
                            get(base,user,pass,"get_"+apiType+"_categories",cats,deadline,30000);
                            groups=categories(cats);
                        } catch (Exception e) { throw new IOException(type+" categories could not be loaded",e); }
                        keep=true;
                        return new ImportedType(type,data,groups);
                    } finally {
                        if (cats!=null) cats.delete();
                        if (!keep) data.delete();
                    }
                }));
            }
            long total=0;
            Exception lastStreamError=null;
            try (BufferedWriter w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(m3u),StandardCharsets.UTF_8),65536)) {
                w.write("#EXTM3U\n");
                for (java.util.concurrent.Future<ImportedType> task : pending) {
                    ImportedType imported=null;
                    try {
                        imported=task.get();
                        total+=append(imported.json,w,base,user,pass,imported.type,imported.groups,output);
                    } catch (Exception e) {
                        lastStreamError=new IOException("One or more Live TV / Movies / Series catalogues failed. Please Reload.",e);
                    } finally {
                        if (imported!=null) imported.json.delete();
                    }
                }
            }
            if (lastStreamError!=null) throw lastStreamError;
            if (total==0) throw new IOException("Xtream API returned no playable entries",lastStreamError);
            return BigStore.build(m3u,storeDir,progress);
        } finally {
            workers.shutdownNow();
            m3u.delete();
        }
    }
}
