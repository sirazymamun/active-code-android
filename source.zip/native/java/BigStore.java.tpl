package __PACKAGE__;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataInput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Disk-backed channel store for very large playlists (hundreds of MB).
 * The playlist is parsed as a stream and each channel is written to entries.dat; only a few bytes per channel
 * (offset, group, kind) stay in memory, so memory use does not grow with the size of the playlist.
 * Pure Java: no Android classes.
 */
public class BigStore {

    public interface Progress { void onEntries(long n); }

    public static class Item {
        public String name = "", url = "", ua = "", ref = "", group = "";
    }

    public static class Page {
        public List<Item> items = new ArrayList<>();
        public long total;
    }

    public static class Group {
        public String key, label;
        public int count;
    }

    private static final String DAT = "entries.dat", IDX = "index-media-v2.bin";

    private final File dir;
    private int n;
    private long[] offsets;
    private int[] gids;
    private byte[] kinds;
    private final List<String> groupNames = new ArrayList<>();
    private final Map<String, Integer> groupId = new HashMap<>();
    private int[] groupCount = new int[16];
    private final int[] kindCount = new int[3];

    private String cachedSearchNeedle;
    private int[] cachedSearchHits;

    private BigStore(File dir) { this.dir = dir; }

    /* ------------------------------------------------------------ build */

    public static BigStore build(File m3u, File dir, Progress progress) throws Exception {
        return build(m3u, dir, progress, null);
    }

    public static BigStore build(File m3u, File dir, Progress progress, String sourceUrl) throws Exception {
        deleteDir(dir);
        if (!dir.mkdirs() && !dir.isDirectory()) throw new Exception("Cannot create storage folder");
        BigStore s = new BigStore(dir);
        s.offsets = new long[1 << 16];
        s.gids = new int[1 << 16];
        s.kinds = new byte[1 << 16];

        long pos = 0;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(m3u), StandardCharsets.UTF_8), 1 << 16);
             DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(new File(dir, DAT)), 1 << 16))) {
            String line;
            String name = null, group = "", kindHint = "", pendingGroup = "", ua = "", ref = "";
            boolean haveInf = false, extended = false;
            boolean first = true;
            while ((line = r.readLine()) != null) {
                if (first) { first = false; if (!line.isEmpty() && line.charAt(0) == '\uFEFF') line = line.substring(1); }
                line = line.trim();
                if (line.isEmpty()) continue;
                if (line.regionMatches(true, 0, "#EXTM3U", 0, 7)) { extended = true; continue; }
                if (line.regionMatches(true, 0, "#EXTINF", 0, 7)) {
                    String[] f = parseExtInf(line);
                    name = f[0]; group = f[1]; kindHint = f[2]; haveInf = true;
                    continue;
                }
                if (line.regionMatches(true, 0, "#EXTGRP:", 0, 8)) { pendingGroup = line.substring(8).trim(); continue; }
                if (line.regionMatches(true, 0, "#EXTVLCOPT:", 0, 11)) {
                    String v = line.substring(11).trim();
                    int eq = v.indexOf('=');
                    if (eq > 0) {
                        String k = v.substring(0, eq).trim().toLowerCase(Locale.ROOT);
                        String val = v.substring(eq + 1).trim();
                        if (k.equals("http-user-agent")) ua = val;
                        else if (k.equals("http-referrer") || k.equals("http-referer")) ref = val;
                    }
                    continue;
                }
                if (line.charAt(0) == '#') continue;

                String url = line;
                int pipe = url.indexOf('|');
                if (pipe > 0 && pipe + 1 < url.length() && url.substring(pipe + 1).matches("^[\\w-]+=.*")) {
                    for (String pair : url.substring(pipe + 1).split("&")) {
                        int eq = pair.indexOf('=');
                        if (eq <= 0) continue;
                        String k = pair.substring(0, eq).trim().toLowerCase(Locale.ROOT);
                        String val = pair.substring(eq + 1);
                        try { val = java.net.URLDecoder.decode(val, "UTF-8"); } catch (Exception ignored) { }
                        if (k.equals("user-agent")) ua = val; else if (k.equals("referer") || k.equals("referrer")) ref = val;
                    }
                    url = url.substring(0, pipe);
                }
                if (!hasValidUrlScheme(url) && sourceUrl != null && (haveInf || extended)) {
                    try { url = new java.net.URL(new java.net.URL(sourceUrl), url).toString(); }
                    catch (java.net.MalformedURLException ignored) { }
                }
                if (!hasValidUrlScheme(url)) { haveInf = false; name = null; group = ""; kindHint = ""; ua = ""; ref = ""; pendingGroup = ""; continue; }

                String g = haveInf ? group : "";
                if (g.isEmpty() && !pendingGroup.isEmpty()) g = pendingGroup;
                String nm = (haveInf && name != null && !name.isEmpty()) ? name : nameFromUrl(url);

                int gid = s.groupIdFor(g);
                int kind = mediaKind(url, g, nm, kindHint);
                s.add(pos, gid, kind);
                pos += writeField(out, nm) + writeField(out, "") + writeField(out, url) + writeField(out, ua) + writeField(out, ref);

                haveInf = false; name = null; group = ""; kindHint = ""; pendingGroup = ""; ua = ""; ref = "";
                if (progress != null && (s.n & 0x3FFF) == 0) progress.onEntries(s.n);
            }
        }
        if (s.n == 0) { deleteDir(dir); throw new Exception("No playable entries found in the playlist"); }
        if (progress != null) progress.onEntries(s.n);
        s.saveIndex();
        return s;
    }

    private static int writeField(DataOutputStream out, String v) throws Exception {
        byte[] b = v.getBytes(StandardCharsets.UTF_8);
        if (b.length > 60000) { b = Arrays.copyOf(b, 60000); }
        out.writeShort(b.length);
        out.write(b);
        return 2 + b.length;
    }

    private static String readField(DataInput in) throws Exception {
        int len = in.readUnsignedShort();
        byte[] b = new byte[len];
        in.readFully(b);
        return new String(b, StandardCharsets.UTF_8);
    }


    private int groupIdFor(String g) {
        Integer id = groupId.get(g);
        if (id == null) {
            id = groupNames.size();
            groupNames.add(g);
            groupId.put(g, id);
            if (id >= groupCount.length) groupCount = Arrays.copyOf(groupCount, groupCount.length * 2);
        }
        return id;
    }

    private void add(long off, int gid, int kind) {
        if (n == offsets.length) {
            int cap = n * 2;
            offsets = Arrays.copyOf(offsets, cap);
            gids = Arrays.copyOf(gids, cap);
            kinds = Arrays.copyOf(kinds, cap);
        }
        offsets[n] = off; gids[n] = gid; kinds[n] = (byte) kind;
        groupCount[gid]++;
        kindCount[kind]++;
        n++;
    }

    static String[] parseExtInf(String line) {
        String body = line.substring(line.indexOf(':') >= 0 ? line.indexOf(':') + 1 : line.length());
        String tvgName = "", group = "", kindHint = "";
        StringBuilder stripped = new StringBuilder();
        int i = 0, len = body.length();
        while (i < len) {
            // attribute  key="value"
            int eq = body.indexOf("=\"", i);
            if (eq < 0) { stripped.append(body, i, len); break; }
            int ks = eq;
            while (ks > i && isKeyChar(body.charAt(ks - 1))) ks--;
            int ve = body.indexOf('"', eq + 2);
            if (ve < 0) { stripped.append(body, i, len); break; }
            if (ks == eq) { stripped.append(body, i, eq + 2); i = eq + 2; continue; }
            stripped.append(body, i, ks);
            String key = body.substring(ks, eq).toLowerCase(Locale.ROOT);
            String val = body.substring(eq + 2, ve);
            if (key.equals("tvg-name")) tvgName = val;
            else if (key.equals("group-title")) group = val;
            else if (key.equals("stream-type") || key.equals("media-type") || key.equals("tvg-type") || key.equals("type")) kindHint = val;
            i = ve + 1;
        }
        int comma = stripped.indexOf(",");
        String name = comma >= 0 ? stripped.substring(comma + 1).trim() : "";
        if (name.isEmpty()) name = tvgName;
        return new String[]{name, group, kindHint};
    }

    private static boolean isKeyChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_' || c == '.' || c == '-';
    }

    private static boolean hasValidUrlScheme(String url) {
        int end = url.indexOf("://");
        if (end < 1 || !Character.isLetter(url.charAt(0))) return false;
        for (int i = 1; i < end; i++) {
            char c = url.charAt(i);
            if (!(Character.isLetterOrDigit(c) || c == '+' || c == '.' || c == '-')) return false;
        }
        return true;
    }

    static String nameFromUrl(String url) {
        try {
            String p = new java.net.URL(url).getPath();
            String[] parts = p.split("/");
            for (int i = parts.length - 1; i >= 0; i--) if (!parts[i].isEmpty()) return java.net.URLDecoder.decode(parts[i], "UTF-8");
            return new java.net.URL(url).getHost();
        } catch (Exception e) {
            return url.length() > 60 ? url.substring(0, 60) : url;
        }
    }

    /** Classify direct M3U entries as well as conventional Xtream URLs. */
    private static int mediaKind(String url, String group, String name, String hint) {
        String path, query;
        String h = hint == null ? "" : hint.trim().toLowerCase(Locale.ROOT);
        String nm = name == null ? "" : name.toLowerCase(Locale.ROOT);
        try {
            java.net.URI parsed = new java.net.URI(url);
            path = parsed.getPath().toLowerCase(Locale.ROOT);
            query = "?" + (parsed.getRawQuery() == null ? "" : parsed.getRawQuery().toLowerCase(Locale.ROOT));
        } catch (Exception ignored) { return 0; }
        // A category such as INDIAN | MOVIES is a genre, not evidence of VOD.
        if (path.contains("/live/") || query.matches(".*[?&](?:type|stream_type|media_type)=live(?:[&#].*)?")) return 0;
        if (h.equals("live")) return 0;
        if (path.matches(".*/(?:series|tv[ _-]?series|episodes?)/.*") || query.matches(".*[?&](?:type|stream_type|media_type)=(?:series|episode)(?:[&#].*)?")) return 2;
        if (path.matches(".*/(?:movie|movies|vod|film|films)/.*") || query.matches(".*[?&](?:type|stream_type|media_type)=(?:movie|movies|vod|film)(?:[&#].*)?")) return 1;
        if (h.matches("series|episode|tv_series")) return 2;
        if (h.matches("movie|movies|vod|film")) return 1;
        if (path.matches(".*\\.(?:mp4|mkv|avi|mov|m4v)$")) {
            return nm.matches(".*(?:s[0-9]{1,2}[ ]*e[0-9]{1,3}|[0-9]{1,2}x[0-9]{1,3}|(?:episode|season)[ ]*[0-9]+|الحلقة[ ]*[0-9]+|পর্ব[ ]*[0-9]+).*") ? 2 : 1;
        }
        return 0;
    }

    /* ------------------------------------------------------------ index file */

    private void saveIndex() throws Exception {
        try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(new File(dir, IDX)), 1 << 16))) {
            o.writeInt(n);
            o.writeInt(groupNames.size());
            for (String g : groupNames) { byte[] b = g.getBytes(StandardCharsets.UTF_8); o.writeShort(Math.min(b.length, 60000)); o.write(b, 0, Math.min(b.length, 60000)); }
            for (int i = 0; i < n; i++) { o.writeLong(offsets[i]); o.writeInt(gids[i]); o.writeByte(kinds[i]); }
        }
    }

    public static BigStore open(File dir) {
        File idx = new File(dir, IDX), dat = new File(dir, DAT);
        if (!idx.isFile() || !dat.isFile()) return null;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(idx), 1 << 16))) {
            BigStore s = new BigStore(dir);
            int cnt = in.readInt();
            int groups = in.readInt();
            for (int g = 0; g < groups; g++) { String name = readField(in); s.groupIdFor(name); }
            s.offsets = new long[Math.max(cnt, 16)];
            s.gids = new int[Math.max(cnt, 16)];
            s.kinds = new byte[Math.max(cnt, 16)];
            for (int i = 0; i < cnt; i++) {
                long off = in.readLong(); int gid = in.readInt(); int kind = in.readByte();
                s.add(off, gid, kind);
            }
            return s;
        } catch (Exception e) {
            return null;
        }
    }

    /* ------------------------------------------------------------ info + query */

    public int total() { return n; }

    /** Kept for older bridge callers. Shared category names cannot determine stream type. */
    public synchronized int reclassify(Set<String> movieGroups, Set<String> seriesGroups) throws Exception {
        return 0;
    }

    public List<Group> groups() {
        List<Group> list = new ArrayList<>();
        String[] kl = {"Live TV", "Movies", "Series"}, kk = {"k:live", "k:movie", "k:series"};
        // These are stable top-level navigation rows, even when a provider has
        // no entries for one type. Provider categories follow underneath.
        for (int k = 0; k < 3; k++) { Group g = new Group(); g.key = kk[k]; g.label = kl[k]; g.count = kindCount[k]; list.add(g); }
        for (int i = 0; i < groupNames.size(); i++) {
            Group g = new Group();
            String nm = groupNames.get(i);
            if (nm.equalsIgnoreCase("Live TV") || nm.equalsIgnoreCase("Movies") || nm.equalsIgnoreCase("Series")) continue;
            g.key = "g:" + nm;
            g.label = nm.isEmpty() ? "Ungrouped" : nm;
            g.count = groupCount[i];
            list.add(g);
        }
        return list;
    }

    private boolean matches(int i, String group, int gidWanted, int kindWanted) {
        if (kindWanted >= 0) return kinds[i] == kindWanted;
        if (gidWanted >= 0) return gids[i] == gidWanted;
        return group.equals("all");
    }

    /** Paged channel list, optionally limited to an existing group or media kind. */
    public Page listPage(String group, int offset, int limit) throws Exception {
        if (group == null) group = "all";
        offset = Math.max(0, offset);
        limit = Math.max(1, Math.min(500, limit));
        int kindWanted = group.equals("k:live") ? 0 : group.equals("k:movie") ? 1 : group.equals("k:series") ? 2 : -1;
        int gidWanted = -1;
        if (group.startsWith("g:")) { Integer id = groupId.get(group.substring(2)); gidWanted = id == null ? Integer.MAX_VALUE : id; }
        Page page = new Page();
        long total = 0;
        List<Integer> wanted = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (!matches(i, group, gidWanted, kindWanted)) continue;
            if (total >= offset && wanted.size() < limit) wanted.add(i);
            total++;
        }
        page.total = total;
        if (!wanted.isEmpty()) {
            try (RandomAccessFile data = new RandomAccessFile(new File(dir, DAT), "r")) {
                for (int i : wanted) {
                    data.seek(offsets[i]);
                    page.items.add(readItem(data, gids[i]));
                }
            }
        }
        return page;
    }

    /** Search all entries using buffered sequential I/O, caching IDs for pagination. */
    public Page searchPage(String query, int offset, int limit) throws Exception {
        return searchPage(query, offset, limit, () -> false);
    }

    private static void checkSearchCancelled(java.util.function.BooleanSupplier cancelled) throws java.io.InterruptedIOException {
        if (Thread.currentThread().isInterrupted() || cancelled.getAsBoolean())
            throw new java.io.InterruptedIOException("Search superseded");
    }

    public synchronized Page searchPage(String query, int offset, int limit,
                                         java.util.function.BooleanSupplier cancelled) throws Exception {
        checkSearchCancelled(cancelled);
        String needle = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        Page page = new Page();
        if (needle.isEmpty()) return page;
        offset = Math.max(0, offset);
        limit = Math.max(1, Math.min(200, limit));
        if (!needle.equals(cachedSearchNeedle)) {
            int[] hits = new int[n];
            int count = 0;
            try (java.io.DataInputStream data = new java.io.DataInputStream(
                    new BufferedInputStream(new FileInputStream(new File(dir, DAT)), 1 << 16))) {
                for (int i = 0; i < n; i++) {
                    if ((i & 255) == 0) checkSearchCancelled(cancelled);
                    Item it = readItem(data, gids[i]);
                    if (it.name.toLowerCase(Locale.ROOT).contains(needle)
                        || it.group.toLowerCase(Locale.ROOT).contains(needle)
                        || it.url.toLowerCase(Locale.ROOT).contains(needle)) hits[count++] = i;
                }
            }
            checkSearchCancelled(cancelled);
            cachedSearchHits = Arrays.copyOf(hits, count);
            cachedSearchNeedle = needle;
        }
        page.total = cachedSearchHits.length;
        int end = (int)Math.min((long)cachedSearchHits.length, (long)offset + limit);
        try (RandomAccessFile data = new RandomAccessFile(new File(dir, DAT), "r")) {
            for (int at = offset; at < end; at++) {
                checkSearchCancelled(cancelled);
                int i = cachedSearchHits[at];
                data.seek(offsets[i]);
                page.items.add(readItem(data, gids[i]));
            }
        }
        return page;
    }

    private Item readItem(DataInput in, int gid) throws Exception {
        Item it = new Item();
        it.name = readField(in);
        readField(in); // Discard the retired field so existing on-device databases remain readable.
        it.url = readField(in);
        it.ua = readField(in);
        it.ref = readField(in);
        it.group = groupNames.get(gid);
        return it;
    }

    /* ------------------------------------------------------------ helpers */

    public static void deleteDir(File d) {
        File[] files = d.listFiles();
        if (files != null) for (File f : files) { if (f.isDirectory()) deleteDir(f); else f.delete(); }
        d.delete();
    }
}
