package __PACKAGE__;

import android.graphics.Bitmap;
import android.os.Handler;
import android.view.PixelCopy;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

/** One bounded, in-memory video picture below the WebView controls. No extra decoder. */
final class FrameHold {
    private final ViewGroup parent;
    private final View controls;
    private final Handler main;
    private ImageView image;
    private Runnable pending;
    private boolean copying;
    private boolean waiting;
    private long ticket;
    private Runnable timeout;

    FrameHold(ViewGroup parent, View controls, Handler main) {
        this.parent = parent; this.controls = controls; this.main = main;
    }

    void captureThen(View video, Runnable start) {
        pending = start;
        if (image != null || copying) {
            // Keep the same old picture through rapid zaps. If a capture is still
            // pending, its callback starts only the most recently requested item.
            if (!copying || !waiting || image != null) runPending();
            return;
        }
        View source = findVideo(video);
        if (source == null || source.getWidth() < 1 || source.getHeight() < 1) { runPending(); return; }
        final long capture = ++ticket;
        try {
            double scale = Math.min(1.0, Math.min(960.0/source.getWidth(), 540.0/source.getHeight()));
            int w = Math.max(1, (int)(source.getWidth()*scale));
            int h = Math.max(1, (int)(source.getHeight()*scale));
            if (source instanceof TextureView) {
                Bitmap bitmap = ((TextureView)source).getBitmap(w, h);
                if (bitmap != null) show(bitmap);
                runPending(); return;
            }
            final Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            copying = true;
            waiting = true;
            timeout = () -> {
                if (capture != ticket) return;
                waiting = false;
                ++ticket; // a late PixelCopy must never cover the next video
                runPending(); // capture wait is included in the existing startup budget
            };
            main.postDelayed(timeout, 120);
            PixelCopy.request(((SurfaceView)source).getHolder().getSurface(), bitmap, result -> {
                copying = false;
                waiting = false;
                if (capture != ticket) { bitmap.recycle(); runPending(); return; }
                main.removeCallbacks(timeout);
                if (result == PixelCopy.SUCCESS) show(bitmap);
                else bitmap.recycle(); // no source/protected output: switch normally
                runPending();
            }, main);
        } catch (RuntimeException | OutOfMemoryError error) {
            copying = false;
                waiting = false;
            if (timeout != null) main.removeCallbacks(timeout);
            runPending();
        }
    }

    private void runPending() { Runnable next = pending; pending = null; if (next != null) next.run(); }
    private void show(Bitmap bitmap) {
        image = new ImageView(parent.getContext());
        image.setScaleType(ImageView.ScaleType.FIT_XY);
        image.setFocusable(false); image.setClickable(false);
        image.setImageBitmap(bitmap);
        int index = parent.indexOfChild(controls);
        parent.addView(image, Math.max(0,index), new ViewGroup.LayoutParams(-1,-1));
        // No recycle while the GPU may still reference the displayed bitmap.
    }
    void clear() {
        ++ticket;
        waiting = false;
        pending = null;
        if (timeout != null) main.removeCallbacks(timeout);
        if (image != null) { image.setImageDrawable(null); parent.removeView(image); image = null; }
    }
    private static View findVideo(View view) {
        if (view == null || view.getVisibility() != View.VISIBLE) return null;
        if (view instanceof SurfaceView || view instanceof TextureView) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup)view;
            for (int i=0;i<group.getChildCount();i++) {
                View found = findVideo(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }
}
