package __PACKAGE__;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import javax.net.ssl.SSLException;
import java.nio.charset.StandardCharsets;

/** Plain-Java playlist / JSON download: follows http <-> https redirects, reports progress, decodes UTF-8. */
public class HttpFetch {

    public interface Progress { void onBytes(long total); }

    public static String get(String start, String ua, Progress progress) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream(1 << 20);
        stream(start, ua, out, progress);
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    /** Download straight into a file (no size limit besides disk space). Returns the byte count. */
    public static long toFile(String start, String ua, java.io.File file, Progress progress) throws Exception {
        try (java.io.OutputStream os = new java.io.BufferedOutputStream(new java.io.FileOutputStream(file), 1 << 16)) {
            return stream(start, ua, os, progress, 25000, 90000, 600000);
        }
    }

    /**
     * Bounded playlist/API attempt. `budgetMs` covers connect, response and body,
     * so changing User-Agent can never multiply one failed request into minutes.
     */
    public static long toFile(String start, String ua, java.io.File file, Progress progress,
                              long budgetMs) throws Exception {
        return toFile(start, ua, file, progress, budgetMs, null);
    }

    public static long toFile(String start, String ua, java.io.File file, Progress progress,
                              long budgetMs, String[] finalUrl) throws Exception {
        long callMs = Math.max(1000, budgetMs);
        long connectMs = Math.min(10000, callMs);
        long readMs = Math.min(15000, callMs);
        try (java.io.OutputStream os = new java.io.BufferedOutputStream(new java.io.FileOutputStream(file), 1 << 16)) {
            return stream(start, ua, os, progress, connectMs, readMs, callMs, finalUrl);
        }
    }

    private static long stream(String start, String ua, java.io.OutputStream out, Progress progress) throws Exception {
        return stream(start, ua, out, progress, 25000, 90000, 600000);
    }

    private static long stream(String start, String ua, java.io.OutputStream out, Progress progress,
                               long connectMs, long readMs, long callMs) throws Exception {
        return stream(start, ua, out, progress, connectMs, readMs, callMs, null);
    }

    private static long stream(String start, String ua, java.io.OutputStream out, Progress progress,
                               long connectMs, long readMs, long callMs, String[] finalUrl) throws Exception {
        okhttp3.OkHttpClient client = new okhttp3.OkHttpClient.Builder()
            .connectTimeout(connectMs, java.util.concurrent.TimeUnit.MILLISECONDS)
            .readTimeout(readMs, java.util.concurrent.TimeUnit.MILLISECONDS)
            .callTimeout(callMs, java.util.concurrent.TimeUnit.MILLISECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build();
        okhttp3.Request request = new okhttp3.Request.Builder()
            .url(start).header("User-Agent", ua).header("Accept", "*/*").get().build();
        try (okhttp3.Response response = client.newCall(request).execute()) {
            if (finalUrl != null && finalUrl.length > 0) finalUrl[0] = response.request().url().toString();
            if (!response.isSuccessful()) throw new java.io.IOException("Server answered HTTP " + response.code());
            if (response.body() == null) throw new java.io.IOException("Server returned no response body");
            long total = 0, lastEmit = 0;
            try (InputStream in = response.body().byteStream()) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) != -1) {
                    if (n == 0) continue;
                    out.write(buf, 0, n);
                    total += n;
                    // One UI update per MiB keeps progress useful without flooding
                    // the WebView bridge on very large provider playlists.
                    if (progress != null && total - lastEmit >= 1048576) {
                        lastEmit = total;
                        progress.onBytes(total);
                    }
                }
            }
            if (progress != null) progress.onBytes(total);
            return total;
        } catch (SSLException tls) {
            URL endpoint = new URL(start);
            String schemePort = endpoint.getProtocol() + "://" + endpoint.getHost()
                + (endpoint.getPort() < 0 ? "" : ":" + endpoint.getPort());
            throw new java.io.IOException("TLS connection failed while downloading playlist from "
                + schemePort + " (possibly after redirect): "
                + tls.getClass().getSimpleName() + ": " + tls.getMessage(), tls);
        }
    }
}
