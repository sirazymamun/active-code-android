package __PACKAGE__;

import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import com.getcapacitor.PluginHandle;
import android.view.WindowManager;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NativePlayerPlugin.class);
        registerPlugin(TrialIdentityPlugin.class);
        super.onCreate(savedInstanceState);
        String userAgent=android.webkit.WebSettings.getDefaultUserAgent(this);
        java.util.regex.Matcher chrome=java.util.regex.Pattern.compile("(?:Chrome|Chromium)/(\\d+)").matcher(userAgent);
        boolean supportedWebView=chrome.find() && Integer.parseInt(chrome.group(1))>=60;
        if(!supportedWebView) {
            new android.app.AlertDialog.Builder(this)
                .setTitle("WebView update required")
                .setMessage("active-code needs Chrome / Android System WebView 60 or newer. Update the WebView provider in device settings, then reopen the app.")
                .setPositiveButton("Open settings",(dialog,which)->{
                    try { startActivity(new android.content.Intent(android.provider.Settings.ACTION_SETTINGS)); }
                    catch(Exception ignored) { }
                }).setNegativeButton("Close",(dialog,which)->finish()).setCancelable(false).show();
        }


        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        hideSystemBars();
    }

    @Override
    public void onResume() {
        super.onResume();
        hideSystemBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int code=event.getKeyCode();
        if (code==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code==KeyEvent.KEYCODE_MEDIA_PLAY || code==KeyEvent.KEYCODE_MEDIA_PAUSE) {
            if (event.getAction()==KeyEvent.ACTION_DOWN && event.getRepeatCount()==0 && getBridge()!=null) {
                PluginHandle handle=getBridge().getPlugin("NativePlayer");
                if(handle!=null && handle.getInstance() instanceof NativePlayerPlugin)
                    ((NativePlayerPlugin)handle.getInstance()).handleMediaKey(code);
            }
            return true;
        }
        // Video surfaces may acquire focus during decoder/fallback transitions.
        // TV navigation belongs to the WebView, even when the channel failed.
        if (code==KeyEvent.KEYCODE_DPAD_UP || code==KeyEvent.KEYCODE_DPAD_DOWN
                || code==KeyEvent.KEYCODE_DPAD_LEFT || code==KeyEvent.KEYCODE_DPAD_RIGHT
                || code==KeyEvent.KEYCODE_DPAD_CENTER || code==KeyEvent.KEYCODE_ENTER
                || code==KeyEvent.KEYCODE_MENU || code==KeyEvent.KEYCODE_CHANNEL_UP
                || code==KeyEvent.KEYCODE_CHANNEL_DOWN || code==KeyEvent.KEYCODE_PAGE_UP
                || code==KeyEvent.KEYCODE_PAGE_DOWN) {
            android.webkit.WebView web = getBridge()==null ? null : getBridge().getWebView();
            if (web != null) {
                if (!web.hasFocus()) web.requestFocus();
                web.dispatchKeyEvent(event);
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    /** Immersive full screen: no status bar, no navigation bar. */
    private void hideSystemBars() {
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (c == null) return;
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        c.hide(WindowInsetsCompat.Type.systemBars());
    }
}
