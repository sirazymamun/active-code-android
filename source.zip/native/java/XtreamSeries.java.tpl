package __PACKAGE__;

import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Fetch only the selected series; catalogue imports never expand every episode. */
public final class XtreamSeries {
    private static String enc(String s) throws Exception {return URLEncoder.encode(s,"UTF-8").replace("+","%20");}
    public static List<BigStore.Item> load(String base,String user,String pass,String id,String name,File cache) throws Exception {
        if(base==null||(!base.startsWith("http://")&&!base.startsWith("https://"))||id==null||!id.matches("[0-9]+"))throw new IOException("Invalid series account");
        File json=File.createTempFile("series_info_",".json",cache);
        try {
            String url=base+"/player_api.php?username="+enc(user)+"&password="+enc(pass)+"&action=get_series_info&series_id="+enc(id);
            HttpFetch.toFile(url,"IPTVSmartersPro",json,null,120000);
            if(json.length()>16*1024*1024)throw new IOException("Series details exceed safe size limit");
            StringBuilder text=new StringBuilder();
            try(Reader r=new InputStreamReader(new FileInputStream(json),StandardCharsets.UTF_8)){char[] buf=new char[8192];int n;while((n=r.read(buf))>=0)text.append(buf,0,n);}
            JSONObject data=new JSONObject(text.toString());JSONObject episodes=data.optJSONObject("episodes");
            if(episodes==null)throw new IOException("This series has no playable episodes");
            List<String> seasons=new ArrayList<>();Iterator<String> names=episodes.keys();while(names.hasNext())seasons.add(names.next());
            seasons.sort((a,b)->{try{return Integer.compare(Integer.parseInt(a),Integer.parseInt(b));}catch(Exception e){return a.compareTo(b);}});
            List<BigStore.Item> out=new ArrayList<>();
            for(String season:seasons){
                JSONArray rows=episodes.optJSONArray(season);if(rows==null)continue;
                List<JSONObject> sorted=new ArrayList<>();for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);if(row!=null)sorted.add(row);}
                sorted.sort((a,b)->Integer.compare(a.optInt("episode_num",0),b.optInt("episode_num",0)));
                for(JSONObject row:sorted){String episode=row.optString("id","");if(!episode.matches("[0-9]+"))continue;
                    String ext=row.optString("container_extension","mp4");if(!ext.matches("[A-Za-z0-9]{1,8}"))ext="mp4";
                    BigStore.Item item=new BigStore.Item();item.name=row.optString("title","");if(item.name.isEmpty())item.name="Episode "+row.optString("episode_num",episode);
                    item.group=name+" · Season "+season;item.kindHint="series";
                    item.url=base+"/series/"+enc(user)+"/"+enc(pass)+"/"+enc(episode)+"."+ext;
                    String direct=row.optString("direct_source","");if(direct.startsWith("http://")||direct.startsWith("https://"))item.url=direct;
                    out.add(item);
                }
            }
            if(out.isEmpty())throw new IOException("This series has no playable episodes");return out;
        }finally{json.delete();}
    }
}
