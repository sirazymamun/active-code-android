package __PACKAGE__;

import android.content.SharedPreferences;
import android.content.Intent;
import android.app.Activity;
import android.speech.RecognizerIntent;
import android.content.ActivityNotFoundException;
import com.getcapacitor.annotation.ActivityCallback;
import java.util.Locale;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.datasource.DataSink;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.TeeDataSource;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.io.File;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Full-screen native video player (Media3 ExoPlayer) drawn BEHIND the transparent web view.
 * It plays HLS (.m3u8), raw MPEG-TS (.ts / mpegts), MP4/MKV, RTSP and DASH over http and https,
 * follows redirects (including http <-> https) and sends custom headers from the playlist.
 * No on-screen controller is ever shown.
 *
 * Robustness: slow-starting streams get long timeouts, a refused request (HTTP 401/403/406) is retried
 * with other User-Agents, failing decoders fall back to other decoders, and the plugin reports exactly
 * which video / audio formats a channel uses and whether this device can decode them.
 */
// Explicit Media3 opt-in: keep lint enabled and acknowledge the pinned API contract.
@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
@CapacitorPlugin(name = "NativePlayer")
public class NativePlayerPlugin extends Plugin {

    private static final String[] USER_AGENTS = {
            "IPTVSmartersPro",
            "VLC/3.0.18 LibVLC/3.0.18",
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            "Lavf/60.16.100",
            "okhttp/4.12.0"
    };
    private static final long STALL_MS = 5000; // user-requested 5-second watchdog
    private static final long PLAYLIST_FETCH_BUDGET_MS = 60000;
    private static final int PLAYLIST_UA_ATTEMPTS = 3;

    private PlayerView playerView;
    private ExoPlayer player;
    private final Handler main = new Handler(Looper.getMainLooper());

    // Subscription lease uses a monotonic Android clock, including time spent asleep.
    // This complements WebView checks so resume cannot bypass an expired permission.
    private volatile long accessUntil = 0;
    private boolean hasAccess() { return android.os.SystemClock.elapsedRealtime() < accessUntil; }
    private long playbackGeneration = 0;
    private FrameHold frameHold;
    private PluginCall pendingFramePlay;
    private void clearFrameHold() {
        if (frameHold != null) frameHold.clear();
        if (pendingFramePlay != null) { pendingFramePlay.resolve(); pendingFramePlay = null; }
    }
    private int playbackRequestId = 0;
    private long playbackAttempt = 0;
    private boolean playbackFailed = false;
    private final Runnable accessExpiry = () -> { if (!hasAccess()) expireAccess(); };
    private void expireAccess() {
        ++playbackGeneration; ++playbackAttempt;
        playbackFailed = true;
        accessUntil = 0;
        main.removeCallbacks(accessExpiry);
        // VLC's synchronous network stop can block Android's UI thread. Pause
        // decoded output here; normal next-start/destroy cleanup releases it.
        if (vlc != null && vlc.isActive()) vlc.haltForAccessCheck();
        vlcActive = false;
        if (playerView != null) playerView.setVisibility(android.view.View.VISIBLE);
        stopPlayback();
        emit("access-expired", "Subscription verification expired.");
    }
    @PluginMethod
    public void accessGrant(PluginCall call) {
        final double seconds = call.getDouble("seconds", 0.0);
        getActivity().runOnUiThread(() -> {
            main.removeCallbacks(accessExpiry);
            if (!Double.isFinite(seconds) || seconds <= 0) { expireAccess(); call.resolve(); return; }
            long ms = (long) (Math.min(seconds, 65.0) * 1000.0);
            accessUntil = android.os.SystemClock.elapsedRealtime() + ms;
            main.postDelayed(accessExpiry, ms);
            call.resolve();
        });
    }

    private String tracksSummary = "";
    private String videoDecoder = "";
    private String lastError = "";
    private String playbackPhase = "Idle";
    private boolean videoUnsupported = false;
    private boolean audioUnsupported = false;
    private boolean exoRenderedFrame = false;
    private String videoMime = "";
    private String audioMime = "";

    

    private VlcFallback vlc;
    private boolean vlcActive = false;

    // Request-wide monotonic deadlines: retries and unverified READY events cannot renew them.
    private long exoStartupDeadline = 0, exoFrameDeadline = 0, exoStallDeadline = 0;
    private long exoStallFrames = -1, exoStallPosition = 0;
    private long exoDroppedFrames = 0, exoQualityFrames = 0;
    private final Runnable videoStartupWatchdog = () -> {
        if (player == null || playbackFailed || vlcActive || !hasAccess()) return;
        checkExoDeadline();
    };

    private final Runnable stallWatchdog = new Runnable() {
        @Override
        public void run() {
            if (player != null && player.getPlaybackState() != Player.STATE_READY) {
                String msg = "No picture after " + (STALL_MS / 1000) + " seconds. ";
                if (tracksSummary.isEmpty()) {
                    msg += "No video or audio was found in the stream yet (the server may be slow, refusing the connection, or the stream is in an unsupported format).";
                } else {
                    msg += tracksSummary;
                }
                // Do not launch VLC just because startup/buffering took longer than the watchdog.
                // On Fire OS/low-memory Android TV devices, an unnecessary second decoder can
                // increase native-memory pressure and may cause the OS to kill the app.
                // Keep the diagnostic internally, but do not show a transient startup warning to viewers.
                // The user requested the 5-second watchdog remain unchanged; this does not trigger a player switch.
                lastError = msg;
            }
        }
    };

    @Override
    public void load() {
        installCrashRecorder();
        getActivity().runOnUiThread(() -> {
            WebView web = getBridge().getWebView();
            ViewGroup parent = (ViewGroup) web.getParent();
            parent.setBackgroundColor(Color.BLACK);
            web.setBackgroundColor(Color.TRANSPARENT);

            playerView = new PlayerView(getActivity());
            playerView.setUseController(false);
            playerView.setKeepScreenOn(true);
            playerView.setFocusable(false);
            playerView.setFocusableInTouchMode(false);
            playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER);
            playerView.setShutterBackgroundColor(Color.BLACK);
            playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
            videoParent = parent;
            frameHold = new FrameHold(parent, web, main);
            // Do not initialize VLC during app startup. Create the fallback lazily only if ExoPlayer needs it.
            // This reduces idle native-memory/decoder pressure on Fire OS devices playing 4K streams.
            parent.addView(playerView, 0, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            web.requestFocus();
        });
    }

    @PluginMethod
    public void play(PluginCall call) {
        final String url = call.getString("url");
        final int requestId = call.getInt("requestId", 0);
        if (url == null || url.isEmpty()) {
            call.reject("No URL");
            return;
        }
        final Map<String, String> headers = new HashMap<>();
        JSObject h = call.getObject("headers");
        if (h != null) {
            Iterator<String> keys = h.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                String v = h.optString(k, "");
                if (!v.isEmpty()) headers.put(k, v);
            }
        }
        getActivity().runOnUiThread(() -> {
            if (!hasAccess()) { expireAccess(); call.reject("Activate an active subscription first."); return; }
            ++playbackGeneration;
            playbackRequestId = requestId;
            playbackFailed = false;
            vlcTriedUrl = "";
            beginExoDeadline();
            videoVariants = 0;
            if (!url.equals(curUrl)) { clearAudioOverride(); audioAutoSelectedUrl = ""; }
            curTriedModes = 0;
            if (pendingFramePlay != null) pendingFramePlay.resolve();
            pendingFramePlay = call;
            final long generation = playbackGeneration;
            Runnable begin = () -> {
                if (generation != playbackGeneration || playbackFailed || !hasAccess()) {
                    if (pendingFramePlay == call) { pendingFramePlay = null; call.resolve(); }
                    return;
                }
                if (pendingFramePlay == call) pendingFramePlay = null;
                try { startPlayback(url, headers, StreamFormatDetector.AUTO, 0); call.resolve(); }
                catch (RuntimeException | LinkageError error) {
                    failPlayback("Player could not start: " + error.getClass().getSimpleName());
                    call.reject("No signal!");
                }
            };
            if (frameHold != null) frameHold.captureThen(vlcActive && vlc != null ? vlc.videoView() : playerView, begin);
            else begin.run();
        });
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            ++playbackGeneration; ++playbackAttempt;
            playbackFailed = true;
            stopVlc();
            stopPlayback();
            call.resolve();
        });
    }

    /** Movies / series episodes: jump forward or back (seconds). Live channels ignore it. */
    @PluginMethod
    public void seekBy(PluginCall call) {
        final long ms = (long) (call.getDouble("seconds", 10.0) * 1000);
        getActivity().runOnUiThread(() -> {
            if (vlcActive && vlc != null) {
                long[] r = vlc.seekBy(ms);
                if (r != null) {
                    JSObject o = new JSObject();
                    o.put("position", r[0]);
                    o.put("duration", r[1]);
                    call.resolve(o);
                } else call.resolve();
                return;
            }
            if (player != null && player.isCurrentMediaItemSeekable() && !player.isCurrentMediaItemLive()) {
                long target = Math.max(0, player.getCurrentPosition() + ms);
                long dur = player.getDuration();
                if (dur > 0 && target > dur - 1000) target = Math.max(0, dur - 1000);
                player.seekTo(target);
                JSObject r = new JSObject();
                r.put("position", target / 1000);
                r.put("duration", dur > 0 ? dur / 1000 : 0);
                call.resolve(r);
            } else {
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void setResizeMode(PluginCall call) {
        final String mode = call.getString("mode", "fit");
        getActivity().runOnUiThread(() -> {
            if (playerView != null) {
                int m = AspectRatioFrameLayout.RESIZE_MODE_FIT;
                if ("zoom".equals(mode)) m = AspectRatioFrameLayout.RESIZE_MODE_ZOOM;
                else if ("fill".equals(mode)) m = AspectRatioFrameLayout.RESIZE_MODE_FILL;
                playerView.setResizeMode(m);
            }
            call.resolve();
        });
    }

    /** Technical details of the current channel, for the "Info" button. */
    /* ---------- breadcrumbs: remember where the app stopped, even after a crash ---------- */
    private SharedPreferences crumbPrefs() {
        return getContext().getSharedPreferences("tv2u_trace", android.content.Context.MODE_PRIVATE);
    }

    private void writeCrumb(String text) {
        try { crumbPrefs().edit().putString("text", text).commit(); } catch (Throwable ignored) { }
    }

    private void installCrashRecorder() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                StringBuilder sb = new StringBuilder("CRASH in " + thread.getName() + ": " + throwable);
                StackTraceElement[] st = throwable.getStackTrace();
                for (int i = 0; i < st.length && i < 4; i++) sb.append(" | ").append(st[i]);
                writeCrumb(sb.toString());
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread, throwable);
        });
    }

    @PluginMethod
    public void crumb(PluginCall call) {
        writeCrumb(call.getString("text", ""));
        call.resolve();
    }

    @PluginMethod
    public void lastCrumb(PluginCall call) {
        JSObject r = new JSObject();
        r.put("text", crumbPrefs().getString("text", ""));
        call.resolve(r);
    }

    /* ------------------------------------------------------------------
     * Native playlist download (big Xtream / XUI playlists, player-like User-Agents,
     * http <-> https redirects, progress, delivered to the page in small chunks).
     * ------------------------------------------------------------------ */
    private final Map<String, String> downloads = new ConcurrentHashMap<>();
    private int downloadSeq = 0;

    private BigStore bigStore;
    private final java.util.concurrent.atomic.AtomicLong searchRequest = new java.util.concurrent.atomic.AtomicLong();

    private File bigDir() { return new File(getContext().getFilesDir(), "bigstore"); }

    @PluginMethod
    public void fetchStart(final PluginCall call) {
        final String url = call.getString("url");
        final boolean json = "json".equals(call.getString("kind", "playlist"));
        final List<String> uas = new ArrayList<>();
        try {
            org.json.JSONArray arr = call.getData().optJSONArray("userAgents");
            if (arr != null) for (int i = 0; i < arr.length(); i++) uas.add(arr.getString(i));
        } catch (Exception ignored) { }
        if (uas.isEmpty()) uas.add("VLC/3.0.18 LibVLC/3.0.18");
        if (url == null || url.isEmpty()) { call.reject("No URL"); return; }
        new Thread(() -> {
          File tmp = null;
          try {
            tmp = File.createTempFile("tv2u_download_", ".tmp", getContext().getCacheDir());
            final File downloadFile = tmp;
            writeCrumb("Downloading " + url.replaceAll("(?i)(password=)[^&]*", "$1***"));
            String lastErr = "no answer";
            final long fetchDeadline = android.os.SystemClock.elapsedRealtime() + (json ? PLAYLIST_FETCH_BUDGET_MS : 600000);
            final int attemptCount = Math.min(PLAYLIST_UA_ATTEMPTS, uas.size());
            for (int uaIndex = 0; uaIndex < attemptCount; uaIndex++) {
                String ua = uas.get(uaIndex);
                try {
                    long remaining = fetchDeadline - android.os.SystemClock.elapsedRealtime();
                    if (remaining < 1000) { lastErr = "Playlist import timed out. Please check the connection and Reload."; break; }
                    int attemptsLeft = attemptCount - uaIndex;
                    long reserveForNext = Math.max(0, attemptsLeft - 1) * 10000L;
                    long attemptBudget = Math.max(1000, Math.min(json ? 40000 : 480000, remaining - reserveForNext));
                    final String[] finalUrl = new String[1];
                    long size = HttpFetch.toFile(url, ua, downloadFile, bytes -> {
                        JSObject p = new JSObject();
                        p.put("bytes", bytes);
                        notifyListeners("fetchProgress", p);
                    }, attemptBudget, finalUrl);
                    String head = readHead(downloadFile);
                    if (size == 0 || head.isEmpty()) { lastErr = "Server sent an empty reply (account expired, too many connections, or blocked)"; continue; }
                    if (!json && (head.regionMatches(true, 0, "<!doctype", 0, 9) || head.regionMatches(true, 0, "<html", 0, 5))) {
                        lastErr = "Server sent a web page instead of the data: " + head.replaceAll("<[^>]+>", " ").replaceAll("\\s+", " ").trim();
                        if (lastErr.length() > 160) lastErr = lastErr.substring(0, 160);
                        continue;
                    }
                    JSObject r = new JSObject();
                    r.put("userAgent", ua);
                    // Parse channel playlists on this worker thread for every
                    // size. A sub-megabyte M3U can still contain thousands of
                    // channels and freeze the WebView long enough to cause ANR.
                    if (!json && !isHlsManifest(downloadFile)) {
                        writeCrumb("Downloaded " + size + " bytes, building the channel database");
                        bigStore = null;
                        BigStore st = BigStore.build(downloadFile, bigDir(), n -> {
                            JSObject p = new JSObject();
                            p.put("entries", n);
                            notifyListeners("fetchProgress", p);
                        }, finalUrl[0] == null ? url : finalUrl[0]);
                        bigStore = st;
                        r.put("big", true);
                        putBigInfo(r, st);
                    } else {
                        String body = readAll(downloadFile);
                        String id = "d" + (++downloadSeq);
                        downloads.put(id, body);
                        r.put("id", id);
                        r.put("length", body.length());
                        writeCrumb("Downloaded " + body.length() + " characters, now reading the channels");
                    }
                    call.resolve(r);
                    return;
                } catch (java.net.UnknownHostException | java.net.ConnectException | java.net.SocketTimeoutException e) {
                    boolean connectProblem = !(e instanceof java.net.SocketTimeoutException) || String.valueOf(e.getMessage()).toLowerCase().contains("connect");
                    lastErr = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
                    if (connectProblem) break;
                } catch (Exception e) {
                    lastErr = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                }
            }
            if (android.os.SystemClock.elapsedRealtime() >= fetchDeadline)
                lastErr = "Playlist import timed out. Please check the connection and Reload.";
            call.reject(lastErr);
          } catch (Throwable t) {
            call.reject("Download failed: " + t);
          } finally {
            if (tmp != null) tmp.delete();
          }
        }, "tv2u-download").start();
    }

    private static String readAll(File f) throws Exception {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream((int) Math.min(f.length() + 16, 16L << 20));
            byte[] b = new byte[65536];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static String readHead(File f) {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            byte[] b = new byte[4096];
            int n = in.read(b);
            return n <= 0 ? "" : new String(b, 0, n, StandardCharsets.UTF_8).trim();
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean isHlsManifest(File f) {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            byte[] b = new byte[65536];
            int n = in.read(b);
            if (n <= 0) return false;
            String head = new String(b, 0, n, StandardCharsets.UTF_8).toUpperCase(java.util.Locale.ROOT);
            return head.contains("#EXT-X-STREAM-INF")
                    || head.contains("#EXT-X-TARGETDURATION")
                    || head.contains("#EXT-X-MEDIA-SEQUENCE")
                    || head.contains("#EXT-X-I-FRAME-STREAM-INF");
        } catch (Exception ignored) {
            return false;
        }
    }

    private void putBigInfo(JSObject r, BigStore st) throws Exception {
        r.put("total", st.total());
        org.json.JSONArray arr = new org.json.JSONArray();
        for (BigStore.Group g : st.groups()) {
            JSObject o = new JSObject();
            o.put("key", g.key);
            o.put("label", g.label);
            o.put("count", g.count);
            o.put("kind", g.kind);
            arr.put(o);
        }
        r.put("groups", arr);
    }

    /** Re-open the channel database from the last big playlist (after the app was restarted). */
    @PluginMethod
    public void bigOpen(PluginCall call) {
        new Thread(() -> {
            try {
                if (bigStore == null) bigStore = BigStore.open(bigDir());
                JSObject r = new JSObject();
                if (bigStore == null) { r.put("total", 0); call.resolve(r); return; }
                putBigInfo(r, bigStore);
                call.resolve(r);
            } catch (Throwable t) {
                call.reject("Could not open the saved playlist: " + t);
            }
        }, "tv2u-bigopen").start();
    }

    @PluginMethod
    public void bigListPage(final PluginCall call) {
        final BigStore st = bigStore;
        if (st == null) { call.reject("The big playlist is not loaded"); return; }
        final String group = call.getString("group", "all");
        final int offset = call.getInt("offset", 0);
        final int limit = call.getInt("limit", 500);
        new Thread(() -> {
            try {
                BigStore.Page page = st.listPage(group, offset, limit);
                org.json.JSONArray arr = new org.json.JSONArray();
                for (BigStore.Item it : page.items) {
                    JSObject o = new JSObject();
                    o.put("name", it.name);
                    o.put("group", it.group);
                    o.put("url", it.url);
                    o.put("kindHint", it.kindHint);
                    if (!it.ua.isEmpty() || !it.ref.isEmpty()) {
                        JSObject h = new JSObject();
                        if (!it.ua.isEmpty()) h.put("User-Agent", it.ua);
                        if (!it.ref.isEmpty()) h.put("Referer", it.ref);
                        o.put("headers", h);
                    }
                    arr.put(o);
                }
                JSObject r = new JSObject();
                r.put("items", arr);
                r.put("total", page.total);
                call.resolve(r);
            } catch (Throwable t) {
                call.reject("Could not load channels: " + t);
            }
        }, "tv2u-biglist").start();
    }

    /** Import Xtream API entries using disk-backed JSON streaming; no huge JS strings. */
    /** Import Xtream API entries using disk-backed JSON streaming; no huge JS strings. */
    @PluginMethod
    public void xtreamImport(final PluginCall call) {
        final String base=call.getString("base");
        final String user=call.getString("username");
        final String pass=call.getString("password");
        final String output=call.getString("output", "ts");
        if (base==null || user==null || pass==null || user.isEmpty() || pass.isEmpty()) {
            call.reject("Invalid Xtream account"); return;
        }
        new Thread(() -> {
            try {
                BigStore st=XtreamImport.build(base,user,pass,getContext().getCacheDir(),bigDir(), n -> {
                    JSObject p=new JSObject(); p.put("entries",n); notifyListeners("fetchProgress",p);
                },output);
                bigStore=st;
                JSObject result=new JSObject(); result.put("big",true); putBigInfo(result,st);
                call.resolve(result);
            } catch (Exception e) {
                String detail=e.getClass().getSimpleName();
                for (Throwable cause=e; cause!=null; cause=cause.getCause()) {
                    java.util.regex.Matcher status=java.util.regex.Pattern.compile("HTTP [0-9]{3}").matcher(String.valueOf(cause.getMessage()));
                    if (status.find()) { detail=status.group(); break; }
                    if (cause instanceof java.net.SocketTimeoutException) detail="connection timed out";
                    else if (cause instanceof java.net.UnknownHostException) detail="server name could not be resolved";
                    else if (cause instanceof javax.net.ssl.SSLException) detail="TLS connection failed";
                }
                call.reject("Could not load the complete Live TV / Movies / Series catalogue ("+detail+"). Please Reload; no incomplete catalogue was saved.");
            }
        }, "tv2u-xtream-import").start();
    }

    @PluginMethod
    public void xtreamSeries(final PluginCall call) {
        final String base=call.getString("base"),user=call.getString("username"),pass=call.getString("password"),id=call.getString("seriesId"),name=call.getString("name", "Series");
        if(base==null||user==null||pass==null||id==null){call.reject("Invalid series account");return;}
        new Thread(()->{
            try{
                org.json.JSONArray rows=new org.json.JSONArray();
                for(BigStore.Item it:XtreamSeries.load(base,user,pass,id,name,getContext().getCacheDir())){
                    JSObject o=new JSObject();o.put("name",it.name);o.put("group",it.group);o.put("url",it.url);o.put("kindHint","series");rows.put(o);
                }
                JSObject result=new JSObject();result.put("items",rows);call.resolve(result);
            }catch(Exception e){call.reject("Could not load this series. Please try again.");}
        },"tv2u-series-info").start();
    }

    /** Compatibility endpoint: category names must never override per-stream types. */
    @PluginMethod
    public void xtreamClassify(final PluginCall call) {
        final BigStore current = bigStore;
        if (current == null) { call.reject("Playlist index is not loaded"); return; }
        try {
            JSObject result = new JSObject(); result.put("big", true); putBigInfo(result, current);
            call.resolve(result);
        } catch (Exception e) { call.reject("Could not read playlist types"); }
    }

    /** Android TV speech recognition via the system voice-input activity. */
    @PluginMethod
    public void voiceSearch(final PluginCall call) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a channel name / চ্যানেলের নাম বলুন");
        try {
            startActivityForResult(call, intent, "voiceSearchResult");
        } catch (ActivityNotFoundException e) {
            call.reject("No speech recognition service is installed on this TV");
        } catch (Exception e) {
            call.reject("Unable to start voice recognition: " + e.getMessage());
        }
    }

    @ActivityCallback
    private void voiceSearchResult(PluginCall call, androidx.activity.result.ActivityResult result) {
        if (call == null) return;
        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null) {
            call.reject("Voice search cancelled or unavailable");
            return;
        }
        ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (matches == null || matches.isEmpty()) {
            call.reject("No speech was recognized");
            return;
        }
        JSObject response = new JSObject();
        response.put("text", matches.get(0));
        org.json.JSONArray alternatives = new org.json.JSONArray();
        for (int i = 0; i < Math.min(5, matches.size()); i++) alternatives.put(matches.get(i));
        response.put("alternatives", alternatives);
        call.resolve(response);
    }

    @PluginMethod
    public void bigSearchPage(final PluginCall call) {
        final BigStore st = bigStore;
        if (st == null) { call.reject("The big playlist is not loaded"); return; }
        final String query = call.getString("query", "");
        final int offset = call.getInt("offset", 0);
        final long request = searchRequest.incrementAndGet();
        new Thread(() -> {
            try {
                BigStore.Page page = st.searchPage(query, offset, 100, () -> searchRequest.get() != request);
                org.json.JSONArray arr = new org.json.JSONArray();
                for (BigStore.Item it : page.items) {
                    JSObject o = new JSObject();
                    o.put("name", it.name); o.put("group", it.group); o.put("url", it.url);
                    o.put("kindHint", it.kindHint);
                    if (!it.ua.isEmpty() || !it.ref.isEmpty()) {
                        JSObject h = new JSObject();
                        if (!it.ua.isEmpty()) h.put("User-Agent", it.ua);
                        if (!it.ref.isEmpty()) h.put("Referer", it.ref);
                        o.put("headers", h);
                    }
                    arr.put(o);
                }
                JSObject r = new JSObject(); r.put("items", arr); r.put("total", page.total);
                call.resolve(r);
            } catch (Throwable t) { call.reject("Search failed: " + t); }
        }, "tv2u-search").start();
    }

    @PluginMethod
    public void bigClear(PluginCall call) {
        bigStore = null;
        BigStore.deleteDir(bigDir());
        call.resolve();
    }

    @PluginMethod
    public void fetchRead(PluginCall call) {
        String id = call.getString("id");
        String text = id == null ? null : downloads.get(id);
        if (text == null) { call.reject("Download expired"); return; }
        int offset = call.getInt("offset", 0);
        int length = call.getInt("length", 400000);
        int end = Math.min(text.length(), offset + length);
        JSObject r = new JSObject();
        r.put("text", offset >= text.length() ? "" : text.substring(offset, end));
        r.put("done", end >= text.length());
        call.resolve(r);
    }

    @PluginMethod
    public void fetchDone(PluginCall call) {
        String id = call.getString("id");
        if (id != null) downloads.remove(id);
        call.resolve();
    }

    @PluginMethod
    public void isTv(PluginCall call) {
        android.app.UiModeManager um = (android.app.UiModeManager) getContext().getSystemService(android.content.Context.UI_MODE_SERVICE);
        JSObject r = new JSObject();
        r.put("tv", um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION);
        call.resolve(r);
    }

    @PluginMethod
    public void info(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            StringBuilder sb = new StringBuilder();
            if (vlcActive && vlc != null) {
                sb.append(vlc.describe());
            } else if (player == null) {
                sb.append("Nothing is playing.");
            } else {
                sb.append("State: ").append(stateName(player.getPlaybackState()));
                Format vf = player.getVideoFormat();
                Format af = player.getAudioFormat();
                sb.append("\nPicture: ").append(vf == null ? "none is being shown" : describeFormat(vf));
                sb.append("\nSound: ").append(af == null ? "none is being played" : describeFormat(af));
                if (!videoDecoder.isEmpty()) sb.append("\nPicture decoder: ").append(videoDecoder);
                androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
                if (dc != null) {
                    dc.ensureUpdated();
                    sb.append("\nFrames shown: ").append(dc.renderedOutputBufferCount).append(", dropped: ").append(dc.droppedBufferCount);
                }
                long bps = androidx.media3.exoplayer.upstream.DefaultBandwidthMeter.getSingletonInstance(getContext()).getBitrateEstimate();
                if (bps > 0) sb.append("\nConnection speed: about ").append(String.format(java.util.Locale.US, "%.1f", bps / 1000000.0)).append(" Mbit/s");
                sb.append("\nBuffered ahead: ").append(String.format(java.util.Locale.US, "%.1f", player.getTotalBufferedDuration() / 1000.0)).append(" s");
                if (!tracksSummary.isEmpty()) sb.append("\nStream contains: ").append(tracksSummary);
            }
            sb.append("\nPlayback phase: ").append(playbackPhase);
            long deadline = activeExoDeadline();
            if (!vlcActive && deadline != Long.MAX_VALUE)
                sb.append("\nNative fallback deadline: ").append(Math.max(0, deadline - playbackNow()) / 1000.0).append(" s");
            if (!lastError.isEmpty()) sb.append("\nLast problem: Playback unavailable. Please try again.");
            JSObject o = new JSObject();
            o.put("text", sb.toString());
            call.resolve(o);
        });
    }

    /** Must run on the main thread. */
    // The request being played right now (the shared listener reads these when it has to retry).
    private String curUrl = "";
    private Map<String, String> curHeaders = new HashMap<>();
    private int curSourceMode = StreamFormatDetector.AUTO;
    private int curTriedModes = 0;
    private StreamFormatDetector curStreamDetector = new StreamFormatDetector();
    private int curUaIndex = 0;
    private boolean curUaFixed = false;
    private DefaultTrackSelector trackSelector;
    private boolean strictTracks = false;
    private int videoVariants = 0;

    /* ---------- recording ---------- */
    /** Receives a copy of the downloaded stream while a recording is running; ignores playlists / text. */
    private static final class RecordSink implements DataSink {
        private java.io.OutputStream out;
        private boolean first, accept;
        private long bytes;

        synchronized void begin(File f) throws java.io.IOException {
            out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(f), 1 << 16);
            bytes = 0;
        }
        synchronized long end() throws java.io.IOException {
            java.io.OutputStream o = out;
            out = null;
            if (o != null) { o.flush(); o.close(); }
            return bytes;
        }
        synchronized boolean active() { return out != null; }
        @Override public synchronized void open(DataSpec dataSpec) { first = true; accept = false; }
        @Override public synchronized void write(byte[] buffer, int offset, int length) throws java.io.IOException {
            if (out == null || length <= 0) return;
            if (first) {
                first = false;
                int c = buffer[offset] & 0xFF;
                accept = !(c == 0x23 || c == 0x3C || c == 0x7B || c == 0xEF || c == 0x20 || c == 0x0D || c == 0x0A || c == 0x09); // any media (TS, MP4, audio...), but not text such as #EXTM3U playlists, xml or json
            }
            if (accept) { out.write(buffer, offset, length); bytes += length; }
        }
        @Override public void close() { }
    }

    private final RecordSink recSink = new RecordSink();
    private boolean recording = false, recViaVlc = false, recVideo = true;
    private volatile boolean savingRecording = false;
    private String recName = "channel";
    private File recFile, recDir;
    private long recStartMs;

    @PluginMethod
    public void recordStart(final PluginCall call) {
        final String mode = "video"; // always picture + sound together
        final String name = call.getString("name", "channel");
        getActivity().runOnUiThread(() -> {
            if (!hasAccess()) { call.reject("Subscription is inactive."); return; }
            if (recording) { call.reject("Already recording."); return; }
            if (savingRecording) { call.reject("The previous recording is still being saved."); return; }
            boolean playingNow = vlcActive || (player != null && player.getPlaybackState() != Player.STATE_IDLE);
            if (curUrl.isEmpty() || !playingNow) { call.reject("Nothing is playing yet."); return; }
            try {
                File dir = new File(getContext().getCacheDir(), "rec");
                dir.mkdirs();
                File[] old = dir.listFiles();
                if (old != null) for (File f : old) f.delete();
                recVideo = "video".equals(mode);
                recName = name;
                recDir = dir;
                recStartMs = System.currentTimeMillis();
                if (vlcActive && vlc != null) {
                    if (!vlc.startRecord(dir.getAbsolutePath())) { call.reject("Recording is not possible with this player for this channel."); return; }
                    recViaVlc = true;
                    recFile = null;
                } else {
                    recFile = new File(dir, "rec_" + recStartMs + ".ts");
                    recSink.begin(recFile);
                    recViaVlc = false;
                }
                recording = true;
                call.resolve();
            } catch (Throwable t) {
                call.reject("Could not start recording: " + t);
            }
        });
    }

    @PluginMethod
    public void recordStop(final PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if (!recording) { call.resolve(new JSObject()); return; }
            savingRecording = true;
            recording = false;
            File ts = recFile;
            try {
                if (recViaVlc) {
                    if (vlc != null) vlc.stopRecord();
                    ts = newestIn(recDir, recStartMs);
                } else {
                    recSink.end();
                }
            } catch (Throwable ignored) { }
            final File captured = ts;
            final boolean video = recVideo;
            // Millisecond suffix avoids overwriting two recordings from the same minute.
            final String base = new java.text.SimpleDateFormat("dd-MM-yy_HH-mm-ss-SSS", java.util.Locale.getDefault()).format(new java.util.Date(recStartMs));
            new Thread(() -> {
                try {
                    RecordingSaver.Result r = RecordingSaver.save(getContext(), captured, video, base);
                    if (r.error.isEmpty()) try { if (captured != null) captured.delete(); } catch (Throwable ignored) { }
                    JSObject o = new JSObject();
                    o.put("path", r.path);
                    o.put("note", r.note);
                    o.put("error", r.error);
                    call.resolve(o);
                } catch (Throwable error) {
                    call.reject("Could not save recording: " + error.getClass().getSimpleName());
                } finally { savingRecording = false; }
            }, "tv2u-save").start();
        });
    }

    private static File newestIn(File dir, long sinceMs) {
        File best = null;
        File[] list = dir == null ? null : dir.listFiles();
        if (list == null) return null;
        for (File f : list) {
            if (f.isFile() && f.lastModified() >= sinceMs - 2000 && (best == null || f.lastModified() > best.lastModified())) best = f;
        }
        return best;
    }

    private static String safeName(String s) {
        String t = (s == null ? "channel" : s).replaceAll("[^A-Za-z0-9._-]+", "_").replaceAll("^_+|_+$", "");
        if (t.isEmpty()) t = "channel";
        return t.length() > 40 ? t.substring(0, 40) : t;
    }

    /* ---------- audio tracks (languages): reported to the page, chosen from its wizard ---------- */
    private final List<Tracks.Group> audioGroups = new ArrayList<>();
    private final List<Integer> audioIdx = new ArrayList<>();
    private String audioAutoSelectedUrl = "";

    /** Lists every audio track of the current channel: {id, lang, label, channels, selected, supported}. */
    private org.json.JSONArray buildAudioList(Tracks tracks) {
        audioGroups.clear();
        audioIdx.clear();
        org.json.JSONArray arr = new org.json.JSONArray();
        // Present tracks in this order: stereo (2ch), 5.1 (6ch), then all other layouts.
        // Keep the mapping used by setAudioTrack() in the same sorted order.
        for (int pass = 0; pass < 3; pass++) {
            for (Tracks.Group g : tracks.getGroups()) {
                if (g.getType() != C.TRACK_TYPE_AUDIO) continue;
                for (int i = 0; i < g.length; i++) {
                    Format f = g.getTrackFormat(i);
                    int ch = f.channelCount;
                    int priority = audioPriority(f);
                    if (priority != pass) continue;
                    audioGroups.add(g);
                    audioIdx.add(i);
                    JSObject o = new JSObject();
                    o.put("id", audioGroups.size() - 1);
                    o.put("lang", f.language == null ? "" : f.language);
                    o.put("label", f.label == null ? "" : f.label);
                    o.put("channels", ch);
                    o.put("selected", g.isTrackSelected(i));
                    o.put("supported", g.isTrackSupported(i));
                    arr.put(o);
                }
            }
        }
        return arr;
    }

    /** Classify audio using channel metadata first, then descriptive labels when metadata is absent. */
    private static int audioPriority(Format f) {
        if (f == null) return 2;
        int ch = f.channelCount;
        String text = ((f.label == null ? "" : f.label) + " " + (f.language == null ? "" : f.language))
                .toLowerCase(java.util.Locale.ROOT);
        if (ch == 2 || text.contains("stereo") || text.contains("2.0") || text.contains("2-channel") || text.contains("2 channel") || text.contains("2ch")) return 0;
        if (ch == 6 || text.contains("5.1") || text.contains("6-channel") || text.contains("6 channel") || text.contains("6ch") || text.contains("surround")) return 1;
        return 2;
    }

    /** Prefer a supported stereo track at startup; if none exists, prefer 5.1, then any supported track. */
    private void selectPreferredStartupAudio(Tracks tracks) {
        if (curUrl.isEmpty() || curUrl.equals(audioAutoSelectedUrl) || trackSelector == null) return;
        int preferredId = -1;
        int fallbackId = -1;
        // buildAudioList() must run first so these IDs match the order shown to the user.
        for (int id = 0; id < audioGroups.size(); id++) {
            Tracks.Group g = audioGroups.get(id);
            int i = audioIdx.get(id);
            if (!g.isTrackSupported(i)) continue;
            Format format = g.getTrackFormat(i);
            int priority = audioPriority(format);
            if (priority == 0) { preferredId = id; break; }
            if (fallbackId < 0 || priority < audioPriority(audioGroups.get(fallbackId).getTrackFormat(audioIdx.get(fallbackId)))) fallbackId = id;
        }
        // IMPORTANT: do not mark this URL as handled until a real supported audio track
        // was found and an override was applied. On Fire TV/HLS, the first onTracksChanged
        // callback can contain no audio tracks; marking the URL then would permanently skip
        // the later callback where the stereo renditions become available.
        int chosenId = preferredId >= 0 ? preferredId : fallbackId;
        if (chosenId >= 0 && selectExoAudio(chosenId)) {
            // Set after applying the override to prevent recursive onTracksChanged loops.
            audioAutoSelectedUrl = curUrl;
        }
    }

    private void emitAudioList(org.json.JSONArray list) {
        JSObject o = new JSObject();
        o.put("tracks", list);
        notifyListeners("audioTracks", o);
    }

    private boolean selectExoAudio(int id) {
        if (trackSelector == null || id < 0 || id >= audioGroups.size()) return false;
        Tracks.Group g = audioGroups.get(id);
        int ti = audioIdx.get(id);
        trackSelector.setParameters(trackSelector.buildUponParameters()
                .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                .setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), ti)));
        return true;
    }

    private void clearAudioOverride() {
        if (trackSelector == null) return;
        trackSelector.setParameters(trackSelector.buildUponParameters()
                .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                .setMaxAudioChannelCount(2));
    }

    /** Per-UID receive counters include both Exo and native VLC sockets. No probe download. */
    @PluginMethod
    public void getNetworkTraffic(PluginCall call) {
        JSObject result = new JSObject();
        long received = android.net.TrafficStats.getUidRxBytes(android.os.Process.myUid());
        result.put("supported", received != android.net.TrafficStats.UNSUPPORTED && received >= 0);
        result.put("receivedBytes", received);
        result.put("elapsedMs", android.os.SystemClock.elapsedRealtime());
        call.resolve(result);
    }

    /** The page's wizard chose an audio track (id from the list it received). */
    @PluginMethod
    public void setAudioTrack(PluginCall call) {
        final int id = call.getInt("id", -1);
        getActivity().runOnUiThread(() -> {
            boolean ok;
            if (vlcActive && vlc != null) {
                ok = vlc.setAudio(id);
            } else {
                // A manual choice must be allowed to select 5.1 or another layout.
                // Startup is stereo-first, but the user's explicit choice wins.
                if (trackSelector != null) {
                    trackSelector.setParameters(trackSelector.buildUponParameters()
                            .setMaxAudioChannelCount(Integer.MAX_VALUE));
                }
                ok = selectExoAudio(id);
            }
            JSObject r = new JSObject();
            r.put("ok", ok);
            call.resolve(r);
        });
    }

    /* ---------- VLC engine: second player when ExoPlayer cannot play a channel ---------- */
    private String vlcTriedUrl = "";
    private ViewGroup videoParent;

    /** Posted format/UA retries belong to one attempt, never a newly selected channel. */
    private void postPlaybackRetry(Runnable action) {
        final long generation = playbackGeneration, attempt = playbackAttempt;
        main.post(() -> {
            if (generation != playbackGeneration || attempt != playbackAttempt || playbackFailed || vlcActive || !hasAccess()) return;
            try { action.run(); }
            catch (RuntimeException | LinkageError error) { failPlayback("Player retry failed: " + error.getClass().getSimpleName()); }
        });
    }

    private void focusPlayerUi() {
        WebView web = getBridge().getWebView();
        if (web != null) { web.setFocusable(true); web.setFocusableInTouchMode(true); web.requestFocus(); }
    }

    private void failPlayback(String message) {
        ++playbackGeneration; ++playbackAttempt;
        playbackFailed = true;
        lastError = message;
        playbackPhase = "Failed";
        main.removeCallbacks(stallWatchdog);
        stopVlc();
        try { stopPlayback(); } catch (RuntimeException ignored) { }
        focusPlayerUi();
        emit("error", message);
    }

    @PluginMethod
    public void tryFallback(PluginCall call) {
        final int requestId = call.getInt("requestId", 0);
        getActivity().runOnUiThread(() -> {
            JSObject result = new JSObject();
            result.put("started", requestId == playbackRequestId && hasAccess() && !playbackFailed
                    && (vlcActive || tryVlc("ExoPlayer startup/buffering deadline reached.")));
            call.resolve(result);
        });
    }

    private long playbackNow() { return android.os.SystemClock.elapsedRealtime(); }

    private long activeExoDeadline() {
        long deadline = Long.MAX_VALUE;
        if (exoStartupDeadline > 0) deadline = Math.min(deadline, exoStartupDeadline);
        if (exoFrameDeadline > 0) deadline = Math.min(deadline, exoFrameDeadline);
        if (exoStallDeadline > 0) deadline = Math.min(deadline, exoStallDeadline);
        return deadline;
    }

    private void clearExoDeadlines() {
        exoStartupDeadline = exoFrameDeadline = exoStallDeadline = 0;
        main.removeCallbacks(videoStartupWatchdog);
    }

    private void beginExoDeadline() {
        clearExoDeadlines();
        exoStartupDeadline = playbackNow() + 7000;
        exoStallFrames = -1;
        exoStallPosition = 0;
        exoDroppedFrames = 0;
        exoQualityFrames = Math.max(0, exoRenderedFrames());
    }

    private boolean exoHasVideo() { return !videoMime.isEmpty() || (player != null && player.getVideoFormat() != null); }

    private long exoRenderedFrames() {
        if (player == null) return -1;
        androidx.media3.exoplayer.DecoderCounters counters = player.getVideoDecoderCounters();
        if (counters == null) return -1;
        counters.ensureUpdated();
        return counters.renderedOutputBufferCount;
    }

    private void armExoDeadlineCheck() {
        main.removeCallbacks(videoStartupWatchdog);
        long deadline = activeExoDeadline();
        if (deadline != Long.MAX_VALUE && player != null && !playbackFailed && !vlcActive && hasAccess())
            main.postDelayed(videoStartupWatchdog, Math.max(1, Math.min(1000, deadline - playbackNow())));
    }

    private void beginExoBuffering() {
        if (exoStartupDeadline == 0 && exoFrameDeadline == 0 && exoStallDeadline == 0) {
            exoStallDeadline = playbackNow() + 7000;
            exoStallFrames = exoRenderedFrames();
            exoStallPosition = player == null ? 0 : player.getCurrentPosition();
            exoDroppedFrames = 0;
            exoQualityFrames = Math.max(0, exoStallFrames);
        }
        playbackPhase = "ExoPlayer buffering";
        emit("buffering", null);
        armExoDeadlineCheck();
    }

    private void finishExoProgress() {
        if (player == null || playbackFailed || vlcActive || !hasAccess()) return;
        clearExoDeadlines();
        playbackPhase = "ExoPlayer playing";
        if (lastError.startsWith("No picture after ")) lastError = "";
        JSObject playing = new JSObject();
        playing.put("state", "playing");
        playing.put("requestId", playbackRequestId);
        playing.put("vod", player.isCurrentMediaItemSeekable() && !player.isCurrentMediaItemLive() && player.getDuration() > 60000);
        notifyListeners("state", playing);
    }

    private void handleExoReady() {
        if (!player.getPlayWhenReady()) { rearmVideoStartupWatchdog(); return; }
        if (exoHasVideo()) {
            if (!exoRenderedFrame) {
                // First READY starts this clock once, even if READY/BUFFERING flaps.
                if (exoFrameDeadline == 0) exoFrameDeadline = playbackNow() + 10000;
                exoStartupDeadline = 0;
                playbackPhase = "ExoPlayer ready; waiting for first video frame";
                emit("buffering", null);
                armExoDeadlineCheck();
            } else if (exoStallDeadline > 0 || exoStartupDeadline > 0) {
                checkExoDeadline();
            } else finishExoProgress();
        } else if (player.getAudioFormat() != null) {
            clearFrameHold();
            finishExoProgress(); // audio-only: no video frame is expected
        } else {
            playbackPhase = "ExoPlayer ready; waiting for media";
            emit("buffering", null);
            armExoDeadlineCheck();
        }
    }

    private void observeExoDrops(int droppedFrames) {
        if (player == null || playbackFailed || vlcActive || !hasAccess()
                || !player.getPlayWhenReady() || !exoRenderedFrame || droppedFrames <= 0) return;
        long shown = exoRenderedFrames();
        if (shown < 0) return;
        if (shown < exoQualityFrames) exoQualityFrames = 0;
        exoDroppedFrames += droppedFrames;
        if (exoDroppedFrames < 120) return;
        long rendered = Math.max(0, shown - exoQualityFrames);
        if (rendered * 20 < exoDroppedFrames) {
            // Evidence-driven handoff: >95% of this observed frame window was dropped.
            // No elapsed-time wait is required once unusable decoding is observed.
            postPlaybackRetry(() -> {
                String why = "ExoPlayer dropped over 95% of at least 120 observed video frames.";
                if (!tryVlc(why)) failPlayback(why);
            });
        } else {
            exoDroppedFrames = 0;
            exoQualityFrames = shown;
        }
    }

    private void checkExoDeadline() {
        if (player == null || playbackFailed || vlcActive || !hasAccess() || !player.getPlayWhenReady()) return;
        if (player.getPlaybackState() == Player.STATE_READY) {
            if (!exoHasVideo() && player.getAudioFormat() != null) { finishExoProgress(); return; }
            if (exoRenderedFrame && exoStallDeadline > 0) {
                long frames = exoRenderedFrames();
                long position = player.getCurrentPosition();
                if (frames >= 0 && frames < exoStallFrames) exoStallFrames = 0; // decoder counter reset
                if (position < exoStallPosition) exoStallPosition = position; // live-window/seek discontinuity
                long elapsed = Math.max(0, playbackNow() - (exoStallDeadline - 7000));
                Format format = player.getVideoFormat();
                float fps = format == null ? -1 : format.frameRate;
                double minimumFps = fps > 0 ? Math.min(5.0, Math.max(0.5, fps / 2.0)) : 5.0;
                long requiredFrames = Math.max(2, (long) Math.ceil(elapsed * minimumFps / 1000.0));
                boolean progress = exoHasVideo() && frames >= 0
                        ? frames - exoStallFrames >= requiredFrames && position - exoStallPosition >= 1000
                        : position - exoStallPosition >= 1000;
                if (progress) { finishExoProgress(); return; }
            }
        }
        long deadline = activeExoDeadline();
        if (deadline == Long.MAX_VALUE) return;
        if (playbackNow() >= deadline) {
            String why = deadline == exoFrameDeadline
                    ? "ExoPlayer produced no first video frame within 10 seconds of READY."
                    : "ExoPlayer startup/buffering made no playback progress within 7 seconds.";
            clearExoDeadlines();
            if (!tryVlc(why)) failPlayback(lastError.isEmpty() ? why : lastError);
            return;
        }
        armExoDeadlineCheck();
    }

    private void rearmVideoStartupWatchdog() {
        if (player == null || !player.getPlayWhenReady()) {
            clearExoDeadlines();
            playbackPhase = "ExoPlayer paused";
            emit("paused", null);
            return;
        }
        if (!playbackFailed && !vlcActive) {
            if (activeExoDeadline() == Long.MAX_VALUE) {
                if (!exoRenderedFrame) beginExoDeadline();
                else beginExoBuffering();
            }
            if (player.getPlaybackState() == Player.STATE_READY) handleExoReady();
            else beginExoBuffering();
            armExoDeadlineCheck();
        }
    }

    private void handleExoEnded(boolean vod) {
        clearExoDeadlines();
        main.removeCallbacks(stallWatchdog);
        playbackPhase = "ExoPlayer ended";
        if (!vod && tryVlc("ExoPlayer live stream ended unexpectedly.")) return;
        emit("ended", null);
    }

    private boolean tryVlc(String why) {
        if (playbackFailed || !hasAccess() || videoParent == null || curUrl.isEmpty() || curUrl.equals(vlcTriedUrl)) return false;
        vlcTriedUrl = curUrl;
        ++playbackAttempt; // cancel any sibling ExoPlayer retries already queued
        vlcActive = true; // claim handoff before releasing Exo; release can emit callbacks
        try {
            if (vlc == null) vlc = new VlcFallback(getContext(), videoParent);
            // Release the first decoder before opening a second one on low-memory TV boxes.
            releasePlayer();
            main.removeCallbacks(stallWatchdog);
            if (playerView != null) playerView.setVisibility(android.view.View.GONE);
            // VLC creates a new native video surface. Keep the transparent WebView as the
            // input target so TV remote keys continue reaching the JavaScript UI.
            WebView web = getBridge().getWebView();
            if (web != null) { web.setFocusable(true); web.setFocusableInTouchMode(true); web.requestFocus(); }
            lastError = "ExoPlayer: " + why;
            String ua = USER_AGENTS[Math.min(curUaIndex, USER_AGENTS.length - 1)];
            for (Map.Entry<String, String> e : curHeaders.entrySet()) if ("user-agent".equalsIgnoreCase(e.getKey())) ua = e.getValue();
            playbackPhase = "VLC waiting for decoder cleanup";
            emit("fallback-queued", null);
            final long generation = playbackGeneration;
            vlc.start(curUrl, ua, curHeaders, new VlcFallback.Listener() {
                private boolean current() { return generation == playbackGeneration && vlcActive && !playbackFailed; }
                @Override public void onStarting() { if (current()) { playbackPhase = "VLC starting"; emit("fallback-starting", null); } }
                @Override public void onAudio(org.json.JSONArray tracks) { if (current()) emitAudioList(tracks); }
                @Override public void onFirstFrame() { if (current()) clearFrameHold(); }
                @Override public void onPlaying(boolean vod) {
                    if (!current()) return;
                    playbackPhase = "VLC playing";
                    JSObject o = new JSObject();
                    o.put("state", "playing");
                    o.put("requestId", playbackRequestId);
                    o.put("vod", vod);
                    notifyListeners("state", o);
                }
                @Override public void onBuffering() { if (current()) { playbackPhase = "VLC buffering"; emit("buffering", null); } }
                @Override public void onError() {
                    if (!current()) return;
                    String msg = "Neither player could play this channel. " + lastError;
                    failPlayback(msg);
                }
                @Override public void onEnded() { if (current()) { playbackPhase = "VLC ended"; emit("ended", null); } }
            });
            return true;
        } catch (Throwable t) {
            vlcActive = false;
            if (playerView != null) playerView.setVisibility(android.view.View.VISIBLE);
            lastError = why + " | VLC could not start: " + t;
            return false;
        }
    }

    private void stopVlc() {
        vlcActive = false;
        if (vlc != null) vlc.release(); // also cancel a queued start during async cleanup
        if (playerView != null) playerView.setVisibility(android.view.View.VISIBLE);
    }

    /** Strict: never pick a picture/sound track this device cannot decode (plays the rest, e.g. sound only for 4K HEVC on a weak box). */
    private void setStrictTracks(boolean strict) {
        strictTracks = strict;
        if (trackSelector == null) return;
        trackSelector.setParameters(trackSelector.buildUponParameters()
                .setExceedRendererCapabilitiesIfNecessary(!strict)
                .setExceedVideoConstraintsIfNecessary(!strict));
    }

    private static final class InspectingDataSource implements DataSource {
        private final DataSource delegate;
        private final StreamFormatDetector detector;
        private final byte[] prefix = new byte[1024];
        private int prefixLength;
        InspectingDataSource(DataSource delegate, StreamFormatDetector detector) {
            this.delegate=delegate; this.detector=detector;
        }
        @Override public void addTransferListener(androidx.media3.datasource.TransferListener listener) {
            delegate.addTransferListener(listener);
        }
        @Override public long open(DataSpec spec) throws java.io.IOException {
            prefixLength=0;
            long size=delegate.open(spec);
            if(size==0)detector.observeEmpty();
            return size;
        }
        @Override public int read(byte[] buffer,int offset,int length) throws java.io.IOException {
            int count=delegate.read(buffer,offset,length);
            if(count>0 && prefixLength<prefix.length) {
                int copy=Math.min(count,prefix.length-prefixLength);
                System.arraycopy(buffer,offset,prefix,prefixLength,copy);
                prefixLength+=copy;
                detector.observe(prefix,prefixLength);
            } else if(count == C.RESULT_END_OF_INPUT && prefixLength == 0) {
                detector.observeEmpty();
            }
            return count;
        }
        @Override public android.net.Uri getUri() { return delegate.getUri(); }
        @Override public Map<String,List<String>> getResponseHeaders() { return delegate.getResponseHeaders(); }
        @Override public void close() throws java.io.IOException { delegate.close(); }
    }

    private void startPlayback(final String url, final Map<String, String> headers, final int sourceMode, final int uaIndex) {
        if (!hasAccess()) { expireAccess(); return; }
        if (playerView == null) return;
        ++playbackAttempt;
        playbackPhase = "ExoPlayer starting";
        main.removeCallbacks(videoStartupWatchdog);
        exoRenderedFrame = false;
        stopVlc();
        tracksSummary = "";
        lastError = "";
        videoUnsupported = false;
        audioUnsupported = false;
        videoMime = "";
        audioMime = "";
        videoDecoder = "";

        String ua = USER_AGENTS[Math.min(uaIndex, USER_AGENTS.length - 1)];
        boolean uaFromPlaylist = false;
        Map<String, String> props = new HashMap<>();
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if ("user-agent".equalsIgnoreCase(e.getKey())) {
                ua = e.getValue();
                uaFromPlaylist = true;
            } else {
                props.put(e.getKey(), e.getValue());
            }
        }
        curUrl = url;
        curHeaders = headers;
        curSourceMode = sourceMode;
        curTriedModes |= (1 << sourceMode);
        final StreamFormatDetector detector = new StreamFormatDetector();
        curStreamDetector = detector;
        curUaIndex = uaIndex;
        curUaFixed = uaFromPlaylist;

        // OkHttp is faster and steadier than the built-in HTTP stack (connection reuse, HTTP/2, http <-> https redirects).
        okhttp3.OkHttpClient client = new okhttp3.OkHttpClient.Builder()
                .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(40, java.util.concurrent.TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .retryOnConnectionFailure(true)
                .build();
        OkHttpDataSource.Factory http = new OkHttpDataSource.Factory(client)
                .setUserAgent(ua)
                .setDefaultRequestProperties(props);

        // Live MPEG-TS often lacks clean keyframe markers; these flags make it start reliably.
        DefaultExtractorsFactory extractors = new DefaultExtractorsFactory()
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
                        | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS);

        // While recording, every byte that is downloaded for playback is also written to the recording file
        // (no second connection to the server).
        final DataSource.Factory baseFactory = new DefaultDataSource.Factory(getContext(), http);
        final DataSource.Factory teeFactory = () -> new TeeDataSource(
                new InspectingDataSource(baseFactory.createDataSource(), detector), recSink);
        DefaultMediaSourceFactory sources = new DefaultMediaSourceFactory(teeFactory, extractors)
                .setLoadErrorHandlingPolicy(new DefaultLoadErrorHandlingPolicy(3));

        // One player is kept for the whole session: changing channel only swaps the media (much faster than rebuilding).
        final ExoPlayer exo = ensurePlayer();
        MediaItem.Builder item = new MediaItem.Builder().setUri(url)
                .setMediaId(playbackGeneration + "/" + playbackAttempt);
        if (sourceMode == StreamFormatDetector.HLS) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        if (sourceMode == StreamFormatDetector.DASH) item.setMimeType(MimeTypes.APPLICATION_MPD);
        setStrictTracks(false); // every new channel first tries everything the stream offers
        if (sourceMode == StreamFormatDetector.PROGRESSIVE)
            exo.setMediaSource(new ProgressiveMediaSource.Factory(teeFactory, extractors).createMediaSource(item.build()), true);
        else exo.setMediaSource(sources.createMediaSource(item.build()), true);
        exo.setPlayWhenReady(true);
        exo.prepare();
        main.removeCallbacks(stallWatchdog);
        main.postDelayed(stallWatchdog, STALL_MS);
        armExoDeadlineCheck();
    }


    

    private ExoPlayer ensurePlayer() {
        if (player != null) return player;

        // One Exo decoder attempt; independent VLC owns decoder fallback.
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(getContext())
                .setEnableDecoderFallback(false)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON);

        // Start playing after a very short buffer so channel changes feel instant.
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                // Starts quickly (0.8 s) but keeps a healthy cushion (up to 50 s) so Full HD / 4K streams do not stutter.
                .setBufferDurationsMs(5000, 20000, 800, 2000)
                // Keep native + Java memory use bounded on Android TV boxes, especially during 4K playback.
                .setTargetBufferBytes(16 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .build();

        trackSelector = new DefaultTrackSelector(getContext());
        // Startup policy: cap the default audio selection at stereo (2 channels).
        // This is stronger than sorting the UI list: it constrains ExoPlayer itself
        // while a channel starts. Explicit user selections lift the cap below.
        trackSelector.setParameters(trackSelector.buildUponParameters()
                .setMaxAudioChannelCount(2));
        final ExoPlayer exo = new ExoPlayer.Builder(getContext(), renderers)
                .setTrackSelector(trackSelector)
                .setLoadControl(loadControl)
                .build();
        player = exo;

        exo.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(), true);

        exo.addAnalyticsListener(new androidx.media3.exoplayer.analytics.AnalyticsListener() {
            @Override public void onRenderedFirstFrame(EventTime eventTime, Object output, long renderTimeMs) {
                if (pendingFramePlay != null || exo != player || playbackFailed || vlcActive || eventTime.timeline.isEmpty()) return;
                androidx.media3.common.Timeline.Window window = new androidx.media3.common.Timeline.Window();
                if (eventTime.windowIndex < 0 || eventTime.windowIndex >= eventTime.timeline.getWindowCount()) return;
                String id = eventTime.timeline.getWindow(eventTime.windowIndex, window).mediaItem.mediaId;
                if (!id.equals(playbackGeneration + "/" + playbackAttempt)) return;
                clearFrameHold();
            }
        });
        exo.addListener(new Player.Listener() {
            @Override
            public void onTracksChanged(Tracks tracks) {
                if (pendingFramePlay != null) return; // previous media is being captured
                if (exo != player || playbackFailed || vlcActive) return;
                summariseTracks(tracks);
                // The device can't decode the sound (e.g. MPEG audio Layer 2 on Fire TV): VLC decodes it in software.
                if ((audioUnsupported || videoUnsupported) && !vlcActive) {
                    final String why = "This device can't decode the " + (videoUnsupported ? "picture (" + videoMime : "sound (" + audioMime) + ")";
                    postPlaybackRetry(() -> tryVlc(why));
                    return;
                }
                org.json.JSONArray audioList = buildAudioList(tracks);
                selectPreferredStartupAudio(tracks);
                emitAudioList(audioList);
                if (exo.getPlaybackState() == Player.STATE_READY) handleExoReady();
            }

            @Override
            public void onPlaybackStateChanged(int state) {
                if (pendingFramePlay != null) return; // previous media is being captured
                if (exo != player || playbackFailed || vlcActive) return;
                if (state == Player.STATE_BUFFERING) {
                    beginExoBuffering();
                } else if (state == Player.STATE_READY) {
                    main.removeCallbacks(stallWatchdog);
                    handleExoReady();
                } else if (state == Player.STATE_ENDED) {
                    handleExoEnded(exo.isCurrentMediaItemSeekable() && !exo.isCurrentMediaItemLive() && exo.getDuration() > 60000);
                }
            }

            @Override
            public void onRenderedFirstFrame() {
                if (pendingFramePlay != null) return; // previous media is being captured
                if (exo != player || playbackFailed || vlcActive) return;
                exoRenderedFrame = true;
                if (exoStallDeadline > 0) { checkExoDeadline(); armExoDeadlineCheck(); }
                else finishExoProgress();
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (pendingFramePlay != null) return; // previous media is being captured
                if (exo != player || playbackFailed || vlcActive) return; // stale/stopped player
                final String url = curUrl;
                final Map<String, String> headers = curHeaders;
                final int sourceMode = curSourceMode;
                final int uaIndex = curUaIndex;
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    exo.seekToDefaultPosition();
                    exo.prepare();
                    return;
                }
                // A terminal decoder failure is handed to VLC immediately, at every resolution.
                if (error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED
                        || error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
                        || error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
                        || error.errorCode == PlaybackException.ERROR_CODE_DECODING_RESOURCES_RECLAIMED) {
                    String why = describeError(error);
                    if (!tryVlc(why)) failPlayback(why);
                    return;
                }
                final int detected = curStreamDetector.kind();
                final boolean parsingFailure = error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
                        || error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED;
                int nextMode = StreamFormatDetector.nextMode(detected, curTriedModes);
                // An observed TS/MP4 body may arrive on a .m3u8 URL; an opaque
                // URL may contain HLS. Never infer HLS from a generic parse failure.
                if (parsingFailure && nextMode >= 0
                        && (detected != StreamFormatDetector.HLS
                            || error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED)) {
                    postPlaybackRetry(() -> startPlayback(url, headers, nextMode, uaIndex));
                    return;
                }
                int code = httpStatusOf(error);
                if (!curUaFixed && (code == 401 || code == 403 || code == 406 || detected == StreamFormatDetector.TEXT_ERROR || detected == StreamFormatDetector.EMPTY_RESPONSE)
                        && uaIndex + 1 < USER_AGENTS.length) {
                    postPlaybackRetry(() -> startPlayback(url, headers, sourceMode, uaIndex + 1));
                    return;
                }
                if (detected == StreamFormatDetector.TEXT_ERROR || detected == StreamFormatDetector.EMPTY_RESPONSE) {
                    lastError = detected == StreamFormatDetector.EMPTY_RESPONSE
                            ? "Server returned an empty stream response. Try another channel or retry later."
                            : "Server returned a webpage or error response instead of a video stream.";
                    failPlayback(lastError);
                    return;
                }
                String msg = describeError(error);
                // An HTTP failure is not a decoder problem. A second native
                // player cannot repair 404/410 or a failed provider connection.
                if (code >= 400 || error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
                        || error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) {
                    failPlayback(msg);
                    return;
                }
                // Give the independent VLC engine a chance at every resolution.
                if (tryVlc(msg)) return;
                failPlayback(msg);
            }
        });

        exo.addAnalyticsListener(new androidx.media3.exoplayer.analytics.AnalyticsListener() {

            @Override
            public void onDroppedVideoFrames(androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime eventTime,
                    int droppedFrames, long elapsedMs) {
                if (pendingFramePlay != null) return; // previous media is being captured
                if (exo != player || playbackFailed || vlcActive) return;
                observeExoDrops(droppedFrames);
            }

            @Override
            public void onVideoDecoderInitialized(androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime eventTime,
                                                  String decoderName, long initializedTimestampMs, long initializationDurationMs) {
                videoDecoder = decoderName;
                String n = decoderName.toLowerCase();
                boolean software = n.startsWith("omx.google") || n.startsWith("c2.android") || n.contains("sw") || n.contains("ffmpeg");
                // (no on-screen message: the decoder name is shown in Info)
            }
        });

        playerView.setKeepContentOnPlayerReset(true);
        playerView.setPlayer(exo);
        WebView web = getBridge().getWebView();
        if (web != null) { web.setFocusable(true); web.setFocusableInTouchMode(true); web.requestFocus(); }
        return exo;
    }

    /** Stop playing but keep the player ready for the next channel. */
    private void stopPlayback() {
        clearFrameHold();
        clearExoDeadlines();
        main.removeCallbacks(stallWatchdog);
        if (player != null) {
            player.stop();
            player.clearMediaItems();
        }
    }

    private void releasePlayer() {
        clearExoDeadlines();
        main.removeCallbacks(stallWatchdog);
        if (playerView != null) playerView.setPlayer(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }

    private void summariseTracks(Tracks tracks) {
        StringBuilder sb = new StringBuilder();
        videoUnsupported = false;
        audioUnsupported = false;
        boolean anyAudio = false, anyAudioOk = false;
        for (Tracks.Group g : tracks.getGroups()) {
            int type = g.getType();
            if ((type != C.TRACK_TYPE_VIDEO && type != C.TRACK_TYPE_AUDIO) || g.length == 0) continue;
            Format f = g.getTrackFormat(0);
            boolean ok = g.isSupported();
            if (sb.length() > 0) sb.append("; ");
            sb.append(type == C.TRACK_TYPE_VIDEO ? "video " : "audio ").append(describeFormat(f));
            sb.append(ok ? " (ok)" : " (NOT SUPPORTED on this device)");
            if (type == C.TRACK_TYPE_VIDEO) {
                videoVariants = Math.max(videoVariants, g.length);
                videoMime = String.valueOf(f.sampleMimeType);
                if (!ok) videoUnsupported = true;
            } else {
                audioMime = String.valueOf(f.sampleMimeType);
                anyAudio = true;
                if (ok) anyAudioOk = true;
            }
        }
        audioUnsupported = anyAudio && !anyAudioOk;
        tracksSummary = sb.toString();
    }

    private static String describeFormat(Format f) {
        StringBuilder sb = new StringBuilder(String.valueOf(f.sampleMimeType));
        if (f.width > 0 && f.height > 0) sb.append(' ').append(f.width).append('x').append(f.height);
        if (f.channelCount > 0) sb.append(' ').append(f.channelCount).append("ch");
        if (f.sampleRate > 0) sb.append(' ').append(f.sampleRate).append("Hz");
        return sb.toString();
    }

    private static int httpStatusOf(Throwable t) {
        int depth = 0;
        while (t != null && depth < 6) {
            if (t instanceof HttpDataSource.InvalidResponseCodeException) {
                return ((HttpDataSource.InvalidResponseCodeException) t).responseCode;
            }
            t = t.getCause();
            depth++;
        }
        return 0;
    }

    private String describeError(PlaybackException error) {
        StringBuilder sb = new StringBuilder(error.getErrorCodeName());
        int code = httpStatusOf(error);
        if (code != 0) sb.append(" | server answered HTTP ").append(code);
        Throwable c = error.getCause();
        int depth = 0;
        while (c != null && depth < 3) {
            String m = c.getMessage();
            if (m != null && !m.isEmpty() && !(code != 0 && m.contains(String.valueOf(code)))) sb.append(" | ").append(m);
            c = c.getCause();
            depth++;
        }
        if (!tracksSummary.isEmpty()) sb.append(" | ").append(tracksSummary);
        return sb.toString();
    }

    private static String stateName(int s) {
        switch (s) {
            case Player.STATE_IDLE: return "idle";
            case Player.STATE_BUFFERING: return "loading";
            case Player.STATE_READY: return "playing";
            case Player.STATE_ENDED: return "ended";
            default: return String.valueOf(s);
        }
    }

    private void emit(String state, String message) {
        JSObject o = new JSObject();
        o.put("state", state);
        o.put("requestId", playbackRequestId);
        if (message != null) o.put("message", message);
        notifyListeners("state", o);
    }

    /** Android TV/media remote keys never bypass the subscription lease. */
    public void handleMediaKey(int code) {
        if (!hasAccess()) { expireAccess(); return; }
        if (playbackFailed) { focusPlayerUi(); return; }
        boolean active=vlcActive && vlc!=null;
        boolean playing=active?vlc.isPlaying():(player!=null && player.getPlayWhenReady());
        boolean pause=code==android.view.KeyEvent.KEYCODE_MEDIA_PAUSE || (code==android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE && playing);
        if(active) {if(pause)vlc.pause();else vlc.resume();}
        else if(player!=null) {if(pause)player.pause();else player.play();rearmVideoStartupWatchdog();}
    }

    @Override
    protected void handleOnPause() {
        clearExoDeadlines();
        emit("paused", null);
        if (player != null) player.pause();
        if (vlcActive && vlc != null) vlc.pause();
        super.handleOnPause();
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        if (!hasAccess()) { expireAccess(); return; }
        if (playbackFailed) { focusPlayerUi(); return; }
        if (vlcActive && vlc != null) vlc.resume();
        else if (player != null) { player.play(); rearmVideoStartupWatchdog(); }
    }

    @Override
    protected void handleOnDestroy() {
        clearFrameHold();
        ++playbackGeneration; ++playbackAttempt;
        playbackFailed = true;
        main.removeCallbacks(accessExpiry);
        if (vlc != null) vlc.shutdown();
        releasePlayer();
        super.handleOnDestroy();
    }
}
