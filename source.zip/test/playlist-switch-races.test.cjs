const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
const apiNormalize=require('../www/script.js').normalizeUrl;
const {ActivationClient}=require('../www/activation-client.js');
function defer(){let resolve;const promise=new Promise(r=>resolve=r);return{promise,resolve};}
function grant(id){return{ok:true,allowed:true,playlist_url:`https://example.test/${id}.m3u`,remaining_seconds:86400,subscription_id:id,playlist_version:1,days_left:30,label:'Playlist '+id,device_token:String(id).repeat(64)};}
test('late old grant cannot restore the previous playlist after activation changed',async()=>{
 const old=defer(),a=grant(1),b=grant(2);let calls=0;
 const c={normalizeUrl:apiNormalize,accessClient:{value:a,deadline:65000},performance:{now:()=>0},nativePlugin:()=>({accessGrant:()=>++calls===1?old.promise:Promise.resolve()}),$:()=>({textContent:''}),setMsg(){},currentAccess:null,trialResult:{}};
 vm.createContext(c);vm.runInContext('let playlistEpoch=0;'+script.slice(script.includes('  function isCurrentPlaylistGrant(')?script.indexOf('  function isCurrentPlaylistGrant('):script.indexOf('  async function acceptAccess('),script.indexOf('  async function checkTrial(')),c);
 const pending=c.acceptAccess(a);c.accessClient.value=b;vm.runInContext('playlistEpoch++',c);await c.acceptAccess(b);old.resolve();await pending;
 assert.equal(c.currentAccess.subscription_id,2);
});
test('old channel-page response cannot refill a cleared playlist after code switch',async()=>{
 const old=defer();const c={state:{items:[{name:'Old'}],view:[0],big:{},groups:[],current:0},ui:{},store:{del(){}},KEY:{last:'last',lastItem:'lastItem'},els:{list:{textContent:''},listWrap:{scrollTop:0},emptyList:{},emptyText:{}},setBusy(){},bigListPage:()=>old.promise,renderMore(){},paintCursor(){},setMsg(){},clearTimeout(){},setTimeout(){}};
 vm.createContext(c);vm.runInContext('let bigSeq=0,bigTimer=0,bigLoading=false;'+script.slice(script.indexOf('  function bigApply('),script.indexOf('  async function bigLoadMore(')),c);
 const pending=c.bigApply(0);
 // Model accepting a different code; the production switch invalidator must advance bigSeq.
 const fnStart=script.indexOf('  function beginPlaylistSwitch(');
 if(fnStart>=0){const fnEnd=script.indexOf('  function clearActivatedPlaylist(',fnStart);c.playRequest=0;c.searchSeq=0;c.searchDebounce=0;c.cancelStartupPlayTimer=()=>{};c.cancelPlaybackWait=()=>{};c.ui={};vm.runInContext('let playlistEpoch=0;'+script.slice(fnStart,fnEnd),c);c.beginPlaylistSwitch();}
 c.state.items=[];c.state.view=[];c.state.big=null;
 old.resolve({items:[{name:'OLD CHANNEL LATE'}],total:1});await pending;
 assert.equal(c.state.items.length,0);
});
test('new activation verification does not join a still-pending old-token check',async()=>{
 const old=defer();let requests=[];const st=new Map([['active-code.device-token','1'.repeat(64)]]);
 const c=new ActivationClient({identity:async()=> 'a'.repeat(32),storage:{getItem:k=>st.get(k)||'',setItem:(k,v)=>st.set(k,v)},request:async(action,b)=>{requests.push([action,b.device_token]);if(action==='activate')return grant(2);return b.device_token==='1'.repeat(64)?old.promise:grant(2);}});
 try{
  const oldCheck=c.verify(true);await new Promise(r=>setImmediate(r));await c.activate('2222222222');
  const currentCheck=c.verify(true);await new Promise(r=>setImmediate(r));
  assert.ok(requests.some(([a,t])=>a==='device-check'&&t==='2'.repeat(64)));
  old.resolve(grant(1));await oldCheck;assert.equal((await currentCheck).subscription_id,2);
 }finally{old.resolve(grant(1));clearTimeout(c.timer);}
});
test('late old saved-index restore cannot load or play after a different code is accepted',async()=>{
 const pending=defer(),a=grant(1),b=grant(2);let applied=0;
 const c={accessClient:{value:a},normalizeUrl:apiNormalize,state:{source:'',items:[]},loadedVersion:null,loadedSubscription:null,savedCacheMatches:require('../www/script.js').savedCacheMatches,prepareSavedRestore:()=>null,startupProgress(){},loadBig:async()=>{applied++},startRestoredPlaylist:async()=>{throw Error('old playback was requested')}};
 vm.createContext(c);
 vm.runInContext('let playlistEpoch=0;'+script.slice(script.indexOf('  function isCurrentPlaylistGrant('),script.indexOf('  async function acceptAccess('))+script.slice(script.indexOf('  async function restoreAuthorized('),script.indexOf('  function bigApply(')),c);
 const restore=c.restoreAuthorized(a,{bigMeta:{cacheFormat:5,subscriptionId:1,playlistVersion:1,source:a.playlist_url},bigOpen:pending.promise});
 c.accessClient.value=b;vm.runInContext('playlistEpoch++',c);pending.resolve({total:1,groups:[]});assert.equal(await restore,false);assert.equal(applied,0);
});
