from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
CHECKOUT=ROOT.parent

class WorkflowSourcePackage(unittest.TestCase):
    def test_every_workflow_rejects_missing_jvm_adapters_or_stale_version(self):
        for kind in ('debug', 'release'):
            text=(CHECKOUT/'.github/workflows'/('app-'+kind+'.yml')).read_text()
            for required in ('source.zip', 'Version mismatch',
                             'test/vlc-stubs/android/content/Context.java',
                             'test/vlc-stubs/android/net/Uri.java',
                             'test/vlc-stubs/android/os/Handler.java',
                             'test/vlc-stubs/android/os/Looper.java',
                             'test/vlc-stubs/android/view/ViewGroup.java',
                             'test/vlc-stubs/android/view/View.java',
                             'test/vlc-stubs/android/os/SystemClock.java',
                             'test/vlc-stubs/org/videolan/libvlc/interfaces/IMedia.java',
                             'native/java/FrameHold.java.tpl',
                             'tools/TestFrameHold.java',
                             'archive.testzip()'):
                self.assertIn(required, text, kind + ': ' + required)

if __name__ == '__main__':
    unittest.main()
