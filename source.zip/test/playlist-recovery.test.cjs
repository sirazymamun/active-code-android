const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
function setup(){
 const elements={};const document={activeElement:null,documentElement:{classList:{add(){},remove(){}}}};
 function $(id){return elements[id]??={hidden:true,textContent:'',events:{},classes:new Set(),classList:{add(c){elements[id].classes.add(c)},remove(c){elements[id].classes.delete(c)}},addEventListener(k,fn){this.events[k]=fn},focus(){document.activeElement=this},click(){this.events.click?.()}}}
 const context={$,document,currentAccess:{subscription_id:1,playlist_version:1,playlist_url:'https://example.test/list'},accessClient:{},normalizeUrl:s=>String(s||''),setBusy(){},setMsg(){},closeOverlay(){},closeDialog(){},openActivation(){},syncSubscription(){context.synced++},synced:0,subscriptionSyncPending:null};
 vm.createContext(context);
 const a=script.indexOf('  function startupProgress('),b=script.indexOf('  async function deviceIdentity',a);
 const c=script.indexOf('  const MAX_PLAYLIST_ATTEMPTS'),d=script.indexOf('  async function loadAuthorized',c);
 vm.runInContext('let startupLoading=false;'+script.slice(a,b)+script.slice(c,d),context);
 return {$,context,run:s=>vm.runInContext(s,context)};
}
test('failed import retains full-screen progress, retries once, then pauses visibly',()=>{
 const {$,run}=setup();run('resetPlaylistRecovery(currentAccess);showPlaylistFailure(Error("HTTP 404"),currentAccess)');
 assert.equal(run('startupLoading'),true);assert.equal(run('playlistRecovery.paused'),false);assert.match($('startupStage').textContent,/HTTP 404.*Retrying once/);
 run('showPlaylistFailure(Error("timed out"),currentAccess)');
 assert.equal(run('startupLoading'),true);assert.equal(run('playlistRecovery.paused'),true);assert.equal($('startupRecovery').hidden,false);assert.equal($('startupTitle').textContent,'Could not load playlist');
});
test('Retry resets attempts and restarts verification while preserving activation',()=>{
 const {$,run,context}=setup();run('showPlaylistFailure(Error("timeout"),currentAccess);showPlaylistFailure(Error("timeout"),currentAccess)');
 $('startupRetry').events.click();assert.equal(run('playlistRecovery.paused'),false);assert.equal(run('playlistRecovery.attempts'),0);assert.equal(context.synced,1);assert.equal(context.currentAccess.subscription_id,1);
});
test('recovery controls accept TV remote arrows and OK',()=>{
 const {$,run,context}=setup();run('showPlaylistFailure(Error("timeout"),currentAccess);showPlaylistFailure(Error("timeout"),currentAccess)');
 const event={key:'',keyCode:22,preventDefault(){}};context.event=event;
 assert.equal(run('handleStartupRecoveryKey(event)'),true);assert.equal(context.document.activeElement,$('startupActivate'));
 event.keyCode=21;run('handleStartupRecoveryKey(event)');assert.equal(context.document.activeElement,$('startupRetry'));
 event.keyCode=23;run('handleStartupRecoveryKey(event)');assert.equal(context.synced,1);
});
test('revision change resets paused failure and cannot pin a new playlist',()=>{
 const {run}=setup();run('showPlaylistFailure(Error("timeout"),currentAccess);showPlaylistFailure(Error("timeout"),currentAccess);currentAccess.playlist_version=2;resetPlaylistRecovery(currentAccess)');
 assert.equal(run('playlistRecovery.paused'),false);assert.equal(run('playlistRecovery.attempts'),0);
});
test('authorized download failure is propagated before any loader-dismiss error status',()=>{
 const a=script.indexOf('crumb("ok (failed:');const b=script.indexOf('/* =====================================================================',a);const code=script.slice(a,b);
 assert.ok(code.indexOf('if (propagateError) throw err;')<code.indexOf('setStatus('));
});
test('authorized importer stops after two failures; explicit retry can succeed without another code',async()=>{
 const {$,run,context}=setup();let calls=0;
 context.state={items:[],big:null};context.accessLoading=false;context.loadedVersion=null;context.loadedSubscription=null;
 context.rememberAuthorizedCache=()=>{};
 context.loadFromUrl=async()=>{calls++;throw Error('server timeout')};
 const a=script.indexOf('  async function loadAuthorized(j) {'),b=script.indexOf('  let loadedVersion=null',a);
 vm.runInContext(script.slice(a,b),context);
 await assert.rejects(context.loadAuthorized(context.currentAccess),/server timeout/);
 assert.equal(run('startupLoading'),true);assert.equal(run('playlistRecovery.attempts'),1);
 await assert.rejects(context.loadAuthorized(context.currentAccess),/server timeout/);
 assert.equal(run('playlistRecovery.paused'),true);
 await context.loadAuthorized(context.currentAccess);assert.equal(calls,2);
 context.loadFromUrl=async()=>{calls++;context.state.items=[{url:'https://example.test/live.ts'}]};
 run('resetPlaylistRecovery(currentAccess)');await context.loadAuthorized(context.currentAccess);
 assert.equal(calls,3);assert.equal(run('playlistRecovery.attempts'),0);assert.equal(context.loadedSubscription,1);
});
