const test=require('node:test'),assert=require('node:assert/strict');
const voice=require('../www/voice-search.js');
function lookup(names){return async q=>names.filter(name=>name.toLowerCase().includes(q.toLowerCase())).map(name=>({name}));}
test('Show my tv resolves to the real Somoy channel including region/quality',async()=>{
 const r=await voice.resolve(['Show my tv'],lookup(['BD: SOMOY TV HD','ATN Bangla']));
 assert.equal(r.query,'BD: SOMOY TV HD');assert.equal(r.corrected,true);
});
test('Somoy correction requires a channel in this playlist',async()=>{
 const r=await voice.resolve(['Show my tv'],lookup(['ATN Bangla']));
 assert.equal(r.query,'Show my tv');assert.equal(r.corrected,false);
});
test('Bengali recognition can match a Latin Somoy catalog',async()=>{
 assert.equal((await voice.resolve(['সময় টিভি'],lookup(['SOMOY TV']))).query,'SOMOY TV');
});
test('Latin recognition can match a Bengali Somoy catalog',async()=>{
 assert.equal((await voice.resolve(['Show my tv'],lookup(['সময় টিভি']))).query,'সময় টিভি');
});
test('a lower-ranked exact hypothesis beats an unmatched first hypothesis',async()=>{
 assert.equal((await voice.resolve(['a ten bangle','ATN Bangla'],lookup(['ATN Bangla HD']))).query,'ATN Bangla HD');
});
test('an exact primary channel is never changed to a soundalike',async()=>{
 assert.equal((await voice.resolve(['Show My TV','Somoy TV'],lookup(['Show My TV','Somoy TV']))).query,'Show My TV');
});
test('a unique minor error is corrected using catalog names',async()=>{
 assert.equal((await voice.resolve(['ATN Bangle'],lookup(['ATN Bangla']))).query,'ATN Bangla');
});
test('ambiguous near matches leave the speech intact',async()=>{
 assert.equal((await voice.resolve(['ABC nows'],lookup(['ABC news','ABC now']))).query,'ABC nows');
});
test('short utterances do not trigger fuzzy corrections',async()=>{
 assert.equal((await voice.resolve(['AB'],lookup(['ABC']))).query,'AB');
});
test('punctuation in channel name survives correction so substring search works',async()=>{
 assert.equal((await voice.resolve(['ATN Bangla'],lookup(['ATN-Bangla HD']))).query,'ATN-Bangla HD');
});
test('catalog work is bounded to eight probes',async()=>{
 let calls=0;await voice.resolve(['one name','two name','three name','four name','five name'],async()=>{calls++;return[]});
 assert.ok(calls<=8);
});
test('a cancelled session ignores a late catalog result',async()=>{
 let current=true,complete;const pending=new Promise(r=>complete=r);
 const work=voice.resolve(['Somoy TV'],()=>pending,()=>current);
 current=false;complete([{name:'Somoy TV'}]);assert.equal(await work,null);
});
test('empty recognition does not search the catalog',async()=>{
 const r=await voice.resolve([],()=>{throw Error('must not run')});assert.equal(r.query,'');
});
