const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
function backSetup({failed=false,pending=false,overlay=false}={}){
 const counts={open:0,close:0,exit:0};let visible=overlay;
 const c={ui:{playbackFailed:failed,playbackPending:pending},searchDlg:{open:false},infoOpen:()=>false,dialogOpen:()=>false,startupLoading:false,state:{items:[{},{}],big:null},document:{activeElement:null},overlayOpen:()=>visible,openOverlay(){counts.open++;visible=true},closeOverlay(){counts.close++;visible=false},root:{Capacitor:{Plugins:{App:{exitApp(){counts.exit++}}}}}};
 vm.createContext(c);const start=script.indexOf('  function handleBack()'),end=script.indexOf('  document.addEventListener(',start);vm.runInContext(script.slice(start,end),c);
 return {c,counts};
}
for(const status of ['failed','pending'])test(`Back on a ${status} channel keeps app open across repeated presses`,()=>{
 const {c,counts}=backSetup({[status]:true});for(let i=0;i<6;i++)c.handleBack();assert.equal(counts.exit,0);assert.equal(counts.open,3);assert.equal(counts.close,3);
});
test('healthy playback retains normal Back exit behavior',()=>{
 const {c,counts}=backSetup();c.handleBack();assert.equal(counts.exit,1);
});
test('hardware Back closes search before considering playback or exit',()=>{
 const {c,counts}=backSetup({failed:true});c.searchDlg={open:true,close(){this.open=false}};c.handleBack();assert.equal(c.searchDlg.open,false);assert.equal(counts.exit+counts.open,0);
});
function waitSetup(){
 const timers=new Map();let id=0,stopped=0;const messages=[];
 const c={playRequest:1,ui:{playbackPending:true},setTimeout(fn){timers.set(++id,fn);return id},clearTimeout(n){timers.delete(n)},cancelStartupPlayTimer(){},hideAudioWiz(){},setBusy(){},setMsg:t=>messages.push(t),engine:{stop(){stopped++}}};
 const start=script.indexOf('  let playbackWaitTimer = 0;'),end=script.indexOf('  function cancelStartupPlayTimer()',start);vm.createContext(c);vm.runInContext(script.slice(start,end),c);
 return {c,timers,messages,get stopped(){return stopped}};
}
test('unending buffering becomes No signal without closing app; repeated buffering does not extend deadline',async()=>{
 const s=waitSetup();s.c.armPlaybackWait();s.c.armPlaybackWait();assert.equal(s.timers.size,1);await [...s.timers.values()][0]();assert.deepEqual(s.messages,['No signal!']);assert.equal(s.stopped,1);assert.equal(s.c.ui.playbackFailed,true);assert.equal(s.c.ui.playbackPending,false);
});
test('an old channel timer cannot stop a newly selected channel',()=>{
 const s=waitSetup();s.c.armPlaybackWait();s.c.playRequest++;[...s.timers.values()][0]();assert.equal(s.stopped,0);assert.equal(s.messages.length,0);
});
test('successful playback can cancel its pending watchdog',()=>{
 const s=waitSetup();s.c.armPlaybackWait();s.c.cancelPlaybackWait();assert.equal(s.timers.size,0);
});
test('remote Up Down OK and menu remain wired after an error state',()=>{
 const {c}=backSetup({failed:true});let callback;const keys=[];
 Object.assign(c,{document:{addEventListener:(event,fn)=>callback=fn,body:{classList:{contains:()=>false}},activeElement:null},handleStartupRecoveryKey:()=>false,infoOpen:()=>false,audioWizOpen:()=>false,overlayOpen:()=>false,step:n=>keys.push(n),openOverlay:()=>keys.push('menu'),ui:{playbackFailed:true}});
 const start=script.indexOf('  document.addEventListener(\n    "keydown",',script.indexOf('function handleBack()')),end=script.indexOf('  // Android hardware / remote Back button',start);
 vm.runInContext(script.slice(start,end),c);
 for(const key of ['ArrowUp','ArrowDown','Enter','Menu'])callback({key,preventDefault(){}});
 assert.deepEqual(keys,[-1,1,'menu','menu']);
});

test('Exo deadline requests fallback before No signal; VLC receives its own timer',async()=>{
 const s=waitSetup();let attempts=0;s.c.engine.recover=async()=>{attempts++;return{started:true}};
 s.c.armPlaybackWait();await [...s.timers.values()][0]();assert.equal(attempts,1);assert.equal(s.stopped,0);assert.equal(s.messages.length,0);assert.equal(s.c.ui.playbackEngine,'vlc');
 await [...s.timers.values()].at(-1)();assert.equal(attempts,1);assert.equal(s.stopped,1);assert.deepEqual(s.messages,['No signal!']);
});
test('late fallback response cannot affect a different channel',async()=>{
 const s=waitSetup();let complete;s.c.engine.recover=()=>new Promise(r=>complete=r);s.c.armPlaybackWait();const pending=[...s.timers.values()][0]();s.c.playRequest++;complete({started:true});await pending;assert.equal(s.stopped,0);assert.equal(s.messages.length,0);
});

test('native Exo startup budget is 7 seconds; VLC retains a separate 45 seconds',()=>{
 const s=waitSetup();let delay;s.c.engine.recover=async()=>({started:true});s.c.setTimeout=(fn,ms)=>{delay=ms;return 1};s.c.armPlaybackWait();assert.equal(delay,7000);s.c.cancelPlaybackWait();s.c.ui.playbackEngine='vlc';s.c.armPlaybackWait();assert.equal(delay,45000);
});
