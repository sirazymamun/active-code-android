const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
test('final playback errors display only No signal and do not leak technical diagnostics',()=>{
 let callback,shown;
 const context={engine:{onState:fn=>callback=fn},startupLoading:false,ui:{},cancelPlaybackWait(){},hideAudioWiz(){},cancelStartupPlayTimer(){},setBusy(){},setMsg:(...args)=>shown=args};
 const start=script.indexOf('  engine.onState((e) => {'),end=script.indexOf('\n  async function play(',start);
 // End the extraction at the matching registration, before other UI bindings.
 const stop=script.indexOf('\n  });',start)+7;
 vm.runInNewContext(script.slice(start,stop),context);
 for(const message of ['Neither player could play this channel. HTTP 404','Input does not start with the #EXTM3U header.','Empty stream response']){
  callback({state:'error',message});assert.deepEqual(shown,['No signal!',true]);
 }
});
