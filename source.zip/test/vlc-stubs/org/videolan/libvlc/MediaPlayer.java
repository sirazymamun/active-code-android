package org.videolan.libvlc;
import java.util.concurrent.*;
public class MediaPlayer {
 public static Thread uiThread; public static volatile CountDownLatch gate=new CountDownLatch(1), entered=new CountDownLatch(1);
 public static final java.util.List<MediaPlayer> instances=new java.util.concurrent.CopyOnWriteArrayList<>();
 public Media media; public volatile boolean stopped,detached,released;public boolean automaticDecoding; public EventListener listener; public String url;
 public MediaPlayer(LibVLC l){instances.add(this);}
 public interface EventListener {void onEvent(Event e);} public static class Event {public static final int Buffering=1,Playing=2,EncounteredError=3,EndReached=4;public int type;public Event(int t){type=t;}public float getBuffering(){return 100;}}
 public static class ScaleType {public static final ScaleType SURFACE_FILL=new ScaleType();}
 public static class TrackDescription {public int id;public String name;}
 public void attachViews(Object a,Object b,boolean c,boolean d){}public void setVideoScale(ScaleType s){}public void setEventListener(EventListener e){listener=e;}
 public void setMedia(Media m){media=m;url=m.url;automaticDecoding=m.hardwareEnabled&&!m.hardwareForced&&!m.avcodecNone;}public void play(){}public void pause(){}public boolean isPlaying(){return false;}
 public void stop(){if(Thread.currentThread()==uiThread)throw new AssertionError("stop on UI");entered.countDown();try{if(!gate.await(3,TimeUnit.SECONDS))throw new AssertionError("gate timeout");}catch(InterruptedException e){throw new RuntimeException(e);}stopped=true;}
 public void detachViews(){if(Thread.currentThread()!=uiThread||!stopped)throw new AssertionError("detach must follow stop, on UI");detached=true;}
 public void release(){if(Thread.currentThread()==uiThread||!detached)throw new AssertionError("release must follow detach, off UI");released=true;}
 public TrackDescription[] getAudioTracks(){return new TrackDescription[0];}public int getAudioTrack(){return 0;}public boolean setAudioTrack(int i){return true;}public boolean isSeekable(){return false;}public long getLength(){return 0;}public long getTime(){return 0;}public void setTime(long n){}public Object getCurrentVideoTrack(){return null;}
}
