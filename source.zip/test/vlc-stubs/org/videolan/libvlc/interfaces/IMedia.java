package org.videolan.libvlc.interfaces; public interface IMedia { class Stats { public int displayedPictures,playedAbuffers; } class Track {public int type; public Track(int t){type=t;}} }
