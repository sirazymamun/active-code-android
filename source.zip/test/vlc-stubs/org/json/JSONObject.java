package org.json; public class JSONObject { public JSONObject put(String k,Object v){return this;} }
