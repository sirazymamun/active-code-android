package com.tv2u.app;
import android.os.Handler;import org.videolan.libvlc.*;import java.util.*;import java.util.concurrent.*;
public class VlcLifecycleTest {
 static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
 static void until(java.util.function.BooleanSupplier done)throws Exception {long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);while(!done.getAsBoolean()&&System.nanoTime()<end){Handler.drain();Thread.sleep(5);}Handler.drain();check(done.getAsBoolean(),"cleanup completion timeout");}
 public static void main(String[] args)throws Exception {
  MediaPlayer.uiThread=Thread.currentThread();VlcFallback v=new VlcFallback(new android.content.Context(),new android.view.ViewGroup());int[] events={0},starts={0},playingEvents={0},firstFrames={0};
  VlcFallback.Listener l=new VlcFallback.Listener(){public void onFirstFrame(){firstFrames[0]++;}public void onStarting(){starts[0]++;}public void onPlaying(boolean b){events[0]++;playingEvents[0]++;}public void onBuffering(){events[0]++;}public void onError(){events[0]++;}public void onEnded(){events[0]++;}public void onAudio(org.json.JSONArray a){events[0]++;}};
  v.start("A","ua",Map.of(),l);MediaPlayer a=MediaPlayer.instances.get(0);MediaPlayer.EventListener stale=a.listener;
  long start=System.nanoTime();v.release();check(TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start)<200,"release blocked UI");check(MediaPlayer.entered.await(1,TimeUnit.SECONDS),"worker did not stop");
  int[] heartbeat={0};new Handler(android.os.Looper.getMainLooper()).post(()->heartbeat[0]++);Handler.drain();check(heartbeat[0]==1,"UI unresponsive while stop blocked");
  v.start("B","ua",Map.of(),l);v.start("C","ua",Map.of(),l);check(starts[0]==1,"queued fallback reported starting too early");check(MediaPlayer.instances.size()==1,"overlapping native players created");
  stale.onEvent(new MediaPlayer.Event(MediaPlayer.Event.Playing));check(events[0]==0,"stale callback leaked");
  MediaPlayer.gate.countDown();until(()->MediaPlayer.instances.size()==2);check(a.released&&a.detached&&a.stopped,"cleanup ordering failed");check(MediaPlayer.instances.get(1).url.equals("C"),"older pending start replaced newest channel");
  check(starts[0]==2,"actual deferred start was not reported");check(MediaPlayer.instances.get(0).automaticDecoding&&MediaPlayer.instances.get(1).automaticDecoding,"reference automatic decoding policy lost during deferred start");MediaPlayer.instances.get(1).listener.onEvent(new MediaPlayer.Event(MediaPlayer.Event.Buffering));check(playingEvents[0]==0,"buffer 100% incorrectly reported decoded playback");
  MediaPlayer c=MediaPlayer.instances.get(1);c.listener.onEvent(new MediaPlayer.Event(MediaPlayer.Event.Playing));Handler.tick();check(firstFrames[0]==0,"Playing uncovered video before a presented frame");c.media.stats.displayedPictures=1;Handler.tick();check(firstFrames[0]==1,"presented video frame did not reveal new content");Handler.tick();check(firstFrames[0]==1,"duplicate first-frame callback");
  MediaPlayer.gate=new CountDownLatch(1);MediaPlayer.entered=new CountDownLatch(1);v.start("D","ua",Map.of(),l);check(MediaPlayer.entered.await(1,TimeUnit.SECONDS),"second stop not started");v.shutdown();MediaPlayer.gate.countDown();until(()->LibVLC.released);check(MediaPlayer.instances.size()==2,"shutdown allowed deferred playback");
  System.out.println("PASS actual VlcFallback lifecycle with JVM Android/VLC adapters: blocked stop leaves UI runnable; stale events ignored; only latest deferred start; decoder cleanup order; shutdown cancels pending start");
 }
}
