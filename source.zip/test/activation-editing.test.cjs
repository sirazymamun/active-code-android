const {test}=require('node:test');const assert=require('node:assert/strict');
const {ActivationClient}=require('../www/activation-client.js');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const grant={ok:true,allowed:true,playlist_url:'https://provider.test/list',remaining_seconds:60,device_token:'b'.repeat(64)};
function make(request){return new ActivationClient({request,identity:async()=> 'a'.repeat(32),storage:{getItem:()=> 'a'.repeat(64),setItem(){}}});}
test('saved subscription is checked immediately without requiring input',async()=>{
 let calls=0;const c=make(async()=>{calls++;return grant});try{assert.equal(c.activationRequired,false);assert.equal((await c.verify(true)).allowed,true);assert.equal(calls,1);}finally{clearTimeout(c.timer)}
});
test('first server rejection latches manual mode and only a new 10 digit code resumes it',async()=>{
 let checks=0,activations=0;const c=make(async(action)=>{if(action==='activate'){activations++;return grant}checks++;throw Object.assign(Error('denied'),{activationRequired:true})});
 try{
  await c.verify(true);assert.equal(checks,1);assert.equal(c.activationRequired,true);
  for(let n=0;n<10;n++){await c.verify(true);await assert.rejects(c.activate('1'.repeat(n)));}
  assert.equal(checks,1);assert.equal(activations,0);
  await c.activate('0123456789');assert.equal(activations,1);assert.equal(c.activationRequired,false);
 }finally{clearTimeout(c.timer)}
});
test('connection failure never latches manual mode and next successful retry restores grant',async()=>{
 let calls=0;const c=make(async()=>{if(++calls===1)throw Error('Network unavailable');return grant});
 try{assert.equal(await c.verify(true),null);assert.equal(c.activationRequired,false);assert.equal((await c.verify(true)).allowed,true);assert.equal(calls,2);}finally{clearTimeout(c.timer)}
});
test('after denial timer, online and resume paths do not request or disturb input',async()=>{
 const src=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');let requests=0,timers=0,progress=0;
 const c={accessClient:{token:'old',activationRequired:true,verify(){requests++;throw Error('unexpected')}},subscriptionSyncTimer:null,subscriptionSyncPending:null,activationBusy:false,accessLoading:false,clearTimeout(){},setTimeout(){timers++},document:{hidden:false},startupProgress(){progress++},setBusy(){progress++},setMsg(){progress++}};
 vm.createContext(c);vm.runInContext(src.slice(src.indexOf('  function scheduleSubscriptionSync('),src.indexOf('  document.addEventListener("visibilitychange"')),c);
 c.scheduleSubscriptionSync(5000);await c.syncSubscription();c.resumeSubscription();assert.equal(requests,0);assert.equal(timers,0);assert.equal(progress,0);
});
