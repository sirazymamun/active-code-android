const {test}=require('node:test');
const assert=require('node:assert/strict');
const {savedCacheMatches,mediaKind}=require('../www/script.js');

const grant={subscription_id:7,playlist_version:3,playlist_url:'https://provider.example/list.m3u'};

test('saved playlist cache matches the exact authorized revision',()=>{
  assert.equal(savedCacheMatches({cacheFormat:5,subscriptionId:7,playlistVersion:3,source:'https://provider.example/list.m3u'},grant),true);
});

test('subscription, version or URL change invalidates saved playlist cache',()=>{
  assert.equal(savedCacheMatches({cacheFormat:5,subscriptionId:8,playlistVersion:3,source:grant.playlist_url},grant),false);
  assert.equal(savedCacheMatches({cacheFormat:5,subscriptionId:7,playlistVersion:4,source:grant.playlist_url},grant),false);
  assert.equal(savedCacheMatches({cacheFormat:5,subscriptionId:7,playlistVersion:3,source:'https://provider.example/other.m3u'},grant),false);
  assert.equal(savedCacheMatches({subscriptionId:7,playlistVersion:3,source:grant.playlist_url},grant),false);
});

test('media rows classify live, movie and series entries',()=>{
  assert.equal(mediaKind({url:'https://x/live/u/p/1.ts',group:'Sports'}),'live');
  assert.equal(mediaKind({url:'https://x/movie/u/p/2.mp4',group:'Action'}),'movie');
  assert.equal(mediaKind({url:'https://x/series/u/p/3.m3u8',group:'Drama'}),'series');
  assert.equal(mediaKind({url:'https://x/opaque/4',group:'VOD Cinema'}),'live');
  assert.equal(mediaKind({url:'https://x/play/4',group:'أفلام عربية'}),'live');
  assert.equal(mediaKind({url:'https://x/play/5',group:'مسلسلات عربية'}),'live');
  assert.equal(mediaKind({url:'https://x/play?id=6&type=vod',group:'عربي'}),'movie');
  assert.equal(mediaKind({url:'https://x/play/7',group:'عربي',kindHint:'series'}),'series');
  assert.equal(mediaKind({url:'https://x/play/8',group:'Drama',name:'Example S02E05'}),'live');
});
