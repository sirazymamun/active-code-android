const fs=require('node:fs'),path=require('node:path'),test=require('node:test'),assert=require('node:assert/strict');
const root=path.join(__dirname,'..'),manifest=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')),lock=JSON.parse(fs.readFileSync(path.join(root,'package-lock.json'),'utf8'));
test('release version metadata matches without rewriting transitive package versions',()=>{
 assert.equal(lock.version,manifest.version);assert.equal(lock.packages[''].version,manifest.version);
 const ms=lock.packages['node_modules/ms'];assert.equal(ms.version,'2.1.3');assert.equal(ms.resolved,'https://registry.npmjs.org/ms/-/ms-2.1.3.tgz');
 assert.equal(lock.packages['node_modules/debug'].dependencies.ms,'^2.1.3');assert.ok(ms.integrity.startsWith('sha512-'));
});
