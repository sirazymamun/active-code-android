"""Regression tests for shared AVD discovery. Android SDK processes are mocked."""
import contextlib
import io
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

SOURCE=Path(__file__).resolve().parents[1]/'tools/run_emulator.py'
spec=importlib.util.spec_from_file_location('runner',SOURCE)
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
CHECKOUT=SOURCE.parents[2]/'App' if (SOURCE.parents[2]/'App/.github').exists() else SOURCE.parents[2]

class IsolatedRunnerTests(unittest.TestCase):
 def setUp(self):
  # Expected failure cases must not become live GitHub workflow commands.
  # Production runner annotations remain enabled for real smoke jobs.
  self.runner_output=io.StringIO()
  self.enterContext(contextlib.redirect_stdout(self.runner_output))

class AvdTests(IsolatedRunnerTests):
 def test_environment_overrides_conflicts_and_preserves_home(self):
  with tempfile.TemporaryDirectory() as tmp:
   original={'HOME':'/original','ANDROID_SDK_HOME':'/wrong','ANDROID_AVD_HOME':'/wrong'}
   env,avd=runner.prepare_avd_environment(Path(tmp)/'artifacts',original)
   self.assertEqual(env['HOME'],'/original');self.assertNotIn('ANDROID_SDK_HOME',env)
   self.assertEqual(env['ANDROID_USER_HOME'],env['ANDROID_EMULATOR_HOME'])
   self.assertEqual(avd.parent,Path(env['ANDROID_AVD_HOME']))
   self.assertEqual(avd.parent.parent,Path(env['ANDROID_USER_HOME']))
   self.assertEqual(original['ANDROID_AVD_HOME'],'/wrong')
 def test_missing_created_config_fails_before_boot(self):
  with tempfile.TemporaryDirectory() as tmp:
   env,avd=runner.prepare_avd_environment(Path(tmp)/'artifacts',{})
   with self.assertRaisesRegex(RuntimeError,'config.ini'):runner.register_avd(avd,env,'24')
 def test_storage_override_replaces_spaced_modern_image_keys(self):
  with tempfile.TemporaryDirectory() as tmp:
   avd=Path(tmp);config=avd/'config.ini'
   config.write_text('disk.dataPartition.size = 7372800000\ndisk.cachePartition.size = 66M\nabi.type=x86_64\n')
   runner.configure_avd_storage(avd)
   lines=config.read_text().splitlines()
   self.assertIn('disk.dataPartition.size=6144M',lines)
   self.assertIn('disk.cachePartition.size=512M',lines)
   self.assertNotIn('disk.dataPartition.size = 7372800000',lines)
   self.assertEqual(sum(line.startswith('disk.dataPartition.size=') for line in lines),1)
 def test_absolute_discovery_index_matches_created_avd(self):
  with tempfile.TemporaryDirectory() as tmp:
   env,avd=runner.prepare_avd_environment(Path(tmp)/'artifacts',{})
   avd.mkdir();(avd/'config.ini').write_text('abi.type=x86_64\n')
   index=runner.register_avd(avd,env,'37.2')
   self.assertIn('path='+str(avd.resolve()),index.read_text());self.assertIn('target=android-37.2',index.read_text())
 def test_stable_decimal_selection_excludes_beta_and_extensions(self):
  listing='\n'.join('system-images;android-'+v+';google_apis;x86_64' for v in ['36','37.0','37.2-beta1','37-ext4'])
  self.assertEqual(runner.select_api('latest',listing),('37.0','google_apis'))
  self.assertEqual(runner.select_api('24',''),('24','google_apis'))
 def flow(self,requested='24',pages='4096',discover=True,crash=False,smaps_exit255=False):
  with tempfile.TemporaryDirectory() as tmp:
   art=Path(tmp)/'artifacts';art.mkdir();(art/'active-code-v2.1.7-debug.apk').touch();(art/'android-test.apk').touch()
   seen=[]
   def run(args,**kwargs):
    seen.append(kwargs['env'])
    if args[-1:] == ['-version']:return subprocess.CompletedProcess(args,0,'Android emulator version 36.3.10.0','')
    if args[0]=='avdmanager':
     avd=Path(args[args.index('--path')+1]);avd.mkdir(parents=True);(avd/'config.ini').write_text('abi.type=x86_64\n')
    if args[-1:] == ['get-state']:return subprocess.CompletedProcess(args,0,'device\n','')
    if 'getprop' in args:return subprocess.CompletedProcess(args,0,'1','')
    if 'getconf' in args:
     if smaps_exit255:return subprocess.CompletedProcess(args,127,'','getconf not found\n')
     if 'toybox' in args:return subprocess.CompletedProcess(args,0,pages+'\n','')
     return subprocess.CompletedProcess(args,127,'','/system/bin/sh: getconf: not found\n')
    if '/proc/self/smaps' in args:return subprocess.CompletedProcess(args,255 if smaps_exit255 else 0,'KernelPageSize:        '+str(int(pages)//1024)+' kB\n','')
    return subprocess.CompletedProcess(args,0,'OK (1 test)' if 'instrument' in args else '', '')
   def output(args,**kwargs):
    seen.append(kwargs['env'])
    if '--list' in args:return 'system-images;android-37.2;google_apis_ps16k;x86_64'
    if '-list-avds' in args:
     index=Path(kwargs['env']['ANDROID_AVD_HOME'])/'active-code-test.ini'
     self.assertTrue(index.is_file())
     return 'active-code-test\n' if discover else ''
    return pages+'\n'
   class Process:
    def poll(self):return 1 if crash else None
    def wait(self,**kwargs):return 0
    def terminate(self):pass
    def kill(self):pass
   def popen(args,**kwargs):
    seen.append(kwargs['env']);kwargs['stdout'].write('mock boot failure detail\n');kwargs['stdout'].flush();return Process()
   with patch.dict(os.environ,{'ANDROID_HOME':str(Path(tmp)/'sdk'),'ANDROID_AVD_HOME':'/stale'}),patch.object(runner.subprocess,'run',side_effect=run),patch.object(runner.subprocess,'check_output',side_effect=output),patch.object(runner.subprocess,'Popen',side_effect=popen):
    runner.main([requested,str(art)])
   self.assertEqual(len({env['ANDROID_AVD_HOME'] for env in seen}),1)
   self.assertTrue((art/('avd-api-'+('24' if requested=='24' else '37.2')+'.txt')).is_file())
 def test_shared_environment_full_mocked_sdk_flow(self):self.flow()
 def test_android7_nonzero_smaps_still_runs_both_required_instrumentation_tests(self):
  self.flow(smaps_exit255=True)
 def test_nonzero_smaps_does_not_bypass_16k_requirement(self):
  with self.assertRaisesRegex(RuntimeError,'16 KB environment'):
   self.flow('latest-16k','4096',smaps_exit255=True)
 def test_failed_commands_without_structured_page_data_still_fail(self):
  for output in ['', 'permission denied', '16384']:
   def failed(args,**kwargs):return subprocess.CompletedProcess(args,255,output,'read error')
   with patch.object(runner.subprocess,'run',side_effect=failed):
    with self.assertRaisesRegex(RuntimeError,'Unable to detect'):runner.detect_page_size(['adb'],{})
 def test_page_parser_rejects_invalid_sizes_and_uses_smallest_mapping(self):
  for output in ['0','3','12345','KernelPageSize: 0 kB']:
   self.assertIsNone(runner.parse_page_size(output))
  self.assertEqual(runner.parse_page_size('KernelPageSize: 16 kB\nKernelPageSize: 4 kB\n'),'4096')

 def test_16k_mocked_flow_succeeds_only_with_16k_pages(self):self.flow('latest-16k','16384')
 def test_16k_mocked_flow_rejects_4k_pages(self):
  with self.assertRaisesRegex(RuntimeError,'16 KB environment'):self.flow('latest-16k','4096')
 def test_invisible_avd_fails_before_launch(self):
  with self.assertRaisesRegex(RuntimeError,'not discoverable'):self.flow(discover=False)
 def test_early_exit_propagates_boot_failure(self):
  with self.assertRaisesRegex(RuntimeError,'Emulator exited'):self.flow(crash=True)
 def test_instrumentation_accepts_old_webview_assumption_skip(self):
  self.assertTrue(runner.instrumentation_passed('INSTRUMENTATION_STATUS_CODE: -3\nOK (1 test)',0))
 def test_instrumentation_rejects_failed_or_empty_output(self):
  self.assertFalse(runner.instrumentation_passed('FAILURES!!!',1))
  self.assertFalse(runner.instrumentation_passed('',0))
 def test_instrumentation_runs_native_and_webview_separately(self):
  source=SOURCE.read_text()
  self.assertIn("TEST_CLASS + '#vlcNativeLibraryLoads'",source)
  self.assertIn("TEST_CLASS + '#firstRunAndCodeDialogRender'",source)
  self.assertIn("attempts=2",source)
 def test_unknown_webview_is_not_treated_as_supported(self):
  template=(SOURCE.parents[1]/'native/test/AndroidCompatTest.java.tpl').read_text()
  self.assertIn('boolean supportedWebView=chrome.find() &&',template)
  self.assertIn('assumeTrue("UI coverage pending:',template)
  activity=(SOURCE.parents[1]/'native/java/MainActivity.java.tpl').read_text()
  self.assertIn('boolean supportedWebView=chrome.find() &&',activity)
  self.assertIn('if(!supportedWebView)',activity)
 def test_page_size_parser_accepts_getconf_and_smaps(self):
  self.assertEqual(runner.parse_page_size('4096\n'),'4096')
  self.assertEqual(runner.parse_page_size('KernelPageSize:       16 kB\n'),'16384')
  self.assertIsNone(runner.parse_page_size('/system/bin/sh: getconf: not found\n'))
 def test_device_wait_timeout_is_long_enough_for_modern_first_boot(self):
  self.assertEqual(runner.DEVICE_APPEAR_TIMEOUT,360)
 def test_debug_workflow_frees_ephemeral_runner_space(self):
  workflow=(CHECKOUT/'.github/workflows/app-debug.yml').read_text()
  self.assertIn('Free runner disk space for modern emulator images',workflow)
  self.assertIn('$ANDROID_HOME/ndk',workflow)
  self.assertIn('/usr/share/dotnet',workflow)
  self.assertIn('df -h "$GITHUB_WORKSPACE"',workflow)

class SdkInstallTests(IsolatedRunnerTests):
 def test_corrupt_download_retries_and_preserves_log(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);sdk=root/'sdk';art=root/'art';art.mkdir()
   scratch=sdk/'.temp';scratch.mkdir(parents=True);(scratch/'bad.zip').write_text('bad')
   installed=sdk/'system-images';installed.mkdir()
   results=[subprocess.CompletedProcess([],1,'','Error on ZipFile unknown archive'),
            subprocess.CompletedProcess([],0,'installed',''),
            subprocess.CompletedProcess([],0,'Android emulator version 36.3.10.0','')]
   with patch.object(runner.subprocess,'run',side_effect=results) as commands,patch.object(runner.time,'sleep') as sleep:
    runner.install_sdk_package('emulator',sdk,{'GITHUB_ACTIONS':'true'},art,'emulator',True)
   self.assertEqual(commands.call_count,3)
   self.assertIn('--channel=0',commands.call_args_list[0].args[0])
   self.assertFalse(scratch.exists());self.assertTrue(installed.exists())
   sleep.assert_called_once_with(5)
   log=(art/'sdk-install-emulator.txt').read_text()
   self.assertIn('Error on ZipFile unknown archive',log);self.assertIn('attempt 2/3',log)
 def test_permanent_failure_is_never_accepted(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)
   with patch.object(runner.subprocess,'run',return_value=subprocess.CompletedProcess([],1,'','bad zip')) as commands,patch.object(runner.time,'sleep') as sleep:
    with self.assertRaisesRegex(RuntimeError,'failed after 3 attempts'):
     runner.install_sdk_package('emulator',root,{},root,'emulator',True)
   self.assertEqual(commands.call_count,3)
   self.assertEqual([c.args[0] for c in sleep.call_args_list],[5,10])
 def test_timeout_retries_install(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)
   with patch.object(runner.subprocess,'run',side_effect=[subprocess.TimeoutExpired('sdkmanager',900),subprocess.CompletedProcess([],0,'ok','')]) as commands,patch.object(runner.time,'sleep'):
    runner.install_sdk_package('system-images;android-24;google_apis;x86_64',root,{},root,'image')
   self.assertEqual(commands.call_count,2)
   self.assertIn('TimeoutExpired',(root/'sdk-install-image.txt').read_text())
 def test_install_success_without_working_emulator_fails(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)
   results=[subprocess.CompletedProcess([],0,'installed',''),subprocess.CompletedProcess([],1,'','binary broken')]*3
   with patch.object(runner.subprocess,'run',side_effect=results),patch.object(runner.time,'sleep'):
    with self.assertRaisesRegex(RuntimeError,'failed after 3 attempts'):
     runner.install_sdk_package('emulator',root,{},root,'emulator',True)
 def test_cleanup_preserves_local_sdk_and_symlink_target(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);sdk=root/'sdk';sdk.mkdir();scratch=sdk/'.temp';scratch.mkdir()
   runner.clear_failed_sdk_downloads(sdk,{})
   self.assertTrue(scratch.exists());scratch.rmdir()
   target=root/'outside';target.mkdir();scratch.symlink_to(target,target_is_directory=True)
   runner.clear_failed_sdk_downloads(sdk,{'GITHUB_ACTIONS':'true'})
   self.assertTrue(target.exists());self.assertTrue(scratch.is_symlink())
 def test_preparation_failure_writes_artifact_and_still_raises(self):
  with tempfile.TemporaryDirectory() as tmp:
   with patch.object(runner,'main',side_effect=RuntimeError('SDK package emulator failed')):
    with self.assertRaisesRegex(RuntimeError,'SDK package'):runner.run(['24',tmp])
   self.assertIn('SDK package emulator failed',(Path(tmp)/'failure-preparation-api-24.txt').read_text())
   self.assertIn('::error::Android SDK preparation:',self.runner_output.getvalue())
 def test_expected_failure_annotations_do_not_escape_test_stdout(self):
  class ExpectedFailure(IsolatedRunnerTests):
   def runTest(inner):
    print('::error::simulated failure')
    inner.assertIn('::error::simulated failure',inner.runner_output.getvalue())
  outside=io.StringIO()
  with contextlib.redirect_stdout(outside):
   result=unittest.TestResult();ExpectedFailure().run(result)
  self.assertTrue(result.wasSuccessful())
  self.assertEqual(outside.getvalue(),'')
 def test_artifact_download_uses_node24_stable_action(self):
  for name in ['app-debug.yml','app-release.yml']:
   workflow=(CHECKOUT/('.github/workflows/'+name)).read_text()
   self.assertIn('actions/download-artifact@v8.0.2',workflow)
   self.assertNotIn('actions/download-artifact@v6',workflow)
 def test_workflow_keeps_download_diagnostics_and_release_gate(self):
  workflow=(CHECKOUT/'.github/workflows/app-debug.yml').read_text()
  self.assertNotIn('sdkmanager "emulator"',workflow)
  self.assertIn('artifacts/sdk-install-*.txt',workflow)
  self.assertIn('artifacts/failure-preparation-api-*.txt',workflow)
  self.assertIn('needs: [build, android-smoke]',workflow)


class ApkSelectionChecks(unittest.TestCase):
 def test_internal_x86_build_is_selected_instead_of_user_arm_apk(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);(p/'active-code-v2.1.14-debug.apk').touch();x=p/'active-code-v2.1.14-x86_64-debug.apk';x.touch()
   self.assertEqual(runner.select_emulator_apk(p),x)
 def test_two_legacy_apps_are_ambiguous(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);(p/'one-debug.apk').touch();(p/'two-debug.apk').touch()
   with self.assertRaisesRegex(RuntimeError,'Exactly one'):runner.select_emulator_apk(p)

if __name__=='__main__':unittest.main()
