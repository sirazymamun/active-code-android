const {test}=require('node:test');
const assert=require('node:assert/strict');
const {mediaKind,savedCacheMatches}=require('../www/script.js');
const cases=[
 ['https://x/123.ts','INDIAN | MOVIES','IN | Star Gold HD','', 'live'],
 ['https://x/watch/12.m3u8','MOVIES','Star Gold Thrills','', 'live'],
 ['https://x/u/p/12','VOD Cinema','& Pictures HD','', 'live'],
 ['https://x/live/u/p/12.mp4','Movies','Star Gold','movie','live'],
 ['https://x/live/u/p/13.ts','Series','Drama S01E02','series','live'],
 ['https://x/watch/12?type=live','Movies','Star Gold','vod','live'],
 ['https://x/movie/u/p/1.ts','News','Recorded movie','','movie'],
 ['https://x/watch?id=3&stream_type=vod','Sports','Movie','','movie'],
 ['https://x/opaque','News','Movie','movie','movie'],
 ['https://x/series/u/p/2.m3u8','Movies','Episode','','series'],
 ['https://x/episode.mkv','Movies','Story S02E04','','series'],
 ['https://x/film.mp4','News','Recorded film','','movie'],
 ['https://x/watch?next=/movie/1.mp4','Movies','Live movie channel','','live'],
 ['https://x/watch?type=vodcasting','Movies','Live','','live'],
];
test('genres never promote live movie channels into on-demand rows',()=>{for(const [url,group,name,kindHint,want]of cases)assert.equal(mediaKind({url,group,name,kindHint}),want,url)});
test('old incorrectly classified cache must be downloaded and indexed again',()=>{assert.equal(savedCacheMatches({cacheFormat:4,subscriptionId:7,playlistVersion:3,source:'https://x/list'},{subscription_id:7,playlist_version:3,playlist_url:'https://x/list'}),false)});
