import importlib.util
import pathlib
import subprocess
import sys
import tempfile
import unittest
import zipfile

TOOL = pathlib.Path(__file__).resolve().parents[1] / 'tools/report_apk_sizes.py'
spec = importlib.util.spec_from_file_location('apk_sizes', TOOL)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class ApkSizeReportTests(unittest.TestCase):
    def apk(self, folder, name):
        path = pathlib.Path(folder) / name
        with zipfile.ZipFile(path, 'w') as archive:
            archive.writestr('lib/arm64-v8a/libplayer.so', b'arm64')
            archive.writestr('lib/armeabi-v7a/libplayer.so', b'arm32')
        return path

    def test_workflow_canonical_apk_name_and_cli(self):
        with tempfile.TemporaryDirectory() as folder:
            apk = self.apk(folder, 'active-code.apk')
            rows = module.report(folder)
            self.assertEqual(rows, [('active-code.apk', apk.stat().st_size,
                                    ['arm64-v8a', 'armeabi-v7a'], 10)])
            result = subprocess.run([sys.executable, str(TOOL), folder],
                                    capture_output=True, text=True, check=True)
            self.assertIn('active-code.apk:', result.stdout)

    def test_legacy_names_are_supported_without_duplicates(self):
        with tempfile.TemporaryDirectory() as folder:
            self.apk(folder, 'active-code.apk')
            self.apk(folder, 'active-code-v5.1.8-debug.apk')
            self.assertEqual(len(module.report(folder)), 2)

    def test_unrelated_apks_and_directories_are_not_reported(self):
        with tempfile.TemporaryDirectory() as folder:
            self.apk(folder, 'app-debug-androidTest.apk')
            (pathlib.Path(folder) / 'active-code-fake.apk').mkdir()
            with self.assertRaisesRegex(RuntimeError, 'No built app APKs found'):
                module.report(folder)

    def test_missing_apks_still_fail(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(RuntimeError, 'No built app APKs found'):
                module.report(folder)
