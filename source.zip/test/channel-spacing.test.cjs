const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const css = fs.readFileSync(path.join(__dirname, '../www/style.css'), 'utf8');
const rule = (selector) => {
  const i = css.indexOf(selector + ' {', css.indexOf('/* v5.1.8: real compact rows'));
  assert.ok(i >= 0, 'missing selector: ' + selector);
  return css.slice(i + selector.length + 2, css.indexOf('}', i));
};
test('Group rows are compact at 28px and channels independently fit their two lines at 36px', () => {
  const groups = rule('.groups .list > .row.group');
  const channels = rule('.channels .list > .row');
  for (const [block, px] of [[groups,28],[channels,36]]) {
    for (const prop of ['height','min-height','max-height'])
      assert.match(block, new RegExp('\\b' + prop + ':\\s*' + px + 'px'));
    assert.match(block, /padding:\s*1px 7px/);
    assert.match(block, /margin:\s*0/);
  }
  assert.match(css, /\.channels \.list > \.row \.grp\s*\{[^}]*margin-top:\s*1px/s);
  assert.match(css, /@media \(max-width: 680px\)[\s\S]*height: 26px;[\s\S]*height: 33px;/);
});
