const {test}=require('node:test');const assert=require('node:assert/strict');
const p=require('../www/script.js');
test('M3U metadata, relative URLs and per-channel headers',()=>{const rows=p.parseM3U('\uFEFF#EXTM3U\n#EXTINF:-1 group-title="News",Bangla\n#EXTVLCOPT:http-user-agent=TV2U\nstream.ts\n#EXTINF:-1,Other\nhttps://example.com/other.ts','https://example.com/list.m3u');assert.equal(rows[0].name,'Bangla');assert.equal(rows[0].group,'News');assert.equal(rows[0].url,'https://example.com/stream.ts');assert.equal(rows[0].headers['User-Agent'],'TV2U');assert.equal(rows[1].headers,undefined);});
test('Reject HTML and recognize HLS manifests',()=>{assert.deepEqual(p.parseM3U('<html>Server error</html>'),[]);assert.equal(p.isHlsManifest('#EXTM3U\n#EXT-X-TARGETDURATION:10'),true);});
test('Xtream credentials and encoded headers',()=>{assert.equal(p.parseXtreamUrl('https://example.com/get.php?username=a&password=b&type=m3u_plus').username,'a');assert.equal(p.parseHeaderString('Referer=https%3A%2F%2Fexample.com').Referer,'https://example.com');});
test('HTTP/HTTPS XUI and Xtream playlist variants',()=>{for(const protocol of ['http','https']){for(const path of ['get.php?username=alice&password=secret&type=m3u_plus','player_api.php?username=alice&password=secret','playlist/alice/secret/m3u_plus','playlist/alice/secret/m3u']){const x=p.parseXtreamUrl(protocol+'://example.com:8080/'+path);assert.equal(x.username,'alice');assert.equal(x.password,'secret');assert.equal(x.base,protocol+'://example.com:8080');}}});
test('M3U media type metadata is retained',()=>{const rows=p.parseM3U('#EXTM3U\n#EXTINF:-1 stream-type="movie" group-title="عربي",Film\nhttps://example.com/play/1\n#EXTINF:-1 tvg-type="series" group-title="عربي",Episode\nhttps://example.com/play/2');assert.equal(rows[0].kindHint,'movie');assert.equal(rows[1].kindHint,'series');});
test('plain URL playlist and BOM/CRLF Bangla metadata',()=>{
 const plain=p.parseM3U('https://example.test/one.m3u8\nhttp://example.test:8080/two.ts');assert.equal(plain.length,2);
 const rows=p.parseM3U('\uFEFF#EXTM3U\r\n#EXTINF:-1 group-title="বাংলা",সংবাদ\r\nchannel.m3u8\r\n','https://cdn.example/base/list.m3u');assert.equal(rows[0].name,'সংবাদ');assert.equal(rows[0].group,'বাংলা');assert.equal(rows[0].url,'https://cdn.example/base/channel.m3u8');
});
test('opaque ordinary playlist URLs do not assume Xtream credentials',()=>{
 assert.equal(p.parseXtreamUrl('https://example.test/list?token=opaque'),null);
 assert.equal(p.normalizeUrl('http://example.test:8080/signed/list?token=a%2Bb'),'http://example.test:8080/signed/list?token=a%2Bb');
});
test('encoded Xtream and nested XUI accounts retain directory, scheme and port',()=>{
 for(const url of ['https://example.test:8443/panel/get.php?username=a%2Fb&password=p%40ss','https://example.test:8443/panel/playlist/a%2Fb/p%40ss/m3u_plus/']){
  const x=p.parseXtreamUrl(url);assert.equal(x.base,'https://example.test:8443/panel');assert.equal(x.username,'a/b');assert.equal(x.password,'p@ss');
 }
});
test('HLS master and media manifests are recognized as streams',()=>{
 assert.equal(p.isHlsManifest('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000000\n720/index.m3u8'),true);
 assert.equal(p.isHlsManifest('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:6,\nsegment.ts'),true);
 assert.equal(p.isHlsManifest('#EXTM3U\n#EXTINF:-1,Channel\nhttps://example.test/live.ts'),false);
});
