const test=require('node:test'),assert=require('node:assert/strict');
const {presentation,sampleRate,createController}=require('../www/network-speed.js');
const drain=async()=>{for(let i=0;i<10;i++)await Promise.resolve()};
function fixture(read){
 let time=0,id=0;const tasks=new Map(),paints=[],visibility=[];
 const controller=createController({now:()=>time,setTimeout:(fn,ms)=>{tasks.set(++id,{fn,at:time+ms});return id},clearTimeout:i=>tasks.delete(i),read:read||(()=>Promise.resolve({supported:true,receivedBytes:time*1e6/1000,elapsedMs:time})),paint:x=>paints.push(x),visibility:x=>visibility.push(x)});
 return {controller,paints,visibility,async advance(ms){const end=time+ms;for(;;){const next=[...tasks].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;time=next[1].at;tasks.delete(next[0]);next[1].fn();await drain()}time=end;await drain()}};
}
test('bits/s formatting uses decimal kbps/Mbps/Gbps and exact color boundaries',()=>{
 for(const [bps,unit,tone]of [[0,'kbps','slow'],[5000000,'Mbps','slow'],[5000001,'Mbps','medium'],[10000000,'Mbps','medium'],[10000001,'Mbps','fast'],[1e9,'Gbps','fast']]){const p=presentation(bps);assert.ok(p.text.endsWith(unit));assert.equal(p.tone,tone)}
 for(const value of [null,undefined,NaN,-1])assert.equal(presentation(value).tone,'unknown');
});
test('real byte delta is converted to bits using native elapsed time; no baseline/rate is invented',()=>{
 const before={supported:true,receivedBytes:1000,elapsedMs:1000};
 assert.equal(sampleRate(before,{supported:true,receivedBytes:1001000,elapsedMs:2000}),8e6);
 for(const current of [{supported:false},{supported:true,receivedBytes:0,elapsedMs:2000},{supported:true,receivedBytes:2000,elapsedMs:1000},null])assert.equal(sampleRate(before,current),null);
 assert.equal(sampleRate(null,before),null);assert.equal(sampleRate(before,{...before,elapsedMs:2000}),0);
});
test('menu shows speed; closing keeps it exactly60 seconds and then stops polling',async()=>{
 const f=fixture();f.controller.setMenu(true);await f.advance(1000);assert.equal(f.paints.at(-1).text,'8 Mbps');
 f.controller.setMenu(false);await f.advance(59999);assert.equal(f.controller.state().visible,true);await f.advance(1);assert.equal(f.controller.state().visible,false);
 const count=f.paints.length;await f.advance(5000);assert.equal(f.paints.length,count);assert.deepEqual(f.visibility,[true,false]);
});
test('opening again cancels old hide, repeated closed notifications do not renew grace',async()=>{
 const f=fixture();f.controller.setMenu(true);await f.advance(1000);f.controller.setMenu(false);await f.advance(59000);f.controller.setMenu(true);await f.advance(2000);assert.equal(f.controller.state().visible,true);
 f.controller.setMenu(false);await f.advance(1000);f.controller.setMenu(false);await f.advance(59000);assert.equal(f.controller.state().visible,false);
});
test('late native sample cannot repaint or resurrect the hidden indicator',async()=>{
 let complete;const f=fixture(()=>new Promise(resolve=>complete=resolve));f.controller.setMenu(true);await f.advance(0);f.controller.setMenu(false);await f.advance(60000);
 const count=f.paints.length;complete({supported:true,receivedBytes:100,elapsedMs:20000});await drain();assert.equal(f.paints.length,count);assert.equal(f.controller.state().visible,false);
});
test('background suspension stops reads and an elapsed grace stays hidden on resume',async()=>{
 const f=fixture();f.controller.setMenu(true);await f.advance(1000);f.controller.setSuspended(true);const count=f.paints.length;await f.advance(5000);assert.equal(f.paints.length,count);
 f.controller.setMenu(false);await f.advance(65000);f.controller.setSuspended(false);assert.equal(f.controller.state().visible,false);f.controller.dispose();
});
test('unavailable native statistics are displayed as unknown rather than a fake speed',async()=>{
 const f=fixture(()=>Promise.resolve({supported:false}));f.controller.setMenu(true);await f.advance(2000);assert.equal(f.paints.at(-1).text,'— kbps');f.controller.dispose();
});
