import importlib.util
import io
from pathlib import Path
import tempfile
import unittest
import zipfile

spec = importlib.util.spec_from_file_location('package_builder', Path(__file__).resolve().parents[1] / 'tools/build_complete_package.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)

class SourcePackageChecks(unittest.TestCase):
    def test_android_stubs_survive_while_generated_android_project_is_excluded(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in ['android/app/build.gradle', 'test/vlc-stubs/android/os/Handler.java', 'node_modules/large.js']:
                file = root / name
                file.parent.mkdir(parents=True, exist_ok=True)
                file.write_text('fixture')
            output = io.BytesIO()
            builder.write_source(root, output)
            with zipfile.ZipFile(output) as archive:
                self.assertEqual(archive.namelist(), ['test/vlc-stubs/android/os/Handler.java'])

    def test_missing_android_adapters_fail_distribution_validation(self):
        output = io.BytesIO()
        with zipfile.ZipFile(output, 'w') as archive:
            archive.writestr('test/vlc-stubs/org/videolan/libvlc/Media.java', 'fixture')
        with zipfile.ZipFile(output) as archive:
            with self.assertRaisesRegex(ValueError, 'android/content/Context.java'):
                builder.validate_source(archive)

    def test_missing_tutorial_reference_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'START_HERE_BN.txt').write_text('Read Tutorial/02_BUILD_BN.txt')
            with self.assertRaisesRegex(ValueError, 'missing guide'):
                builder.validate_document_links(root)
            (root / 'Tutorial').mkdir()
            (root / 'Tutorial/02_BUILD_BN.txt').write_text('Steps')
            builder.validate_document_links(root)

    def test_every_real_lifecycle_adapter_is_packaged(self):
        output = io.BytesIO()
        builder.write_source(Path(__file__).resolve().parents[1], output)
        with zipfile.ZipFile(output) as archive:
            builder.validate_source(archive)
            self.assertEqual(sum(name.startswith('test/vlc-stubs/') for name in archive.namelist()), 15)

    def test_missing_new_frame_lifecycle_adapters_fail_validation(self):
        # Reproduce the delivered ZIP defect, rather than relying on adapters
        # that happen to remain in the developer's working directory.
        new_adapters = ('android/view/View.java', 'android/os/SystemClock.java',
                        'org/videolan/libvlc/interfaces/IMedia.java')
        for omitted in new_adapters:
            with self.subTest(omitted=omitted):
                output = io.BytesIO()
                with zipfile.ZipFile(output, 'w') as archive:
                    for name in builder.REQUIRED_STUBS:
                        if name != omitted:
                            archive.writestr('test/vlc-stubs/' + name, 'adapter fixture')
                with zipfile.ZipFile(output) as archive:
                    with self.assertRaises(ValueError) as failure:
                        builder.validate_source(archive)
                    self.assertIn(omitted, str(failure.exception))

if __name__ == '__main__':
    unittest.main()
