const {test}=require('node:test');
const assert=require('node:assert/strict');
const {callNativeMethod}=require('../www/script.js');

test('injected Android Plugins work without registerPlugin',async()=>{
 const cap={isNativePlatform:()=>true,Plugins:{TrialIdentity:{getId:async()=>({deviceId:'a'.repeat(32)})}}};
 assert.equal(cap.registerPlugin,undefined);
 assert.equal((await callNativeMethod(cap,'TrialIdentity','getId')).deviceId,'a'.repeat(32));
});
test('injected HTTP bridge sends code and device ID without registry',async()=>{
 let seen;const body={code:'0012345678',device_id:'a'.repeat(32)};
 const cap={isNativePlatform:()=>true,Plugins:{CapacitorHttp:{request:async o=>{seen=o;return{status:200,data:{ok:true}};}}}};
 const options={url:'https://active-code.netcolink.com/api.php?action=activate',method:'POST',data:body};
 assert.equal((await callNativeMethod(cap,'CapacitorHttp','request',options)).status,200);
 assert.deepEqual(seen.data,body);
});
test('raw nativePromise bridge is supported without registry or Plugins',async()=>{
 const calls=[];const cap={isNativePlatform:()=>true,nativePromise:async(...args)=>{calls.push(args);return{deviceId:'b'.repeat(32)};}};
 await callNativeMethod(cap,'TrialIdentity','getId');
 assert.deepEqual(calls,[['TrialIdentity','getId',{}]]);
});
test('modern registerPlugin runtime remains supported',async()=>{
 const cap={isNativePlatform:()=>true,registerPlugin:n=>{assert.equal(n,'TrialIdentity');return{getId:async()=>({deviceId:'c'.repeat(32)})};}};
 assert.equal((await callNativeMethod(cap,'TrialIdentity','getId')).deviceId,'c'.repeat(32));
});
test('native rejection is not retried through a different transport',async()=>{
 let fallback=false;const cap={isNativePlatform:()=>true,Plugins:{CapacitorHttp:{request:async()=>{throw Error('Access denied');}}},nativePromise:async()=>{fallback=true;}};
 await assert.rejects(callNativeMethod(cap,'CapacitorHttp','request'),/Access denied/);
 assert.equal(fallback,false);
});
test('no native bridge fails closed with a clear message',async()=>{
 await assert.rejects(callNativeMethod({isNativePlatform:()=>true},'TrialIdentity','getId'),/native plugin is unavailable/);
 await assert.rejects(callNativeMethod({isNativePlatform:()=>false},'TrialIdentity','getId'),/installed Android app/);
});
