package com.tv2u.app;
import java.io.*;import java.net.*;import java.nio.file.*;
public class HttpFetch {
 public static File fixtures;public static boolean failMovies;
 public static long toFile(String url,String ua,File dest,Object progress,long budget)throws Exception{
  String action="";for(String part:new URI(url).getRawQuery().split("&"))if(part.startsWith("action="))action=part.substring(7);
  if(failMovies&&action.equals("get_vod_streams"))throw new IOException("simulated movie download failure");
  Files.copy(new File(fixtures,action+".json").toPath(),dest.toPath(),StandardCopyOption.REPLACE_EXISTING);return dest.length();
 }
}
