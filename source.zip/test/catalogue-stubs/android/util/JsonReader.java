package android.util;
public class JsonReader implements java.io.Closeable {
 private final com.google.gson.stream.JsonReader r;
 public JsonReader(java.io.Reader in){r=new com.google.gson.stream.JsonReader(in);}
 public JsonToken peek() throws java.io.IOException{return JsonToken.valueOf(r.peek().name());}
 public void nextNull()throws java.io.IOException{r.nextNull();}
 public String nextString()throws java.io.IOException{return r.nextString();}
 public boolean nextBoolean()throws java.io.IOException{return r.nextBoolean();}
 public void skipValue()throws java.io.IOException{r.skipValue();}
 public void beginObject()throws java.io.IOException{r.beginObject();}
 public boolean hasNext()throws java.io.IOException{return r.hasNext();}
 public String nextName()throws java.io.IOException{return r.nextName();}
 public void endObject()throws java.io.IOException{r.endObject();}
 public void beginArray()throws java.io.IOException{r.beginArray();}
 public void endArray()throws java.io.IOException{r.endArray();}
 public void close()throws java.io.IOException{r.close();}
}
