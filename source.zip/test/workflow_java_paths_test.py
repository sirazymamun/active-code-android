"""Validate the actual Java source-launch steps and their checkout-relative paths."""
from pathlib import Path
import re
import unittest

SOURCE = Path(__file__).resolve().parents[1]
CHECKOUT = SOURCE.parent / 'App' if (SOURCE.parent / 'App/.github/workflows').exists() else SOURCE.parent

class WorkflowJavaPaths(unittest.TestCase):
    def verify_workflow(self, name):
        text = (CHECKOUT / '.github/workflows' / name).read_text()
        steps = re.split(r'(?m)^      - ', text)[1:]
        commands = []
        for step in steps:
            command = re.match(r'run: java (tools/\w+\.java)\s*\n', step)
            if not command:
                continue
            relative_file = command.group(1)
            directory = re.search(r'(?m)^        working-directory: (.+)$', step)
            self.assertIsNotNone(directory, f'{name}: {relative_file} runs from checkout root without working-directory')
            self.assertEqual(directory.group(1), 'build-source', f'{name}: wrong working directory for {relative_file}')
            self.assertTrue((SOURCE / relative_file).is_file(), f'{name}: required Java source missing: {relative_file}')
            commands.append(relative_file)
        self.assertEqual(set(commands), {'tools/TestBigStore.java', 'tools/TestVlcLifecycle.java', 'tools/TestFrameHold.java', 'tools/TestPlaybackPolicy.java', 'tools/TestFieldInitializers.java', 'tools/TestRecordingLifecycle.java', 'tools/TestExoDeadline.java', 'tools/TestNetworkTraffic.java'})

    def test_debug_java_steps_resolve_all_packaged_sources(self):
        self.verify_workflow('app-debug.yml')

    def test_release_java_steps_resolve_all_packaged_sources(self):
        self.verify_workflow('app-release.yml')
