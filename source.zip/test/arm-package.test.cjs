const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),test=require('node:test'),assert=require('node:assert/strict'),cp=require('node:child_process');
test('native patch emits one dual-ARM APK, repairs prerelease player versions and survives repeated sync',()=>{
 const source=path.resolve(__dirname,'..'),temp=fs.mkdtempSync(path.join(os.tmpdir(),'active-code-arm-'));
 try{
  fs.cpSync(path.join(source,'native'),path.join(temp,'native'),{recursive:true});
  for(const name of ['apk-version.txt','capacitor.config.json'])fs.copyFileSync(path.join(source,name),path.join(temp,name));
  fs.mkdirSync(path.join(temp,'android/app/src/main'),{recursive:true});
  fs.writeFileSync(path.join(temp,'android/app/build.gradle'),`apply plugin: 'com.android.application'\nandroid { defaultConfig { versionCode 1; versionName "1.0" } }\n`);
  fs.writeFileSync(path.join(temp,'android/app/src/main/AndroidManifest.xml'),'<manifest><application><activity><intent-filter><category android:name="android.intent.category.LAUNCHER" /></intent-filter></activity></application></manifest>');
  for(let i=0;i<2;i++){
   cp.execFileSync(process.execPath,[path.join(temp,'native/apply.mjs')],{stdio:'pipe'});
   if(i===0){const file=path.join(temp,'android/app/build.gradle');fs.writeFileSync(file,fs.readFileSync(file,'utf8').replace(/:1\.11\.1/g,':1.12.0-alpha02').replace('libvlc-all:3.7.7','libvlc-all:4.0.0-eap29'));}
  }
  const gradle=fs.readFileSync(path.join(temp,'android/app/build.gradle'),'utf8');
  assert.match(gradle,/\? \["x86_64"\] : \["arm64-v8a", "armeabi-v7a"\]/);
  assert.match(gradle,/abiFilters\.clear\(\); abiFilters\.addAll\(activeCodeAbis\)/);
  assert.equal(gradle.split('// active-code-arm-apk').length-1,1);assert.doesNotMatch(gradle,/splits\s*\{/);
  assert.match(gradle,/versionCode 5001008/);
  assert.match(gradle,/versionName "active-code-v5\.1\.8"/);
  assert.match(gradle,/libvlc-all:3\.7\.7/);
  const players=[...gradle.matchAll(/androidx\.media3:media3-[\w-]+:([^"']+)/g)].map(m=>m[1]);
  assert.equal(players.length,7);assert.deepEqual([...new Set(players)],['1.11.1']);
 }finally{fs.rmSync(temp,{recursive:true,force:true});}
});
