const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const api=require('../www/script.js'),source=fs.readFileSync(require('node:path').join(__dirname,'../www/script.js'),'utf8');
test('HTTP/HTTPS Xtream accounts fetch all archives even when a direct playlist could succeed',async()=>{
 for(const scheme of ['http','https'])for(const type of ['m3u','m3u_plus'])for(const output of ['ts','mpegts','m3u8']){
  let direct=0,called;
  const plugin={xtreamImport:async options=>{called=options;return{big:true,total:318481,groups:[]}}};
  const c={...api,nativePlugin:()=>plugin,hookProgress(){},setStatus(){},crumb(){},fetchViaPlugin(){direct++;return '#EXTM3U\n#EXTINF:-1,Live\nhttp://x/live.ts'},FETCH_UAS:[]};vm.createContext(c);
  vm.runInContext(source.slice(source.indexOf('  async function fetchText(url)'),source.indexOf('  async function fetchTextLegacy(')),c);
  const result=await c.fetchText(`${scheme}://host.test:8080/get.php?username=u&password=p&type=${type}&output=${output}`);
  assert.equal(result.total,318481);assert.equal(direct,0);assert.equal(called.base,`${scheme}://host.test:8080`);assert.equal(called.output,output);
 }
});
test('ordinary M3U stays on playlist path and incomplete account import never falls back to live-only success',async()=>{
 let direct=0,catalogue=0;const plugin={xtreamImport:async()=>{catalogue++;throw Error('Movies unavailable')}};
 const c={...api,nativePlugin:()=>plugin,hookProgress(){},setStatus(){},crumb(){},fetchViaPlugin:async()=>{direct++;return '#EXTM3U\n#EXTINF:-1,Live\nhttps://host.test/live.ts'},FETCH_UAS:[]};vm.createContext(c);
 vm.runInContext(source.slice(source.indexOf('  async function fetchText(url)'),source.indexOf('  async function fetchTextLegacy(')),c);
 await c.fetchText('http://host.test/plain.m3u');assert.equal(direct,1);assert.equal(catalogue,0);
 await assert.rejects(c.fetchText('https://host.test/get.php?username=u&password=p'),/Movies unavailable/);assert.equal(direct,1);assert.equal(catalogue,1);
});
function hierarchy(){
 const el=()=>({children:[],dataset:{},classList:{toggle(){}},append(...x){this.children.push(...x)},appendChild(x){this.children.push(x)}});
 const groupList=el();Object.defineProperty(groupList,'textContent',{set(){this.children=[]}});
 const c={...api,URL,state:{items:[{name:'Live',group:'Shared',url:'http://x/live/u/p/1.ts'},{name:'Movie',group:'Shared',url:'http://x/movie/u/p/2.mp4'},{name:'Series',group:'Shared',url:'http://x/series/u/p/3?tv2u_series=1'}],group:'all'},ui:{},els:{groupList},document:{createElement:el},isProtectedGroup:()=>false,applyFilter(){},};
 vm.createContext(c);
 vm.runInContext(source.slice(source.indexOf('  function buildGroups()'),source.indexOf('  function applyFilter()')),c);
 vm.runInContext(source.slice(source.indexOf('  function selectGroup('),source.indexOf('  let previousListPane')),c);
 return c;
}
test('type selection exposes only that archive categories and preserves overlapping names',()=>{
 const c=hierarchy();c.buildGroups();assert.deepEqual(Array.from(c.state.groups,g=>g.key),['k:live','k:movie','k:series','g:0:Shared']);
 c.selectGroup(1);assert.deepEqual(Array.from(c.state.groups,g=>g.key),['k:live','k:movie','k:series','g:1:Shared']);
 c.selectGroup(2);assert.deepEqual(Array.from(c.state.groups,g=>g.key),['k:live','k:movie','k:series','g:2:Shared']);
});
test('opening a collection fetches only selected series, exposes season groups and returns to disk library',async()=>{
 const c=hierarchy();c.buildGroups();c.state.source='https://host.test/get.php?username=u&password=p';c.state.big={total:318481};const original=c.state.big;let called;
 c.playRequest=5;c.isProtectedItem=()=>false;c.setBusy=()=>{};c.setMsg=()=>{};c.finishStartupLoading=()=>{};c.openOverlay=()=>{};c.toast=message=>assert.fail(message);
 c.nativePlugin=()=>({xtreamSeries:async options=>{called=options;return{items:[{name:'Pilot',group:'Drama · Season 1',url:'https://x/series/u/p/101.mp4'},{name:'Next',group:'Drama · Season 2',url:'https://x/series/u/p/201.mkv'}]}}});
 vm.runInContext(source.slice(source.indexOf('  async function openSeriesArchive('),source.indexOf('  async function play(idx')),c);
 const parent=c.state.items[2];await c.openSeriesArchive(parent,5);
 assert.equal(called.seriesId,'3');assert.equal(c.state.big,null);assert.equal(c.state.items.length,2);assert.equal(c.state.items[0].lockGroup,'Shared');
 assert.equal(c.state.groups.some(g=>g.label==='Drama · Season 1'),true);assert.equal(c.state.groups.some(g=>g.label==='Drama · Season 2'),true);
 c.restoreSeriesLibrary('series');assert.equal(c.state.big,original);assert.equal(c.state.seriesLibrary,null);assert.equal(c.state.group,'k:series');
});
test('old live-only Xtream cache is reimported while completed catalogue cache is reusable',()=>{
 const grant={playlist_url:'https://x/get.php?username=u&password=p',subscription_id:1,playlist_version:1};const meta={source:grant.playlist_url,cacheFormat:5,subscriptionId:1,playlistVersion:1};
 assert.equal(api.savedCacheMatches(meta,grant),false);assert.equal(api.savedCacheMatches({...meta,catalogueSchema:1},grant),true);
});
