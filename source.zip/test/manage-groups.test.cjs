const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
const begin=source.indexOf('  const MANAGE_SETTINGS_KEY = '),end=source.indexOf('  const PAGE = ',begin);
function fixture(){
 const db=new Map(),state={source:'https://a.test/list'};
 const c={state,mediaKind:it=>it.kind||'live',TextEncoder,crypto:require('node:crypto').webcrypto,store:{get:(k,d)=>db.has(k)?structuredClone(db.get(k)):d,set:(k,v)=>(db.set(k,structuredClone(v)),true)}};
 vm.createContext(c);vm.runInContext(source.slice(begin,end),c);return {c,db,state};
}
test('default PIN 1234 has deterministic hashed representation',async()=>{
 const {c}=fixture();assert.match(await c.managePINHash('1234'),/^[0-9a-f]{64}$/);
 assert.notEqual(await c.managePINHash('1234'),await c.managePINHash('4321'));
});
test('a selected group is simultaneously removed from protected channel playback and group listing',()=>{
 const {c,db}=fixture();db.set('active-code.group-manage.v1',{pin:'',playlists:{'https://a.test/list':['g:Adult']}});
 assert.equal(c.isProtectedItem({group:'Adult',kind:'live'}),true);
 assert.equal(c.isProtectedItem({group:'News',kind:'live'}),false);
 assert.equal(c.isProtectedGroup({key:'g:Adult'}),true);
});
test('settings remain independent for each playlist and changing selection updates the cached filter',()=>{
 const {c,db,state}=fixture();db.set('active-code.group-manage.v1',{playlists:{'https://a.test/list':['k:movie'],'https://b.test/list':['g:Sports']}});
 assert.equal(c.isProtectedItem({group:'Sports',kind:'movie'}),true);
 state.source='https://b.test/list';assert.equal(c.isProtectedItem({group:'Sports',kind:'movie'}),true);
 assert.equal(c.isProtectedItem({group:'Other',kind:'movie'}),false);
});
test('Manage icon and dialog are placed between Reload and Info',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../www/index.html'),'utf8');
 assert.ok(html.indexOf('id="btnRefresh"')<html.indexOf('id="btnManage"'));
 assert.ok(html.indexOf('id="btnManage"')<html.indexOf('id="btnInfo"'));
 assert.match(html,/id="managePin"[^>]*maxlength="4"/);
});
