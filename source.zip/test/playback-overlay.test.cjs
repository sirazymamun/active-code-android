const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
test('channel browser hides playback diagnostics and restores their visibility after closing',()=>{
 const classes=new Set();const context={startupLoading:false,state:{big:null,items:[{}],view:[0],current:0},ui:{},els:{overlay:{hidden:true},zap:{hidden:false}},document:{body:{classList:{add:x=>classes.add(x),remove:x=>classes.delete(x)}},activeElement:null},renderGroups(){},paintCursor(){},armHide(){},clearTimeout(){}};
 vm.createContext(context);const a=script.indexOf('  function openOverlay() {'),b=script.indexOf('  function toggleOverlay()',a);vm.runInContext(script.slice(a,b),context);
 context.openOverlay();assert.equal(classes.has('channel-menu-open'),true);assert.equal(context.els.overlay.hidden,false);
 context.closeOverlay();assert.equal(classes.has('channel-menu-open'),false);assert.equal(context.els.overlay.hidden,true);
 const css=fs.readFileSync(path.join(__dirname,'../www/style.css'),'utf8');assert.match(css,/body\.channel-menu-open #msg\s*\{\s*visibility:\s*hidden/);
});
test('stream inspector is packaged and fallback no longer assumes HLS without body evidence',()=>{
 const native=fs.readFileSync(path.join(__dirname,'../native/java/NativePlayerPlugin.java.tpl'),'utf8');
 const apply=fs.readFileSync(path.join(__dirname,'../native/apply.mjs'),'utf8');assert.ok(apply.includes('"StreamFormatDetector.java"'));
 assert.ok(native.includes('StreamFormatDetector.nextMode(detected, curTriedModes)'));
 assert.ok(native.includes('postPlaybackRetry(() -> startPlayback(url, headers, nextMode, uaIndex))')); 
 assert.ok(native.includes('new ProgressiveMediaSource.Factory(teeFactory, extractors)'));
 assert.ok(!native.includes('startPlayback(url, headers, true, uaIndex)'));
 assert.ok(native.includes('if(size==0)detector.observeEmpty();'));
});
