import unittest,tempfile,zipfile,struct,pathlib,importlib.util
spec=importlib.util.spec_from_file_location('artifact_checker',pathlib.Path(__file__).resolve().parents[1]/'tools/check_android_artifact.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def elf(align):
 d=bytearray(120);d[:6]=b'\x7fELF\x02\x01';struct.pack_into('<Q',d,32,64);struct.pack_into('<HH',d,54,56,1);struct.pack_into('<I',d,64,1);struct.pack_into('<Q',d,64+48,align);return bytes(d)
class AlignmentChecks(unittest.TestCase):
 def test_dual_arm_expected_abis_rejects_x86_payload(self):
  with self.assertRaisesRegex(ValueError,'Unexpected packaged ABIs'):
   m.check_native(self.artifact('app.aar',elf(16384)),expected_abi='arm64-v8a,armeabi-v7a')
 def test_32_bit_elf_is_checked_when_requested(self):
  d=bytearray(84);d[:6]=b'\x7fELF\x01\x01';struct.pack_into('<I',d,28,52);struct.pack_into('<HH',d,42,32,1);struct.pack_into('<I',d,52,1);struct.pack_into('<I',d,80,4096)
  temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);p=pathlib.Path(temp.name)/'arm32.aar'
  with zipfile.ZipFile(p,'w') as z:z.writestr('jni/armeabi-v7a/libtest.so',d)
  self.assertEqual(m.check_native(p,allow_32bit=True,expected_abi='armeabi-v7a'),1)
 def artifact(self,name,data,method=zipfile.ZIP_DEFLATED):
  temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);p=pathlib.Path(temp.name)/name
  with zipfile.ZipFile(p,'w',compression=method) as z:z.writestr('jni/arm64-v8a/libtest.so',data)
  return str(p)
 def test_aligned_64_bit_library_passes(self):self.assertEqual(m.check_native(self.artifact('app.aar',elf(16384))),1)
 def test_four_k_library_is_rejected(self):
  with self.assertRaisesRegex(ValueError,'16 KB ELF'):m.check_native(self.artifact('app.aab',elf(4096)))
 def test_invalid_elf_is_rejected(self):
  with self.assertRaisesRegex(ValueError,'Invalid'):m.check_native(self.artifact('app.aar',b'not an ELF'))
 def test_unaligned_stored_apk_is_rejected(self):
  with self.assertRaisesRegex(ValueError,'ZIP alignment'):m.check_native(self.artifact('app.apk',elf(16384),zipfile.ZIP_STORED))
 def test_no_64_bit_libraries_is_rejected(self):
  temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);p=pathlib.Path(temp.name)/'empty.aab'
  with zipfile.ZipFile(p,'w'):pass
  with self.assertRaisesRegex(ValueError,'No 64-bit'):m.check_native(p)

class RuntimeRegressionChecks(unittest.TestCase):
 def source(self,name):return (pathlib.Path(__file__).resolve().parents[1]/name).read_text()
 def test_all_channel_playlists_use_worker_thread_store(self):
  native=self.source('native/java/NativePlayerPlugin.java.tpl')
  self.assertIn('if (!json && !isHlsManifest(downloadFile))',native)
  self.assertNotIn('size > BIG_BYTES',native)
 def test_background_resume_does_not_revoke_access_before_server_check(self):
  script=self.source('www/script.js')
  start=script.index('function resumeSubscription()')
  end=script.index('document.addEventListener("visibilitychange"',start)
  self.assertNotIn('accessBlocked(',script[start:end])
  self.assertIn('playbackLeaseDue',script[start:end])
 def test_access_expiry_avoids_synchronous_vlc_stop(self):
  native=self.source('native/java/NativePlayerPlugin.java.tpl')
  start=native.index('private void expireAccess()')
  end=native.index('@PluginMethod',start)
  self.assertIn('haltForAccessCheck()',native[start:end])
  self.assertNotIn('stopVlc()',native[start:end])
 def test_cold_start_opens_saved_index_before_network_import(self):
  script=self.source('www/script.js')
  self.assertIn('plugin.bigOpen()',script)
  self.assertIn('const restored=await restoreAuthorized(j, savedRestore);',script)
  self.assertIn('if (!isCurrentPlaylistGrant(j, epoch)) return;',script)
  self.assertIn('if (!restored) await loadAuthorized(j);',script)
  self.assertIn('rememberAuthorizedCache(j);',script)
 def test_disk_pages_use_random_access_without_buffer_wrapper_per_item(self):
  store=self.source('native/java/BigStore.java.tpl')
  self.assertIn('new RandomAccessFile(new File(dir, DAT), "r")',store)
  self.assertIn('data.seek(offsets[i])',store)
  self.assertNotIn('new DataInputStream(new BufferedInputStream(fis, 4096))',store)
 def test_large_download_progress_is_bridge_throttled(self):
  fetch=self.source('native/java/HttpFetch.java.tpl')
  self.assertIn('total - lastEmit >= 1048576',fetch)
 def test_playlist_retry_chain_has_one_short_total_budget(self):
  native=self.source('native/java/NativePlayerPlugin.java.tpl')
  fetch=self.source('native/java/HttpFetch.java.tpl')
  self.assertIn('PLAYLIST_FETCH_BUDGET_MS = 60000',native)
  self.assertIn('PLAYLIST_UA_ATTEMPTS = 3',native)
  self.assertIn('fetchDeadline',native)
  self.assertIn('attemptBudget',native)
  self.assertIn('HttpFetch.toFile(url, ua, downloadFile, bytes ->',native)
  self.assertIn('long budgetMs',fetch)
  self.assertIn('.callTimeout(callMs, java.util.concurrent.TimeUnit.MILLISECONDS)',fetch)
  ua=script=self.source('www/script.js')
  uas=ua[ua.index('const FETCH_UAS = ['):ua.index('];',ua.index('const FETCH_UAS = ['))]
  self.assertLess(uas.index('IPTVSmartersPro'),uas.index('DEFAULT_UA'))
  self.assertIn('FETCH_UAS.slice(0, 3)',script)
  self.assertIn('"Playlist import timed out after 120 seconds."',script)
 def test_xtream_fallback_is_bounded_and_not_repeated_in_webview(self):
  xtream=self.source('native/java/XtreamImport.java.tpl')
  script=self.source('www/script.js')
  self.assertIn('IMPORT_BUDGET_MS = 45000',xtream)
  self.assertIn('"IPTVSmartersPro"',xtream)
  self.assertIn('newFixedThreadPool(3)',xtream)
  self.assertIn('data,deadline,30000',xtream)
  self.assertIn('cats,deadline,12000',xtream)
  native_start=script.index('if (x && typeof plugin.xtreamImport === "function")')
  legacy_start=script.index('if (x) {',native_start+1)
  self.assertIn('throw new Error(firstErr + "; Xtream import: "',script[native_start:legacy_start])
 def test_accepted_code_closes_wizard_before_playlist_import(self):
  script=self.source('www/script.js')
  start=script.index('activationForm.addEventListener("submit"')
  end=script.index('els.dlg.addEventListener("close"',start)
  flow=script[start:end]
  self.assertLess(flow.index('closeDialog();'),flow.index('prepareSavedRestore(j)'))
  self.assertIn('startupProgress("Downloading playlist…")',flow)
  accepted_error=flow[flow.index('if (acceptedAndLoading)'):flow.index('} else {',flow.index('if (acceptedAndLoading)'))]
  self.assertNotIn('openDialog();',accepted_error)
  self.assertNotIn('finishStartupLoading();',accepted_error)
  self.assertIn('showPlaylistFailure(err, currentAccess)',accepted_error)
  self.assertIn('playlistRecovery.paused ? 30000 : 5000',accepted_error)
  self.assertIn('scheduleSubscriptionSync(retryDelay)',flow)
 def test_playlist_progress_and_reload_messages_remain_visible(self):
  script=self.source('www/script.js')
  status=script[script.index('function setStatus('):script.index('function withTimeout(',script.index('function setStatus('))]
  self.assertIn('if (startupLoading) startupProgress(text.replace(/\\.{3}/g, "…"));',status)
  self.assertIn('else if (!dialogOpen()) setMsg(text);',status)
  self.assertIn('Importing channels',status)
  refresh=script[script.index('els.btnRefresh.addEventListener'):script.index('const activationForm',script.index('els.btnRefresh.addEventListener'))]
  self.assertIn('setMsg("Playlist reloaded.",false,3500);',refresh)
 def test_media_type_rows_are_always_first_and_old_index_is_invalidated(self):
  store=self.source('native/java/BigStore.java.tpl')
  script=self.source('www/script.js')
  groups=store[store.index('public List<Group> groups()'):store.index('private boolean matches',store.index('public List<Group> groups()'))]
  self.assertIn('String[] kl = {"Live TV", "Movies", "Series"}',groups)
  self.assertNotIn('kindsWithData',groups)
  self.assertIn('for (int k = 0; k < 3; k++)',groups)
  self.assertIn('int kind = mediaKind(url, g, nm, kindHint);',store)
  self.assertIn('const SAVED_CACHE_FORMAT = 5;',script)
  self.assertIn('index-media-v2.bin',store)
  self.assertNotIn('if (g.matches(movieWords))',store)
  self.assertNotIn('if (movieWords.test(group))',script)
  self.assertIn('attrs["stream-type"]',script)
  self.assertIn('public synchronized int reclassify(',store)
  self.assertIn('mediaCategories(',self.source('native/java/XtreamImport.java.tpl'))
  self.assertIn('public void xtreamClassify(',self.source('native/java/NativePlayerPlugin.java.tpl'))
  self.assertIn('Number(meta.cacheFormat) === SAVED_CACHE_FORMAT',script)
  build=script[script.index('function buildGroups()'):script.index('function renderGroups()',script.index('function buildGroups()'))]
  self.assertLess(build.index('label: "Live TV"'),build.index('label: "Movies"'))
  self.assertLess(build.index('label: "Movies"'),build.index('label: "Series"'))
 def test_remote_menu_defaults_to_channel_column(self):
  script=self.source('www/script.js')
  overlay=script[script.index('function openOverlay()'):script.index('function closeOverlay()')]
  self.assertIn('ui.pane = "channels";',overlay)
  self.assertIn('previousListPane = "channels";',overlay)
  self.assertNotIn('ui.pane = "bar";',overlay)
  keys=script[script.index('function moveHorizontal('):script.index('function moveCursor(')]
  self.assertIn('ui.pane = "groups";',keys)
  self.assertIn('enterChannels();',keys)
  self.assertIn('focusMenuBar(); return;',keys)
 def test_group_channel_separator_has_coloured_progress(self):
  html=self.source('www/index.html')
  css=self.source('www/style.css')
  script=self.source('www/script.js')
  self.assertLess(html.index('id="groupList"'),html.index('id="columnProgress"'))
  self.assertLess(html.index('id="columnProgress"'),html.index('id="listWrap"'))
  self.assertIn('background: #00f5ff;',css)
  self.assertIn('height: clamp(56px, 9vh, 96px);',css)
  self.assertIn('function updateColumnProgress(',script)
  self.assertIn('const onGroups = ui.pane === "groups";',script)
  self.assertIn('onGroups ? ui.gSel : ui.cSel',script)
  self.assertIn('els.groupList.parentElement.addEventListener(',script)
  self.assertIn('updateColumnProgress(true);',script)
 def test_every_top_menu_action_closes_the_columns(self):
  script=self.source('www/script.js')
  for marker in ['els.btnSearch.addEventListener','els.btnOpen.addEventListener',
                 'els.btnRecord.addEventListener','els.btnRefresh.addEventListener',
                 'els.btnInfo.addEventListener']:
   start=script.index(marker)
   body=script[start:start+260]
   self.assertIn('closeOverlay();',body,marker)
 def test_inactive_first_channel_cannot_trap_navigation_behind_loader(self):
  script=self.source('www/script.js')
  overlay=script[script.index('function openOverlay()'):script.index('function closeOverlay()')]
  self.assertIn('cancelStartupPlayTimer();',overlay)
  self.assertIn('finishStartupLoading();',overlay)
  self.assertIn('STARTUP_PLAY_TIMEOUT_MS = 12000',script)
  play=script[script.index('async function play(idx'):script.index('function step(dir)')]
  self.assertIn('request !== playRequest || !startupLoading',play)
  self.assertIn('if (state.items.length || state.big) openOverlay();',play)
  back=script[script.index('function handleBack()'):script.index('document.addEventListener(',script.index('function handleBack()'))]
  self.assertIn('startupLoading && (state.items.length || state.big)',back)
  self.assertIn('openOverlay();',back)
  self.assertIn('kc === 82',script)
if __name__=='__main__':unittest.main()
