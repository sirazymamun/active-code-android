package com.tv2u.app;
import java.io.*;
import java.nio.file.Files;
public class BigStoreFormatsTest {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);System.out.println("PASS "+m);}
 public static void main(String[] args)throws Exception{
  File root=Files.createTempDirectory("active-code-formats-").toFile();
  try {
   File input=new File(root,"list"),db=new File(root,"db");
   String text="\uFEFF#EXTM3U\r\n#EXTINF:-1 group-title=\"বাংলা সংবাদ\",বাংলা HD\r\n#EXTVLCOPT:http-user-agent=ExamplePlayer\r\n#EXTVLCOPT:http-referrer=https://ref.example/\r\nchannels/one.m3u8\r\n#EXTINF:-1,Two\r\n/root/live.ts|User-Agent=SecondPlayer&Referer=https%3A%2F%2Ftwo.example%2F\r\n#EXTINF:-1,Three\r\nhttps://other.example/live/3.ts\r\n";
   Files.writeString(input.toPath(),text);
   BigStore store=BigStore.build(input,db,n->{},"https://cdn.example/base/redirected.m3u?token=opaque");
   var rows=store.listPage("all",0,100).items;
   check(rows.size()==3,"BOM/CRLF and mixed absolute/relative playlist loaded");
   check(rows.get(0).name.equals("বাংলা HD")&&rows.get(0).group.equals("বাংলা সংবাদ"),"Bangla name and category retained");
   check(rows.get(0).url.equals("https://cdn.example/base/channels/one.m3u8"),"relative channel uses effective redirected playlist base");
   check(rows.get(0).ua.equals("ExamplePlayer")&&rows.get(0).ref.equals("https://ref.example/"),"VLC user-agent and referer retained");
   check(rows.get(1).url.equals("https://cdn.example/root/live.ts")&&rows.get(1).ua.equals("SecondPlayer"),"root relative URL and Kodi pipe headers retained");
   check(rows.get(2).ua.isEmpty()&&rows.get(2).ref.isEmpty(),"channel headers do not leak to the next item");
   Files.writeString(input.toPath(),"https://one.example/stream\nhttp://two.example:8080/live.ts\n");
   check(BigStore.build(input,db,n->{}).total()==2,"plain URL lists work without EXTINF");
   Files.writeString(input.toPath(),"#EXTM3U\nrelative.ts\n");
   check(BigStore.build(input,db,n->{},"http://cdn.example:8080/list.m3u").listPage("all",0,10).items.get(0).url.equals("http://cdn.example:8080/relative.ts"),"relative M3U without EXTINF retains original HTTP port");
   Files.writeString(input.toPath(),"#EXTM3U\n#EXTINF:-1 type=\"movie\" group-title=\"Old\",Broken\nnot_a_url\nhttps://news.example/channel.ts\n");
   BigStore cleaned=BigStore.build(input,db,n->{});
   check(cleaned.listPage("k:live",0,10).total==1&&cleaned.listPage("k:movie",0,10).total==0,"invalid entry cannot leak movie classification into the next channel");
   String genres="#EXTM3U\n"
    +"#EXTINF:-1 group-title=\"INDIAN | MOVIES\",IN | Star Gold HD\nhttps://x/u/p/1.ts\n"
    +"#EXTINF:-1 group-title=\"MOVIES\",Star Gold Thrills\nhttps://x/watch/2.m3u8\n"
    +"#EXTINF:-1 stream-type=\"movie\" group-title=\"Movies\",Live Movie Channel\nhttps://x/live/u/p/3.mp4\n"
    +"#EXTINF:-1 group-title=\"Movies\",Movie Archive\nhttps://x/movie/u/p/4.ts\n"
    +"#EXTINF:-1 group-title=\"Movies\",Story S02E04\nhttps://x/episode.mkv\n"
    +"#EXTINF:-1 group-title=\"Series\",Live Drama S02E04\nhttps://x/u/p/6.ts\n"
    +"#EXTINF:-1 group-title=\"Movies\",Live\nhttps://x/watch?next=/movie/1.mp4\n";
   Files.writeString(input.toPath(),genres);
   BigStore delivery=BigStore.build(input,db,n->{});
   check(delivery.listPage("k:live",0,20).total==5,"movie/series genre channels and live paths stay Live TV");
   check(delivery.listPage("k:movie",0,20).total==1&&delivery.listPage("k:series",0,20).total==1,"recorded movies and file episodes stay separate");
   delivery.reclassify(java.util.Set.of("Movies","INDIAN | MOVIES"),java.util.Set.of("Series"));
   check(delivery.listPage("k:live",0,20).total==5,"overlapping API category names cannot promote live channels");
   check(delivery.listPage("g:INDIAN | MOVIES",0,20).total==1,"live movie genre remains browsable");
   check(BigStore.open(db).listPage("k:live",0,20).total==5,"corrected classification survives restart");
   new File(db,"index-media-v2.bin").renameTo(new File(db,"index.bin"));
   check(BigStore.open(db)==null,"old unversioned media index is invalidated");
   Files.writeString(input.toPath(),"<html>Permission denied</html>\n");
   boolean failed=false;try{BigStore.build(input,db,n->{},"https://cdn.example/list");}catch(Exception expected){failed=true;}
   check(failed,"HTML reply is not interpreted as a channel");
  }finally{BigStore.deleteDir(root);}
 }
}
