const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'../www');
const css=fs.readFileSync(path.join(root,'style.css'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
test('Manage uses activation translucent background and square compact shell',()=>{
 assert.match(css,/#manageDlg\.manage-dialog\s*\{[\s\S]*?background:rgba\(8,12,20,\.30\)!important/);
 assert.match(css,/#manageDlg::backdrop\s*\{\s*background:rgba\(0,0,0,\.30\)!important/);
 assert.match(css,/border-radius:0!important/);
 assert.match(css,/box-shadow:none!important/);
});
test('Manage PIN input and title follow activation sizing language',()=>{
 assert.match(css,/#manageDlg #managePin\s*\{[\s\S]*?width:100%!important/);
 assert.match(css,/border:1px solid #7f8a96!important/);
 assert.match(css,/#manageDlg \.manage-header strong\s*\{[\s\S]*?font-size:clamp\(\.8rem,2\.5vw,1\.1rem\)!important/);
});
test('Confirm and Change PIN share one compact action row',()=>{
 assert.match(html,/class="manage-pin-actions"><button class="btn" type="submit">Confirm<\/button><button class="btn" type="button" id="manageChangePinStart">Change PIN<\/button>/);
 assert.match(css,/#manageDlg \.manage-pin-actions\s*\{[\s\S]*?display:flex!important/);
});
