package com.tv2u.app;
import java.io.*;
import java.nio.file.Files;
import java.util.concurrent.atomic.AtomicInteger;
public class BigStoreSearchTest {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);System.out.println("PASS "+m);}
 public static void main(String[] args)throws Exception {
  File root=Files.createTempDirectory("active-code-search-").toFile();
  try {
   File input=new File(root,"input.m3u"),db=new File(root,"db");
   try(BufferedWriter w=Files.newBufferedWriter(input.toPath())) {
    w.write("#EXTM3U\n");
    for(int i=0;i<100000;i++)w.write("#EXTINF:-1 group-title=\""+(i%2==0?"বাংলা News":"Movies")+"\",Channel "+i+"\nhttps://example.invalid/live/test/test/"+i+".ts\n");
   }
   BigStore store=BigStore.build(input,db,n->{});
   long start=System.nanoTime();BigStore.Page first=store.searchPage("channel",0,100);long firstMs=(System.nanoTime()-start)/1000000;
   start=System.nanoTime();BigStore.Page second=store.searchPage("CHANNEL",100,100);long nextMs=(System.nanoTime()-start)/1000000;
   check(first.total==100000 && first.items.size()==100,"all 100k names searched with accurate total");
   check(second.total==100000 && second.items.get(0).name.equals("Channel 100"),"cached next page retains playlist order");
   check(store.searchPage("বাংলা",0,100).total==50000,"Unicode category matching retained");
   check(store.searchPage("/99999.ts",0,100).items.get(0).name.equals("Channel 99999"),"URL search retained");
   check(store.searchPage("no-such-item",0,100).total==0,"empty match result");
   check(store.searchPage("channel",-5,100).items.get(0).name.equals("Channel 0"),"negative offset handled");
   check(store.searchPage("channel",100001,100).items.isEmpty(),"past-end page handled");
   check(store.searchPage("channel",0,500).items.size()==200,"maximum page limit retained");
   check(store.searchPage("   ",0,100).total==0,"blank search handled");
   System.out.println("BENCHMARK first_scan_ms="+firstMs+" next_page_ms="+nextMs);
   if(args.length==0) {
    AtomicInteger checks=new AtomicInteger();boolean stopped=false;
    try {store.searchPage("new uncached query",0,100,()->checks.incrementAndGet()>2);}catch(InterruptedIOException expected){stopped=true;}
    check(stopped,"superseded search cancels during scan");
    check(store.searchPage("channel",100,100).items.get(0).name.equals("Channel 100"),"cancelled query does not corrupt cached results");
    check(BigStore.open(db).searchPage("Channel 99999",0,100).total==1,"saved databases remain searchable");
   }
  }finally{BigStore.deleteDir(root);}
 }
}
