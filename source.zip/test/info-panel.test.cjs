const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const source=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
function setup(info=async()=>'ExoPlayer playing'){
 let id=0;const timers=new Map(),classes=new Set();const c={ui:{},engine:{info},finishStartupLoading(){},setTimeout(fn,ms){timers.set(++id,{fn,ms});return id},clearTimeout(id){timers.delete(id)},els:{msg:{hidden:true,classList:{toggle(k,on){if(on)classes.add(k);else classes.delete(k)}}},msgText:{textContent:''},msgClose:{hidden:true}}};
 vm.createContext(c);vm.runInContext(source.slice(source.indexOf('  function publicError('),source.indexOf('  function startupProgress(')),c);let a=source.indexOf('  function setMsg('),b=source.indexOf('  /** Movies and series',a);vm.runInContext(source.slice(a,b),c);
 a=source.indexOf('  const infoOpen =');b=source.indexOf('  els.msgClose.addEventListener',a);vm.runInContext(source.slice(a,b)+'\nglobalThis.isOpen=infoOpen;',c);return{c,timers};
}
test('Info has no expiry and playback messages cannot replace or close it',async()=>{
 const {c,timers}=setup();await c.showInfo();assert.equal(c.isOpen(),true);assert.equal(c.els.msgClose.hidden,false);assert.equal(c.els.msgText.textContent,'ExoPlayer playing');
 for(const message of ['', 'No signal!', 'warning'])c.setMsg(message,true,20000);
 assert.equal(c.isOpen(),true);assert.equal(c.els.msgText.textContent,'ExoPlayer playing');assert.equal(timers.size,1);assert.equal([...timers.values()][0].ms,1000);
 c.closeInfo();assert.equal(c.isOpen(),false);assert.equal(timers.size,0);
});
test('Info refreshes current player while open and close restores final No signal',async()=>{
 let phase='ExoPlayer playing';const {c,timers}=setup(async()=>phase);await c.showInfo();phase='VLC starting';const [id,t]=[...timers.entries()][0];timers.delete(id);await t.fn();assert.equal(c.els.msgText.textContent,phase);
 c.ui.playbackFailed=true;c.closeInfo();assert.equal(c.els.msgText.textContent,'No signal!');assert.equal(c.els.msgClose.hidden,true);assert.equal(timers.size,0);
});
test('late Info result after manual close cannot reopen the panel',async()=>{
 let resolve;const {c,timers}=setup(()=>new Promise(r=>resolve=r));const pending=c.showInfo();c.closeInfo();resolve('old info');await pending;assert.equal(c.isOpen(),false);assert.equal(c.els.msg.hidden,true);assert.equal(timers.size,0);
});
test('older Info request cannot overwrite a newly opened panel',async()=>{
 const resolves=[];const {c,timers}=setup(()=>new Promise(r=>resolves.push(r)));const old=c.showInfo();c.closeInfo();const latest=c.showInfo();resolves[1]('VLC playing');await latest;resolves[0]('old Exo state');await old;assert.equal(c.els.msgText.textContent,'VLC playing');assert.equal(timers.size,1);c.closeInfo();
});
