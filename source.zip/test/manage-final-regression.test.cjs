const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
test('Manage lists categories in archive order and expands legacy type protection',()=>{
 const element=()=>({children:[],append(...x){this.children.push(...x)},addEventListener(){},dataset:{}});
 const ctx={manage:{},managedSet:()=>new Set(['k:movie']),state:{items:[{group:'Cinema',kind:'movie'},{group:'News',kind:'live'},{group:'Drama',kind:'series'}],groups:[{key:'k:live',label:'Live TV'},{key:'g:Cinema',label:'Cinema'},{key:'g:Drama',label:'Drama'},{key:'g:News',label:'News'}]},mediaKind:it=>it.kind,manageChoices:element(),document:{createElement:element},manageStage:stage=>ctx.stage=stage,requestAnimationFrame(){},updateManageScrollbar(){}};
 vm.createContext(ctx);vm.runInContext(source.slice(source.indexOf('  function showManageGroups()'),source.indexOf('  // Progress indicator')),ctx);ctx.showManageGroups();
 assert.deepEqual(Array.from(ctx.manage.groups,g=>g.label),['News','Cinema','Drama']);
 assert.equal(ctx.manage.selected.has('g:Cinema'),true);assert.equal(ctx.manage.selected.has('k:movie'),false);assert.equal(ctx.stage,'groups');
});
test('explicit Manage hidden state overrides important flex layout',()=>{
 const css=fs.readFileSync(path.join(__dirname,'../www/style.css'),'utf8');
 assert.match(css,/#manageDlg \[hidden\]\s*\{\s*display:none!important/);
 assert.ok(css.lastIndexOf('#manageDlg [hidden]')>css.lastIndexOf('#manageDlg .manage-pin-form'));
});
