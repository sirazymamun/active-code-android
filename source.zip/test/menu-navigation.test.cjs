const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
const begin=script.indexOf('  let previousListPane = "channels";'),end=script.indexOf('  /* =====================================================================',begin);
function setup(index=0,pane='channels') {
 const ui={pane,cSel:index,gSel:42,bSel:0};
 const context={ui,state:{view:Array(1500),groups:Array(100)},clamp:(v,a,b)=>Math.max(a,Math.min(b,v)),paintCursor(){},barItems:()=>Array(5),enterChannels(){ui.pane='channels'},selectGroup(i){ui.gSel=i}};
 vm.createContext(context);vm.runInContext(script.slice(begin,end),context);
 return {ui,run:s=>vm.runInContext(s,context)};
}
for(const index of [0,1,75,1499])test(`channel ${index+1}: all menu items reachable; Down returns to same channel`,()=>{
 const {ui,run}=setup(index);run('moveHorizontal(1)');assert.equal(ui.pane,'bar');assert.equal(ui.cSel,index);
 for(let i=1;i<5;i++){run('moveHorizontal(1)');assert.equal(ui.bSel,i)}
 run('moveHorizontal(1)');assert.equal(ui.bSel,4);
 for(let i=3;i>=0;i--){run('moveHorizontal(-1)');assert.equal(ui.bSel,i)}
 run('moveCursor(1)');assert.equal(ui.pane,'channels');assert.equal(ui.cSel,index);assert.equal(ui.gSel,42);
});
test('channel Up/Down and first-row Up retained',()=>{
 const {ui,run}=setup(75);run('moveCursor(-1)');assert.equal(ui.cSel,74);assert.equal(ui.pane,'channels');run('moveCursor(1)');assert.equal(ui.cSel,75);
 ui.cSel=0;run('moveCursor(-1)');assert.equal(ui.pane,'bar');run('moveCursor(1)');assert.equal(ui.cSel,0);assert.equal(ui.pane,'channels');
});
test('first menu Left restores channel; repeated menu focus preserves return pane',()=>{
 const {ui,run}=setup(999);run('focusMenuBar();focusMenuBar();moveHorizontal(-1)');assert.equal(ui.pane,'channels');assert.equal(ui.cSel,999);
});
test('group selection retained across menu visit',()=>{
 const {ui,run}=setup(75,'groups');run('moveHorizontal(-1)');assert.equal(ui.pane,'bar');run('returnFromMenuBar()');assert.equal(ui.pane,'groups');assert.equal(ui.gSel,42);assert.equal(ui.cSel,75);
});
test('Left reaches groups and group Right returns to channels',()=>{
 const {ui,run}=setup(75);run('moveHorizontal(-1)');assert.equal(ui.pane,'groups');run('moveHorizontal(1)');assert.equal(ui.pane,'channels');assert.equal(ui.cSel,75);
});
