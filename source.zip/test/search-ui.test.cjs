const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
const begin=script.indexOf('  const searchDlg = $("searchDlg")'),end=script.indexOf('  els.btnOpen.addEventListener',begin);
function setup(){
 const elements={};
 const $=id=>elements[id]??=( {value:'news',textContent:'',hidden:false,disabled:false,events:{},appends:0,addEventListener(k,fn){this.events[k]=fn},querySelectorAll(){return[]},append(){this.appends++},focus(){},close(){},showModal(){}} );
 let resolve;const pending=new Promise(r=>resolve=r);
 const context={$ ,els:{btnSearch:$('btnSearch')},state:{big:true,items:[]},bigPlugin:()=>({bigSearchPage:()=>pending}),document:{createDocumentFragment:()=>({})},closeOverlay(){},openDialog(){},clearTimeout(){},setTimeout(){return 1}};
 vm.createContext(context);vm.runInContext(script.slice(begin,end),context);
 return {elements,$,context,resolve};
}
test('typing invalidates old native search before debounce fires',async()=>{
 const {$,context,resolve}=setup();const work=context.searchRun();
 $('searchInput').value='sport';$('searchInput').events.input();resolve({items:[],total:99});await work;
 assert.equal($('searchResults').appends,0);assert.equal($('searchMore').hidden,true);assert.doesNotMatch($('searchStatus').textContent,/99 matching/);
});
test('closing search ignores in-flight results',async()=>{
 const {$,context,resolve}=setup();const work=context.searchRun();$('searchDlg').events.close();resolve({items:[],total:99});await work;
 assert.equal($('searchResults').appends,0);
});
test('More stays disabled while request is pending and is reenabled on completion',async()=>{
 const {$,context,resolve}=setup();const work=context.searchRun();assert.equal($('searchMore').disabled,true);
 resolve({items:[],total:0});await work;assert.equal($('searchMore').disabled,false);assert.match($('searchStatus').textContent,/0 matching/);
});
