const {test}=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');
const source=fs.readFileSync(require('node:path').join(__dirname,'../www/compat.js'),'utf8');
function legacy(expression){return vm.runInNewContext('delete Promise.prototype.finally;'+source+';'+expression);}
test('Chrome 60 finally polyfill retains fulfillment',async()=>assert.equal(await legacy('Promise.resolve(42).finally(function(){return 1;})'),42));
test('Chrome 60 finally polyfill retains rejection',async()=>{await assert.rejects(legacy('Promise.reject(Error("original")).finally(function(){})'),/original/);});
test('Chrome 60 finally callback failure replaces settlement',async()=>{await assert.rejects(legacy('Promise.resolve(1).finally(function(){throw Error("cleanup");})'),/cleanup/);});
