package com.tv2u.app;
import java.io.File;
import java.nio.file.Files;
public class BigStorePageTest {
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);System.out.println("PASS "+s);}
 public static void main(String[] args)throws Exception {
  File root=Files.createTempDirectory("tv2u-pages-").toFile();File input=new File(root,"input.m3u");
  try {
   Files.writeString(input.toPath(),"\uFEFF#EXTM3U\n#EXTINF:-1 group-title=\"News\",One\nhttps://example.com/live/u/p/one.ts\n#EXTINF:-1 group-title=\"أفلام عربية\",Two\nhttps://example.com/movie/u/p/two.mp4\n#EXTINF:-1 stream-type=\"series\" group-title=\"عربي\",Three S01E02\nhttps://example.com/opaque/three\n#EXTINF:-1 group-title=\"নাটক\",Four\nhttps://example.com/live/u/p/four.ts\n");
   BigStore store=BigStore.build(input,new File(root,"db"),n->{});
   check(store.listPage("all",0,2).total==4,"all channels counted");
   check(store.listPage("all",0,2).items.size()==2,"page size respected");
   check(store.listPage("all",2,2).items.get(0).name.equals("Three S01E02"),"next page preserves order");
   check(store.groups().get(0).label.equals("Live TV"),"Live TV is first group");
   check(store.groups().get(1).label.equals("Movies"),"Movies is second group");
   check(store.groups().get(2).label.equals("Series"),"Series is third group");
   check(store.listPage("k:live",0,500).total==2,"explicit live stream paths retained before category correction");
   check(store.listPage("k:movie",0,500).total==1,"movie filter retained");
   check(store.listPage("k:series",0,500).total==1,"explicit series metadata retained before category correction");
   store.reclassify(java.util.Set.of("أفلام عربية"),java.util.Set.of("عربي"));
   check(store.listPage("k:live",0,500).total==2,"provider categories restore heuristic false-positive to Live TV");
   check(store.listPage("k:series",0,500).total==1,"provider categories retain genuine series");
   check(store.listPage("g:News",0,500).total==1,"provider category browsing retained");
   check(store.listPage("g:Missing",0,500).total==0,"unknown group is empty");
   check(store.listPage("all",50,500).items.isEmpty(),"end of list handled");
   check(BigStore.open(new File(root,"db")).listPage("k:movie",0,500).items.get(0).name.equals("Two"),"saved database reopens");
  }finally{BigStore.deleteDir(root);}
 }
}
