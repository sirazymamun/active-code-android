const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const test=require('node:test');
const assert=require('node:assert/strict');
const script=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
function section(name,next){const a=script.indexOf('  function '+name+'(');return script.slice(a,script.indexOf('  '+next,a));}
test('loading closes the wizard and prevents reopening during provider retries',()=>{
 const classes=new Set(['add-wizard-open']), rootClasses=new Set();
 const dlg={open:true,hidden:false,close(){this.open=false},showModal(){this.open=true}};
 const stage={textContent:''};
 const context={ui:{},els:{dlg},document:{body:{classList:{add:x=>classes.add(x),remove:x=>classes.delete(x)}},documentElement:{classList:{add:x=>rootClasses.add(x),remove:x=>rootClasses.delete(x)}}},$:id=>id==='startupStage'?stage:null,armHide(){},clearTimeout(){},setTimeout(){},autoActivationTimer:0,setStatus(){},trialResult:{}};
 vm.createContext(context);
 vm.runInContext('let startupLoading=false;'+section('startupProgress','async function deviceIdentity')+section('openDialog','function closeDialog')+section('closeDialog','// The existing menu'),context);
 vm.runInContext('startupProgress("Downloading playlist…")',context);
 assert.equal(dlg.open,false);assert.equal(dlg.hidden,true);assert.equal(classes.has('add-wizard-open'),false);
 assert.equal(rootClasses.has('has-saved-activation'),true);
 vm.runInContext('openDialog()',context);assert.equal(dlg.open,false);
 vm.runInContext('startupProgress("HTTP 404 — Retrying playlist…")',context);
 assert.match(stage.textContent,/HTTP 404/);assert.equal(dlg.open,false);
 vm.runInContext('finishStartupLoading();openDialog()',context);
 assert.equal(dlg.open,true);assert.equal(dlg.hidden,false);
});
