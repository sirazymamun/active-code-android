const {test}=require('node:test');const assert=require('node:assert/strict');const {httpGet}=require('../www/script.js');
test('Follow relative redirects and preserve headers',async()=>{let urls=[];let result=await httpGet(async o=>{urls.push(o.url);assert.equal(o.headers.Referer,'https://ref.test/');return urls.length===1?{status:302,headers:{Location:'/next'}}:{status:200,headers:{},data:'ok'};},'https://example.com/start',{Referer:'https://ref.test/'});assert.equal(result.data,'ok');assert.equal(result.finalUrl,'https://example.com/next');});
test('Redirect loop terminates',async()=>{let n=0;await assert.rejects(httpGet(async()=>{n++;return {status:302,headers:{location:'/loop'}};},'https://example.com/loop'),/Too many redirects/);assert.equal(n,6);});

test('Preserve HTTP scheme on IPTV port 8080', async()=>{
  const seen=[];
  const res=await httpGet(async opts=>{seen.push(opts.url);return {status:200,headers:{},data:'#EXTM3U'};},'http://example.test:8080/get.php?type=m3u_plus');
  assert.equal(res.finalUrl,'http://example.test:8080/get.php?type=m3u_plus');
  assert.deepEqual(seen,['http://example.test:8080/get.php?type=m3u_plus']);
});
