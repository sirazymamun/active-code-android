const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
const start=source.indexOf('  $("searchVoice").addEventListener("click", async () => {'),end=source.indexOf('  els.btnOpen.addEventListener',start);
function setup(response){
 let handler;const button={disabled:false,addEventListener:(event,fn)=>handler=fn};
 const context={isProtectedItem:()=>false,searchSeq:0,searchDebounce:0,searchMore:{hidden:false},searchStatus:{textContent:''},searchInput:{value:'old'},clearTimeout(){},$:()=>button,
  state:{big:true,items:[]},window:{Capacitor:{isNativePlatform:()=>true},ChannelVoiceSearch:require('../www/voice-search.js')},
  bigPlugin:()=>({voiceSearch:()=>response,bigSearchPage:async({query})=>({items:query.toLowerCase().includes('somoy')?[{name:'SOMOY TV HD'}]:[]})})
 };
 context.searchRun=async()=>{context.searchSeq++;context.searchStatus.textContent='1 matching entries';};
 vm.createContext(context);vm.runInContext(source.slice(start,end),context);
 return {context,button,run:()=>handler()};
}
test('native alternative recognition reaches channel-aware search and explains correction',async()=>{
 const {context,button,run}=setup(Promise.resolve({text:'Show my tv',alternatives:['Show my tv','Somoy TV']}));
 await run();assert.equal(context.searchInput.value,'SOMOY TV HD');assert.match(context.searchStatus.textContent,/Heard “Show my tv”/);assert.equal(button.disabled,false);
});
test('typing/closing/replacing playlist while native voice is open discards its result',async()=>{
 let complete;const response=new Promise(r=>complete=r),{context,button,run}=setup(response);
 const pending=run();context.searchSeq++;context.searchInput.value='user typing';complete({text:'Somoy TV'});await pending;
 assert.equal(context.searchInput.value,'user typing');assert.equal(button.disabled,false);
});
test('cancelled recognition leaves the existing search text available',async()=>{
 const {context,button,run}=setup(Promise.reject(Error('Voice search cancelled')));
 await run();assert.equal(context.searchInput.value,'old');assert.match(context.searchStatus.textContent,/cancelled/);assert.equal(button.disabled,false);
});
