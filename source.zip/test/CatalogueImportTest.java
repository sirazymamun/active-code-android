package com.tv2u.app;
import java.io.*;import java.nio.file.*;import java.nio.charset.StandardCharsets;
public class CatalogueImportTest {
 static void check(boolean x,String message){if(!x)throw new AssertionError(message);System.out.println("PASS "+message);}
 static void rows(File file,String key,int count,String ext)throws Exception{
  try(BufferedWriter w=Files.newBufferedWriter(file.toPath(),StandardCharsets.UTF_8)){w.write("\ufeff[");for(int i=0;i<count;i++){if(i>0)w.write(",");w.write("{\""+key+"\":\""+(i+1)+"\",\"name\":\"Item "+i+"\",\"category_id\":\"1\",\"container_extension\":\""+ext+"\",\"ignored\":{\"nested\":[1,2,3]}}");}w.write("]");}
 }
 public static void main(String[] args)throws Exception{
  File root=Files.createTempDirectory("catalogue-native-").toFile(),cache=new File(root,"cache"),db=new File(root,"db");cache.mkdirs();HttpFetch.fixtures=root;
  try{
   for(String action:new String[]{"get_live_categories","get_vod_categories","get_series_categories"})Files.writeString(new File(root,action+".json").toPath(),"[{\"category_id\":\"1\",\"category_name\":\"Shared\"}]");
   rows(new File(root,"get_live_streams.json"),"stream_id",15397,"ts");
   rows(new File(root,"get_vod_streams.json"),"stream_id",247443,"mkv");
   rows(new File(root,"get_series.json"),"series_id",55641,"");
   BigStore store=XtreamImport.build("http://provider.test:8080","user","pass",cache,db,n->{},"m3u8");
   check(store.total()==318481,"318481 entries imported without loading catalogue JSON into WebView");
   check(store.listPage("k:live",0,1).total==15397,"15397 Live TV entries");
   check(store.listPage("k:movie",0,1).total==247443,"247443 Movies entries");
   check(store.listPage("k:series",0,1).total==55641,"55641 Series collections");
   check(store.listPage("k:live",0,1).items.get(0).url.startsWith("http://provider.test:8080/live/")&&store.listPage("k:live",0,1).items.get(0).url.endsWith(".m3u8"),"HTTP port and requested HLS output retained");
   check(store.listPage("g:0:Shared",0,1).total==15397&&store.listPage("g:1:Shared",0,1).total==247443&&store.listPage("g:2:Shared",0,1).total==55641,"same named categories stay separated by archive type");
   check(store.groups().size()==6,"three root types plus three typed categories");
   check(store.listPage("k:series",0,1).items.get(0).url.endsWith("?tv2u_series=1"),"series collections are marked and never played as episode ids");
   HttpFetch.failMovies=true;boolean failed=false;try{XtreamImport.build("https://provider.test","u","p",cache,db,n->{});}catch(Exception e){failed=true;}check(failed,"movie endpoint failure cannot commit a live-only successful import");
   check(BigStore.open(db).total()==318481,"failed reload leaves last complete disk library intact");HttpFetch.failMovies=false;
   Files.writeString(new File(root,"get_series_info.json").toPath(),"{\"episodes\":{\"2\":[{\"id\":202,\"episode_num\":2,\"title\":\"Two\",\"container_extension\":\"mkv\"},{\"id\":201,\"episode_num\":1,\"title\":\"One\"}],\"1\":[{\"id\":101,\"episode_num\":1,\"title\":\"Pilot\"}]}}");
   var episodes=XtreamSeries.load("https://provider.test","u","p","5","Drama",cache);
   check(episodes.size()==3&&episodes.get(0).name.equals("Pilot")&&episodes.get(1).name.equals("One"),"selected series seasons and episodes sorted numerically");
   check(episodes.get(0).group.equals("Drama · Season 1")&&episodes.get(2).url.equals("https://provider.test/series/u/p/202.mkv"),"season category and real playable episode id retained");
  }finally{try(var files=Files.walk(root.toPath())){for(Path p:files.sorted(java.util.Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
 }
}
