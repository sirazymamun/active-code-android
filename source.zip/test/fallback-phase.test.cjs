const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
function setup(){
 let callback,id=0;const timers=new Map(),messages=[];
 const c={playRequest:7,ui:{playbackPending:true,playbackEngine:'exo'},engine:{onState:fn=>callback=fn,stop(){}},setTimeout(fn,delay){timers.set(++id,{fn,delay});return id},clearTimeout(n){timers.delete(n)},cancelStartupPlayTimer(){},hideAudioWiz(){},setBusy(){},setMsg:t=>messages.push(t),startupLoading:false,currentAccess:{},accessClient:{deadline:99999},performance:{now:()=>0},finishStartupLoading(){}};
 vm.createContext(c);let a=source.indexOf('  let playbackWaitTimer = 0;'),b=source.indexOf('  function cancelStartupPlayTimer()',a);vm.runInContext(source.slice(a,b),c);
 a=source.indexOf('  engine.onState((e) => {');b=source.indexOf('\n  });',a)+7;vm.runInContext(source.slice(a,b),c);
 return{c,timers,messages,event:e=>callback({...e,requestId:e.requestId??7})};
}
test('VLC waiting/starting has distinct budgets and ordinary buffering cannot consume its fresh startup budget',()=>{
 const s=setup();s.c.armPlaybackWait();s.event({state:'fallback-queued'});assert.equal([...s.timers.values()][0].delay,90000);
 s.event({state:'fallback-starting'});const timer=[...s.timers.values()][0];assert.equal(timer.delay,45000);
 s.event({state:'buffering'});assert.equal([...s.timers.values()][0],timer);assert.ok(!s.messages.includes('No signal!'));
 s.event({state:'playing',vod:false});assert.equal(s.timers.size,0);assert.equal(s.c.ui.playbackFailed,false);
});
test('old request final error and fallback event cannot replace a new channel state',()=>{
 const s=setup();s.event({state:'error',requestId:6,message:'old failure'});s.event({state:'fallback-starting',requestId:6});assert.equal(s.messages.length,0);assert.equal(s.c.ui.playbackEngine,'exo');
});
test('final native VLC error displays No signal and cancels its remaining deadline',()=>{
 const s=setup();s.event({state:'fallback-starting'});s.event({state:'error'});assert.deepEqual(s.messages,['','No signal!']);assert.equal(s.timers.size,0);assert.equal(s.c.ui.playbackFailed,true);
});

test('a first error after healthy Exo playback still opens the independent VLC startup phase',()=>{
 const s=setup();s.event({state:'playing',vod:false});assert.equal(s.c.ui.playbackPending,false);
 s.event({state:'fallback-starting'});assert.equal(s.c.ui.playbackPending,true);assert.equal(s.c.ui.playbackEngine,'vlc');assert.equal([...s.timers.values()][0].delay,45000);
});

test('native pause cancels the UI buffering clock without marking failure',()=>{
 const s=setup();s.event({state:'buffering'});assert.equal(s.timers.size,1);s.event({state:'paused'});assert.equal(s.timers.size,0);assert.equal(s.c.ui.playbackPending,false);assert.ok(!s.c.ui.playbackFailed);
});
