package com.tv2u.app;
import android.view.*;import android.os.Handler;
public class FrameHoldTest {
 static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
 public static void main(String[] args){
  ViewGroup parent=new ViewGroup();View controls=new View();SurfaceView video=new SurfaceView();parent.children.add(video);parent.children.add(controls);Handler h=new Handler();FrameHold hold=new FrameHold(parent,controls,h);int[] starts={0};
  hold.captureThen(video,()->starts[0]=1);check(starts[0]==0,"decoder reset before capture");check(PixelCopy.target.width==960&&PixelCopy.target.height==540,"unbounded frame memory");
  hold.captureThen(video,()->starts[0]=2);check(PixelCopy.copies==1,"overlapping copies on rapid zap");PixelCopy.complete(0);check(starts[0]==2,"stale channel start ran");check(parent.children.size()==3&&parent.children.get(2)==controls,"hold above controls or missing");
  hold.captureThen(video,()->starts[0]=3);check(starts[0]==3&&PixelCopy.copies==1,"rapid zap replaced retained picture");hold.clear();check(parent.children.size()==2,"hold not cleared");
  hold.captureThen(video,()->starts[0]=4);var late=PixelCopy.target;h.timeout();check(starts[0]==4,"capture timeout blocked switching");hold.captureThen(video,()->starts[0]=5);check(starts[0]==5,"late capture blocked newer request");PixelCopy.complete(0);check(late.recycled&&parent.children.size()==2,"late capture covered new video");
  hold.captureThen(video,()->starts[0]=6);hold.clear();PixelCopy.complete(0);check(starts[0]==5&&parent.children.size()==2,"stop allowed pending start/capture");
  hold.captureThen(video,()->starts[0]=7);PixelCopy.complete(1);check(starts[0]==7&&parent.children.size()==2,"capture failure blocked playback");
  hold.captureThen(new TextureView(),()->starts[0]=8);check(starts[0]==8&&parent.children.size()==3,"texture fallback failed");hold.clear();
  System.out.println("PASS FrameHold: bounded pixels; newest request only; holds below controls; rapid zaps reuse picture; timeout/nonblocking late-copy/stop/failure/TextureView cleanup");
 }
}
