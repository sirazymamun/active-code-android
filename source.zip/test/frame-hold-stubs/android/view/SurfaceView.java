package android.view; public class SurfaceView extends View {public static class Holder {public Surface getSurface(){return new Surface();}} public Holder getHolder(){return new Holder();}}
