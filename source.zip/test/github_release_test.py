"""Check publication paths and shell syntax of both actual release jobs."""
from pathlib import Path
import subprocess,re,unittest,tempfile,shutil
ROOT=Path(__file__).resolve().parents[1]
CHECKOUT=ROOT.parent/'App' if (ROOT.parent/'App/.github').exists() else ROOT.parent
class GithubRelease(unittest.TestCase):
 def test_publish_jobs_use_token_permissions_and_correct_artifacts(self):
  for kind in ('debug','release'):
   text=(CHECKOUT/'.github/workflows'/('app-'+kind+'.yml')).read_text()
   job=text.split('\n  publish:\n',1)[1]
   self.assertIn('contents: write',job)
   self.assertIn('GH_TOKEN: ${{ github.token }}',job)
   self.assertIn('name: ${{ needs.build.outputs.label }}-'+kind,job)
   self.assertIn('group: active-code-release-${{ needs.build.outputs.label }}',job)
   self.assertIn('needs: [build, android-smoke]' if kind=='debug' else 'needs: build',job)
   self.assertIn('gh release upload "$RELEASE_TAG" release-assets/* --clobber',job)
   lines=job.split('        run: |\n',1)[1].splitlines()
   shell='\n'.join(line[10:] if line.startswith('          ') else line for line in lines)+'\n'
   p=subprocess.run(['bash','-n'],input=shell,text=True,capture_output=True)
   self.assertEqual(p.returncode,0,p.stderr)

 def test_push_build_also_runs_required_smoke_jobs(self):
  text=(CHECKOUT/'.github/workflows/app-debug.yml').read_text()
  smoke=text.split('\n  android-smoke:\n',1)[1].split('\n  publish:\n',1)[0]
  self.assertNotIn("if: github.event_name == 'workflow_dispatch'",smoke)
  self.assertIn('api: [24, latest, latest-16k]',smoke)
  self.assertIn('fail-fast: false',smoke)

 def test_downloaded_release_checksums_work_beside_assets(self):
  for kind in ('debug','release'):
   text=(CHECKOUT/'.github/workflows'/('app-'+kind+'.yml')).read_text()
   commands=[line.strip() for line in text.splitlines() if 'sha256sum ' in line]
   self.assertEqual(len(commands),1)
   with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp);art=root/'artifacts';art.mkdir()
    apk=art/('active-code-v5.1.8-'+kind+'.apk');apk.write_bytes(b'test apk content')
    if kind=='release':(art/'active-code-v5.1.8-release.aab').write_bytes(b'test aab content')
    subprocess.run(['bash','-euc',commands[0]],cwd=root,check=True,capture_output=True)
    assets=root/'downloaded-assets';shutil.move(art,assets)
    report=assets/'SHA256SUMS.txt';report.rename(assets/'version-checksums.txt')
    checked=subprocess.run(['sha256sum','-c','version-checksums.txt'],cwd=assets,text=True,capture_output=True)
    self.assertEqual(checked.returncode,0,checked.stderr)
    (assets/apk.name).write_bytes(b'corrupt')
    self.assertNotEqual(subprocess.run(['sha256sum','-c','version-checksums.txt'],cwd=assets,capture_output=True).returncode,0)
