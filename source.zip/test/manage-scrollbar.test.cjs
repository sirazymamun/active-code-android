const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'../www');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'style.css'),'utf8');
const js=fs.readFileSync(path.join(root,'script.js'),'utf8');
test('Manage group list gets noninteractive right-side progress indicator',()=>{
  assert.match(html,/id="manageScrollTrack"[^>]*aria-hidden="true"/);
  assert.match(html,/id="manageScrollThumb"/);
  assert.match(css,/\.manage-scroll-track[^\{]*\{[^}]*pointer-events:none/);
  assert.match(css,/\.manage-scroll-track[^\{]*\{[^}]*width:3px/);
});
test('Indicator follows real scroll offset, hides without overflow, and cycles focus',()=>{
  assert.match(js,/manageChoices\.scrollHeight-manageChoices\.clientHeight/);
  assert.match(js,/track\.hidden=max<=1/);
  assert.match(js,/manageChoices\.scrollTop\/max/);
  assert.match(js,/index\+delta\+inputs\.length\)%inputs\.length/);
  assert.match(js,/manageChoices\.addEventListener\("scroll",updateManageScrollbar/);
});
