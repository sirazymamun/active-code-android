package com.tv2u.app;
import java.nio.charset.StandardCharsets;
public class StreamFormatTest {
 static void check(boolean b,String text){if(!b)throw new AssertionError(text);System.out.println("PASS "+text);}
 static int kind(String s){byte[] b=s.getBytes(StandardCharsets.UTF_8);return StreamFormatDetector.classify(b,b.length);}
 public static void main(String[] args){
  check(kind("\uFEFF \r\n#EXTM3U\n#EXT-X-TARGETDURATION:6")==StreamFormatDetector.HLS,"HLS header with BOM and whitespace detected");
  byte[] ts=new byte[1024];ts[0]=ts[188]=ts[376]=0x47;
  check(StreamFormatDetector.classify(ts,ts.length)==StreamFormatDetector.PROGRESSIVE,"MPEG-TS detected from packet sync bytes");
  byte[] offsetTs=new byte[1024];offsetTs[17]=offsetTs[205]=offsetTs[393]=0x47;
  check(StreamFormatDetector.classify(offsetTs,offsetTs.length)==StreamFormatDetector.PROGRESSIVE,"MPEG-TS alignment offset supported");
  check(kind("\u0000\u0000\u0000\u0018ftypisom")==StreamFormatDetector.PROGRESSIVE,"MP4 identified without depending on URL extension");
  check(kind("<?xml version=\"1.0\"?><MPD xmlns=\"urn:mpeg:dash\">")==StreamFormatDetector.DASH,"DASH MPD distinguished from error text");
  check(kind("<!DOCTYPE html><html>Denied</html>")==StreamFormatDetector.TEXT_ERROR,"HTTP 200 HTML body rejected as media");
  check(kind("{\"error\":\"account blocked\"}")==StreamFormatDetector.TEXT_ERROR,"JSON error body rejected as media");
  check(kind("unrecognized content")==StreamFormatDetector.UNKNOWN,"unknown content does not imply HLS");
  check(StreamFormatDetector.nextMode(StreamFormatDetector.UNKNOWN,1)==-1,"generic parse failure never forces HLS");
  check(StreamFormatDetector.nextMode(StreamFormatDetector.PROGRESSIVE,1)==StreamFormatDetector.PROGRESSIVE,"TS body permits progressive correction");
  check(StreamFormatDetector.nextMode(StreamFormatDetector.HLS,1)==StreamFormatDetector.HLS,"observed HLS permits HLS correction");
  check(StreamFormatDetector.nextMode(StreamFormatDetector.HLS,1|(1<<StreamFormatDetector.HLS))==-1,"same format cannot be retried in a loop");
  check(StreamFormatDetector.nextMode(StreamFormatDetector.TEXT_ERROR,1)==-1,"HTML never triggers format retry");
  StreamFormatDetector empty=new StreamFormatDetector();empty.observeEmpty();
  check(empty.kind()==StreamFormatDetector.EMPTY_RESPONSE,"zero-byte EOF is identified as empty response");
  check(StreamFormatDetector.nextMode(empty.kind(),1)==-1,"empty response never forces HLS");
  StreamFormatDetector detector=new StreamFormatDetector();detector.observe(ts,80);check(detector.kind()==StreamFormatDetector.UNKNOWN,"partial TS header waits for sufficient evidence");
  detector.observe(ts,512);check(detector.kind()==StreamFormatDetector.PROGRESSIVE,"incremental capture detects TS once enough bytes arrive");
  detector.observeEmpty();check(detector.kind()==StreamFormatDetector.PROGRESSIVE,"later empty seek does not overwrite observed video type");
 }
}
