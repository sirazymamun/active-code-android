const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
function setup(){
 const groups=[{key:'k:live'},{key:'k:movie'},{key:'k:series'},{key:'g:0:PAK | ISLAMIC'},{key:'g:0:PAK | NEWS HD'}];
 const ui={pane:'groups',gSel:0,cSel:0,bSel:0};const state={groups,archiveKind:'live',group:'k:live',view:[0,1]};const selected=[];
 const c={state,ui,isProtectedGroup:()=>false,paintCursor(){},barItems:()=>[{},{}],clamp:(n,a,b)=>Math.min(b,Math.max(a,n)),selectGroup(index){const g=state.groups[index];selected.push(g.key);state.group=g.key;if(g.key.startsWith('k:'))state.archiveKind=g.key.slice(2);ui.gSel=state.groups.indexOf(g);}};
 vm.createContext(c);const a=source.indexOf('  let previousListPane = "channels";');vm.runInContext(source.slice(a,source.indexOf('  /* =====================================================================',a)),c);
 const b=source.indexOf('  /** Enter the visible group');vm.runInContext(source.slice(b,source.indexOf('  function activateCursor()',b)),c);
 return {c,state,ui,selected};
}
test('Down passes Movies and Series without selecting or replacing Live categories',()=>{
 const {c,state,ui,selected}=setup();const groups=state.groups;
 c.moveCursor(1);assert.equal(ui.gSel,1);c.moveCursor(1);assert.equal(ui.gSel,2);
 assert.equal(selected.length,0);assert.equal(state.archiveKind,'live');assert.equal(state.group,'k:live');assert.equal(state.groups,groups);
 c.moveCursor(1);assert.equal(ui.gSel,3);assert.equal(selected[0],'g:0:PAK | ISLAMIC');
 c.moveCursor(1);assert.equal(selected[1],'g:0:PAK | NEWS HD');
 c.moveCursor(1);assert.equal(ui.gSel,0);assert.equal(state.archiveKind,'live');
});
test('Up crosses type rows without changing selected category',()=>{
 const {c,state,ui,selected}=setup();ui.gSel=3;state.group=state.groups[3].key;
 for(let i=0;i<3;i++)c.moveCursor(-1);
 assert.equal(ui.gSel,0);assert.equal(selected.length,0);assert.equal(state.group,'g:0:PAK | ISLAMIC');
});
test('OK selects a type and retains left-pane focus; category Right enters Channels',()=>{
 const {c,state,ui}=setup();c.moveCursor(1);c.enterChannels();assert.equal(state.archiveKind,'movie');assert.equal(ui.pane,'groups');
 ui.gSel=3;c.moveHorizontal(1);assert.equal(ui.pane,'channels');
 c.moveHorizontal(1);assert.equal(ui.pane,'bar');c.moveHorizontal(-1);assert.equal(ui.pane,'channels');
 c.moveHorizontal(-1);assert.equal(ui.pane,'groups');
});
test('empty Channels returns to type focus without selecting a different type',()=>{
 const {c,state,ui,selected}=setup();ui.pane='channels';state.view=[];c.moveCursor(1);
 assert.equal(ui.pane,'groups');assert.equal(ui.gSel,1);assert.equal(selected.length,0);assert.equal(state.archiveKind,'live');
});

test('Right navigates from a type into existing Channels without selecting that type',()=>{const {c,state,ui,selected}=setup();c.moveCursor(1);c.moveHorizontal(1);assert.equal(ui.pane,'channels');assert.equal(state.archiveKind,'live');assert.equal(selected.length,0);c.moveHorizontal(-1);assert.equal(ui.pane,'groups');assert.equal(ui.gSel,1);});

test('focusing Back to Series action does not activate it until OK',()=>{const {c,state,ui,selected}=setup();state.groups.push({key:'series:back'});ui.gSel=4;c.moveCursor(1);assert.equal(ui.gSel,5);assert.equal(selected.length,0);c.enterChannels();assert.equal(selected[0],'series:back');assert.equal(ui.pane,'groups');});
