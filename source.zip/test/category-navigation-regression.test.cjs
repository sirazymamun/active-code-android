const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
const start=source.indexOf('  let previousListPane = "channels";');
const end=source.indexOf('  /* =====================================================================',start);
function create(pane='groups',viewLength=3){
 const groups=[{key:'g:News'},{key:'g:Hidden'},{key:'g:Sports'},{key:'g:Music'}];
 const ui={pane,gSel:0,cSel:0,bSel:0};const state={groups,group:'g:News',view:Array(viewLength).fill(0)};
 const selections=[];
 const c={ui,state,clamp:(v,a,b)=>Math.max(a,Math.min(b,v)),isProtectedGroup:g=>g.key==='g:Hidden',
  paintCursor:()=>{},barItems:()=>[{}],selectGroup:i=>{selections.push(i);ui.gSel=groups.filter(g=>g.key!=='g:Hidden').indexOf(groups[i]);state.group=groups[i].key;},
  enterChannels:()=>{ui.pane='channels';}};
 vm.createContext(c);vm.runInContext(source.slice(start,end),c);return {ui,state,selections,run:t=>vm.runInContext(t,c)};
}
test('group Down skips hidden category and continues navigation',()=>{
 const p=create();p.run('moveCursor(1)');assert.equal(p.ui.gSel,1);assert.equal(p.selections.at(-1),2);
 p.run('moveCursor(1)');assert.equal(p.ui.gSel,2);assert.equal(p.selections.at(-1),3);
 p.run('moveCursor(1)');assert.equal(p.ui.gSel,0);assert.equal(p.selections.at(-1),0);
});
test('group Up wraps from first to last visible category',()=>{
 const p=create();p.run('moveCursor(-1)');assert.equal(p.ui.gSel,2);assert.equal(p.selections.at(-1),3);
});
test('empty channel pane returns to category navigation instead of swallowing remote',()=>{
 const p=create('channels',0);p.run('moveCursor(1)');assert.equal(p.ui.pane,'groups');assert.equal(p.ui.gSel,1);assert.equal(p.selections.at(-1),2);
});
test('group-to-channel transition uses visible selection indices',()=>{
 const segment=source.slice(source.indexOf('  /** Enter the visible group'),source.indexOf('  function activateCursor()',source.indexOf('  /** Enter the visible group')));
 assert.match(segment,/state\.groups\.filter\(x => !isProtectedGroup\(x\)\)\[ui\.gSel\]/);
});
