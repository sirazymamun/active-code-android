const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const {ActivationClient}=require('../www/activation-client.js');
const api=require('../www/script.js');const script=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
const A={ok:true,allowed:true,subscription_id:1,playlist_version:1,playlist_url:'https://provider.test/A.m3u',remaining_seconds:86400,days_left:1,label:'A',device_token:'a'.repeat(64)};
const B={...A,subscription_id:2,playlist_url:'https://provider.test/B.m3u',label:'B',device_token:'b'.repeat(64)};
const text=label=>`#EXTM3U\n#EXTINF:-1 group-title="${label} group",${label} channel\nhttps://video.test/${label}.ts\n`;
function setup(){
 const memory=new Map(),elements={};let handler;const fetches=[],plays=[],grants=new Map([['1111111111',A],['2222222222',B]]),tokens=new Map(),fail=new Set();
 const $=id=>elements[id]??={value:'',textContent:'',hidden:false,readOnly:false,classList:{add(){},remove(){},toggle(){}},addEventListener(){},focus(){}};
 const c={...api,isProtectedItem:()=>false,SAVED_CACHE_FORMAT:4,activationForm:{addEventListener(k,fn){handler=fn}},activationCode:$('activationCode'),savedOpenRequests:new Set(),activationBusy:false,accessLoading:false,autoActivationTimer:null,currentAccess:null,startupLoading:false,trialResult:{},state:{source:'',items:[],view:[],groups:[],big:null,current:-1},ui:{cSel:0,gSel:0},KEY:{cache:'cache',big:'big',history:'history',last:'last',lastItem:'lastItem'},store:{get:(k,d)=>memory.has(k)?structuredClone(memory.get(k)):d,set:(k,v)=>{memory.set(k,structuredClone(v));return true},del:k=>memory.delete(k)},els:{list:$('list'),groupList:$('groups'),dlg:{open:true},btnRefresh:$('refresh')},searchResults:$('searchResults'),searchInput:$('searchInput'),playRequest:0,searchSeq:0,searchDebounce:null,bigSeq:0,bigTimer:null,bigLoading:false,playlistEpoch:0,loadedVersion:null,loadedSubscription:null,performance,clearTimeout(){},setTimeout(fn){queueMicrotask(fn);return 1},cancelStartupPlayTimer(){},cancelPlaybackWait(){},setBusy(){},setMsg(){},setStatus(){},crumb(){},closeDialog(){c.els.dlg.open=false},closeOverlay(){},finishStartupLoading(){c.startupLoading=false},startupProgress(){c.startupLoading=true},$: $,nativePlugin:()=>({accessGrant:async()=>{}}),bigPlugin:()=>null,scheduleSubscriptionSync(){},playlistRecovery:{key:'',error:'',paused:false,attempts:0},resetPlaylistRecovery(){c.playlistRecovery={key:'',error:'',paused:false,attempts:0}},showPlaylistFailure(e){c.playlistRecovery.error=e.message;c.playlistRecovery.attempts++},playlistRevisionKey:j=>[j.subscription_id,j.playlist_version,j.playlist_url].join('|'),rememberAuthorizedCache:undefined};
 c.engine={stop(){c.playing=null;return Promise.resolve()}};
 c.buildGroups=()=>{c.state.groups=[...new Set(c.state.items.map(i=>i.group))]};
 c.applyFilter=()=>{c.state.view=c.state.items.map((_,i)=>i)};
 c.play=async i=>{c.state.current=i;c.playing=c.state.items[i].url;plays.push(c.playing)};
 c.fetchText=async url=>{fetches.push(url);if(fail.has(url))throw Error('B download failed');return url===A.playlist_url?text('A'):text('B')};
 c.accessClient=new ActivationClient({identity:async()=> 'd'.repeat(32),storage:{getItem:k=>memory.get(k)||'',setItem:(k,v)=>memory.set(k,v)},onBlock(){c.currentAccess=null;c.engine.stop()},request:async(action,b)=>{if(action==='activate'){if(!grants.has(b.code))throw Error('Invalid test code');const j={...grants.get(b.code)};tokens.clear();tokens.set(j.device_token,j);return j;}if(!tokens.has(b.device_token))throw Error('Replaced token');return{...tokens.get(b.device_token)}}});
 c.ensureAccess=async()=>{const j=await c.accessClient.verify();return!!j&&await c.acceptAccess(j)};
 vm.createContext(c);
 vm.runInContext(script.slice(script.indexOf('  const MEDIA_FILE_RE'),script.indexOf('  function parseExtInf(')),c);
 function add(a,b){vm.runInContext(script.slice(script.indexOf(a),script.indexOf(b,script.indexOf(a))),c)}
 add('  function isCurrentPlaylistGrant(','  async function checkTrial(');
 add('  function setPlaylist(','  function playSingle(');
 add('  async function loadFromUrl(','  /* =====================================================================\n   * Groups + channel list');
 add('  function rememberAuthorizedCache(','  function bigApply(');
 add('  function beginPlaylistSwitch(','  const activationForm =');
 add('  async function loadAuthorized(j) {','  let loadedVersion=null');
 add('  activationForm.addEventListener("submit"','  els.dlg.addEventListener("close"');
 async function activate(code){c.activationCode.value=code;c.els.dlg.open=true;await handler({preventDefault(){}});if(code==='1111111111'&&!c.state.items.length)throw Error('Initial A setup failed: '+c.playlistRecovery.error)}
 return{c,memory,fetches,plays,fail,grants,tokens,activate,close(){clearTimeout(c.accessClient.timer)}};
}
test('new accepted code replaces old channels, source, token and both cache kinds',async()=>{
 const h=setup();try{
  await h.activate('1111111111');assert.equal(h.c.playing,'https://video.test/A.ts');
  h.memory.set('big',{source:A.playlist_url,subscriptionId:1,playlistVersion:1,cacheFormat:5});h.memory.set('history',['old']);h.c.state.big={total:1};
  await h.activate('2222222222');assert.equal(h.c.playing,'https://video.test/B.ts');assert.equal(h.c.state.items[0].name,'B channel');assert.equal(h.c.state.groups[0],'B group');assert.equal(h.c.state.source,B.playlist_url);
  assert.equal(h.c.accessClient.token,B.device_token);assert.equal(h.memory.get('cache').subscriptionId,2);assert.equal(h.memory.has('big'),false);assert.equal(h.memory.has('history'),false);assert.equal(h.c.els.dlg.open,false);
  const checked=await h.c.accessClient.verify(true);assert.equal(checked.playlist_url,B.playlist_url);
 }finally{h.close()}
});
test('same subscription URL update with a new code downloads the new revision',async()=>{
 const h=setup();try{await h.activate('1111111111');h.grants.set('2222222222',{...B,subscription_id:1,playlist_version:2});await h.activate('2222222222');assert.equal(h.c.playing,'https://video.test/B.ts');assert.equal(h.memory.get('cache').playlistVersion,2);assert.equal(h.fetches.length,2)}finally{h.close()}
});
test('regenerated code for unchanged playlist safely reuses that same authorized cache',async()=>{
 const h=setup();try{await h.activate('1111111111');h.grants.set('2222222222',{...A,device_token:B.device_token});await h.activate('2222222222');assert.equal(h.c.playing,'https://video.test/A.ts');assert.equal(h.fetches.length,1);assert.equal(h.c.accessClient.token,B.device_token)}finally{h.close()}
});
test('invalid new code does not replace the previously stored playlist or token',async()=>{
 const h=setup();try{await h.activate('1111111111');await h.activate('9999999999');assert.equal(h.c.accessClient.token,A.device_token);assert.equal(h.memory.get('cache').source,A.playlist_url);assert.equal(h.c.state.items[0].name,'A channel');assert.equal((await h.c.accessClient.verify(true)).playlist_url,A.playlist_url)}finally{h.close()}
});
test('accepted new code with failed download leaves no old channel rows or playable source',async()=>{
 const h=setup();try{await h.activate('1111111111');h.fail.add(B.playlist_url);await h.activate('2222222222');assert.equal(h.c.accessClient.token,B.device_token);assert.equal(h.c.state.items.length,0);assert.equal(h.c.state.view.length,0);assert.equal(h.c.state.groups.length,0);assert.equal(h.c.state.source,'');assert.equal(h.c.playing,null);assert.equal(h.memory.has('cache'),false);assert.equal(h.memory.has('big'),false);assert.equal((await h.c.accessClient.verify(true)).playlist_url,B.playlist_url)}finally{h.close()}
});
test('new import waits for an old native disk-open to finish before replacing its files',async()=>{
 const h=setup();let resolveOpen;try{
  await h.activate('1111111111');h.memory.set('big',{cacheFormat:5,source:A.playlist_url,subscriptionId:1,playlistVersion:1});h.c.state.items=[];h.c.state.big=null;
  const open=new Promise(r=>resolveOpen=r);h.c.bigPlugin=()=>({bigOpen:()=>open});h.c.prepareSavedRestore(A);
  const switching=h.activate('2222222222');await new Promise(r=>setImmediate(r));assert.equal(h.fetches.length,1);
  resolveOpen({total:1,groups:[]});await switching;
  assert.equal(h.fetches.length,2);assert.equal(h.c.playing,'https://video.test/B.ts');assert.equal(h.memory.get('cache').subscriptionId,2);
 }finally{resolveOpen?.(null);h.close()}
});
test('activation notice names active-code and uses app time rather than playlist label or provider days',async()=>{
 const h=setup();try{
  h.grants.set('1111111111',{...A,label:'amdertv',remaining_seconds:12*86400+1,days_left:99});
  await h.activate('1111111111');
  assert.equal(h.c.$('subscriptionNotice').textContent,'active-code · 13 day(s) remaining');
  h.grants.set('2222222222',{...B,label:'another playlist',remaining_seconds:1,days_left:88});
  await h.activate('2222222222');
  assert.equal(h.c.$('subscriptionNotice').textContent,'active-code · 1 day(s) remaining');
 }finally{h.close()}
});

test('saved activation on cold start loads playlist and plays first channel without entering a code',async()=>{
 const h=setup();try{
  h.c.accessClient.token=A.device_token;h.tokens.set(A.device_token,A);
  const verified=await h.c.accessClient.verify(true);
  assert.equal(await h.c.acceptAccess(verified),true);
  await h.c.loadAuthorized(verified);
  assert.equal(h.c.playing,'https://video.test/A.ts');
  assert.equal(h.plays.length,1);assert.equal(h.c.state.current,0);
  assert.equal(h.c.activationCode.value,'');assert.equal(h.c.els.dlg.open,false);
 }finally{h.close()}
});
