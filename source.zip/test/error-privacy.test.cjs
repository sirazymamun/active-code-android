const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),test=require('node:test'),assert=require('node:assert/strict');
const source=fs.readFileSync(path.join(__dirname,'../www/script.js'),'utf8');
function setup(request){
 const c={API_BASE:'https://private.invalid/api.php',root:{Capacitor:{isNativePlatform:()=>true}},callNativeMethod:request,withTimeout:p=>p};
 vm.createContext(c);
 vm.runInContext(source.slice(source.indexOf('  function publicError('),source.indexOf('  function startupProgress(')),c);
 vm.runInContext(source.slice(source.indexOf('  async function activationRequest('),source.indexOf('  function accessBlocked(')),c);
 return c;
}
test('all activation HTTP failures hide server text and preserve denial semantics',async()=>{
 for(const status of [400,401,403,404,409,410,429,500,502,503]){
  const c=setup(async()=>({status,data:JSON.stringify({error:'https://private.invalid/api.php token=SECRET 192.0.2.1'})}));
  for(const action of ['activate','device-check']){
   await assert.rejects(c.activationRequest(action,{}),e=>{
    assert.doesNotMatch(e.message,/private|SECRET|192\.0|api.php|HTTP/);
    assert.equal(e.activationRequired,status===403);return true;
   });
  }
 }
});
test('network exceptions and malformed responses never expose native API details',async()=>{
 for(const request of [
  async()=>{throw Error('POST https://private.invalid/api.php?token=SECRET read tcp 192.0.2.1')},
  async()=>({status:200,data:'<html>private.invalid SECRET</html>'})
 ]){
  const c=setup(request);
  await assert.rejects(c.activationRequest('device-check',{}),e=>{
   assert.doesNotMatch(e.message,/private|SECRET|192\.0|api.php/);return true;
  });
 }
});
test('public error boundary accepts only known messages',()=>{
 const c=setup(async()=>{});
 for(const text of ['provider.internal secret','https://private.invalid','SQLSTATE password SECRET','read tcp 192.0.2.1']){
  assert.notEqual(c.publicError(text),text);
 }
 assert.equal(c.publicError('No signal!'),'No signal!');
});
test('Android source contains no embedded BOM characters',()=>{
 const root=path.join(__dirname,'..');
 function walk(dir){
  for(const e of fs.readdirSync(dir,{withFileTypes:true})){
   const file=path.join(dir,e.name);
   if(e.isDirectory())walk(file);
   else if(/\.(js|mjs|java|tpl|html|css|json|xml)$/.test(e.name)){
    assert.equal(fs.readFileSync(file,'utf8').includes('\uFEFF'),false,path.relative(root,file));
   }
  }
 }
 walk(path.join(root,'www'));walk(path.join(root,'native'));
});
