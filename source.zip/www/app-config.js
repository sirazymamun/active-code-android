window.ACTIVE_CODE_CONFIG = Object.freeze({ apiBase: "https://active-code.netcolink.com/api.php" });
