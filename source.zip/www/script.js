/* active-code — full-screen media player UI.
 * On Android the video is drawn by a native ExoPlayer behind this transparent page (see native/).
 * In a normal browser it falls back to an HTML5 <video> (+ hls.js) so the UI can still be tested.
 */
(function (root) {
  "use strict";

  const DEFAULT_UA =
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";
  const HLS_CDN = "https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js";
  const SAVED_CACHE_FORMAT = 5;

  /* =====================================================================
   * Parsing (pure functions)
   * ===================================================================== */
  const SCHEME_RE = /^[a-z][a-z0-9+.-]*:\/\//i;
  const MEDIA_FILE_RE =
    /\.(mp4|m4v|mkv|webm|mov|avi|flv|mp3|aac|m4a|ogg|opus|wav|ts|mts|m2ts)(\?|#|$)/i;
  const HLS_URL_RE = /\.m3u8?(\?|#|$)/i;
  const UNSUPPORTED_RE = /^(rtmp|rtmps|rtmpe|mms|mmsh|srt):/i;

  function parseExtInf(line) {
    const body = line.replace(/^#EXTINF:/i, "");
    const attrs = {};
    const re = /([\w.-]+)="([^"]*)"/g;
    let m;
    while ((m = re.exec(body))) attrs[m[1].toLowerCase()] = m[2];
    const stripped = body.replace(/([\w.-]+)="[^"]*"/g, "");
    const comma = stripped.indexOf(",");
    const name = comma >= 0 ? stripped.slice(comma + 1).trim() : "";
    return {
      name: name || attrs["tvg-name"] || "",
      group: attrs["group-title"] || "",
      kindHint:
        attrs["stream-type"] ||
        attrs["media-type"] ||
        attrs["tvg-type"] ||
        attrs.type ||
        "",
    };
  }

  function nameFromUrl(url) {
    try {
      const u = new URL(url);
      const last = decodeURIComponent(
        u.pathname.split("/").filter(Boolean).pop() || "",
      );
      return last || u.hostname;
    } catch (e) {
      return String(url).slice(0, 60);
    }
  }

  /** "User-Agent=Foo&Referer=http%3A%2F%2Fx" -> { "User-Agent": "Foo", Referer: "http://x" } */
  function parseHeaderString(s) {
    const out = {};
    String(s)
      .split("&")
      .forEach((pair) => {
        const i = pair.indexOf("=");
        if (i <= 0) return;
        const k = pair.slice(0, i).trim();
        const raw = pair.slice(i + 1);
        try {
          out[k] = decodeURIComponent(raw);
        } catch (e) {
          out[k] = raw;
        }
      });
    return out;
  }

  /** True when the text is a single HLS manifest (master or media playlist) rather than a channel list. */
  function isHlsManifest(text) {
    return /#EXT-X-(STREAM-INF|TARGETDURATION|MEDIA-SEQUENCE|MEDIA:|I-FRAME-STREAM-INF)/i.test(
      text,
    );
  }

  /** Parse an M3U / M3U_PLUS channel list (or a plain list of URLs). Returns [{name,url,group,headers?}]. */
  function parseM3U(text, baseUrl) {
    text = String(text || "").replace(/^\uFEFF/, "");
    const hasExt = /#EXTM3U|#EXTINF/i.test(text);
    const items = [];
    let cur = null;
    let pendingGroup = "";
    let optHeaders = {};

    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line) continue;

      if (/^#EXTINF/i.test(line)) {
        cur = parseExtInf(line);
        continue;
      }
      if (/^#EXTGRP:/i.test(line)) {
        pendingGroup = line.slice(8).trim();
        continue;
      }

      const vlc = line.match(
        /^#EXTVLCOPT:\s*http-(user-agent|referrer|referer)\s*=\s*(.*)$/i,
      );
      if (vlc) {
        optHeaders[/^user/i.test(vlc[1]) ? "User-Agent" : "Referer"] =
          vlc[2].trim();
        continue;
      }
      if (/^#EXTHTTP:/i.test(line)) {
        try {
          const obj = JSON.parse(line.slice(9));
          for (const k of Object.keys(obj))
            if (typeof obj[k] === "string") optHeaders[k] = obj[k];
        } catch (e) {
          /* ignore malformed */
        }
        continue;
      }
      if (line[0] === "#") continue; // other tags / comments

      let url = line;
      let pipeHeaders = null;
      // Kodi style "url|User-Agent=...&Referer=..."
      const pipe = url.indexOf("|");
      if (pipe > 0 && /^[\w-]+=/.test(url.slice(pipe + 1))) {
        pipeHeaders = parseHeaderString(url.slice(pipe + 1));
        url = url.slice(0, pipe);
      }

      if (!SCHEME_RE.test(url)) {
        if (!hasExt) { cur = null; pendingGroup = ""; optHeaders = {}; continue; } // ignore junk lines
        if (baseUrl) {
          try {
            url = new URL(url, baseUrl).href;
          } catch (e) {
            cur = null;
            pendingGroup = "";
            optHeaders = {};
            continue;
          }
        } else {
          cur = null;
          pendingGroup = "";
          optHeaders = {};
          continue;
        }
      }

      const entry = cur || { name: "", group: "" };
      if (!entry.group && pendingGroup) entry.group = pendingGroup;
      entry.url = url;
      if (!entry.name) entry.name = nameFromUrl(url);
      const headers = Object.assign({}, optHeaders, pipeHeaders || {});
      if (Object.keys(headers).length) entry.headers = headers;
      items.push(entry);
      cur = null;
      pendingGroup = "";
      optHeaders = {};
    }
    return items;
  }

  function mediaKind(item) {
    let path = "", query = "";
    const hint = String((item && item.kindHint) || "").trim().toLowerCase();
    const name = String((item && item.name) || "");
    try {
      const parsed = new URL(String((item && item.url) || ""));
      path = decodeURIComponent(parsed.pathname).toLowerCase();
      query = parsed.search.toLowerCase();
    } catch (_) { return "live"; }
    // Category names describe channel genres, never the delivery type.
    // A known live path wins even when a provider sends conflicting metadata.
    if (/\/live\//.test(path) || /[?&](?:type|stream_type|media_type)=live(?:[&#]|$)/.test(query)) return "live";
    if (hint === "live") return "live";
    if (/\/(?:series|tv[ _-]?series|episodes?)\//.test(path) || /[?&](?:type|stream_type|media_type)=(?:series|episode)(?:[&#]|$)/.test(query)) return "series";
    if (/\/(?:movie|movies|vod|film|films)\//.test(path) || /[?&](?:type|stream_type|media_type)=(?:movie|movies|vod|film)(?:[&#]|$)/.test(query)) return "movie";
    if (/^(?:series|episode|tv_series)$/.test(hint)) return "series";
    if (/^(?:movie|movies|vod|film)$/.test(hint)) return "movie";
    if (/\.(?:mp4|mkv|avi|mov|m4v)$/.test(path)) {
      return /\bs\d{1,2}\s*e\d{1,3}\b|\b\d{1,2}x\d{1,3}\b|\b(?:episode|season)\s*\d+|الحلقة\s*\d+|পর্ব\s*\d+/i.test(name) ? "series" : "movie";
    }
    return "live";
  }

  /** Tidy user input into a fetchable URL. */
  function normalizeUrl(raw) {
    let url = String(raw || "").trim();
    if (!url) return "";
    if (!SCHEME_RE.test(url)) url = "https://" + url;
    const gh = url.match(
      /^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/blob\/(.+)$/i,
    );
    if (gh)
      url = `https://raw.githubusercontent.com/${gh[1]}/${gh[2]}/${gh[3]}`;
    return url;
  }

  /* ---------- native HTTP helper (no CORS, follows http<->https redirects) ---------- */
  function headerValue(headers, name) {
    if (!headers) return "";
    const n = name.toLowerCase();
    for (const k of Object.keys(headers))
      if (k.toLowerCase() === n) return String(headers[k]);
    return "";
  }

  /** `call` is CapacitorHttp.request. Redirects are followed here because Android's HttpURLConnection will not cross http<->https. */
  async function httpGet(call, url, headers, responseType, timeoutMs) {
    let cur = url;
    for (let hop = 0; hop < 6; hop++) {
      const res = await call({
        url: cur,
        method: "GET",
        headers: Object.assign(
          { "User-Agent": DEFAULT_UA, Accept: "*/*" },
          headers || {},
        ),
        responseType: responseType || "text",
        disableRedirects: true,
        connectTimeout: 15000,
        readTimeout: timeoutMs || 30000,
      });
      if (res && res.status >= 300 && res.status < 400) {
        const loc = headerValue(res.headers, "location");
        if (loc) {
          cur = new URL(loc, cur).href;
          continue;
        }
      }
      res.finalUrl = cur;
      return res;
    }
    throw new Error("Too many redirects");
  }

  /* ---------- Xtream Codes login (what Televizo / IPTV Smarters do) ---------- */
  /** Upgrade an HTTP playlist URL to its conventional HTTPS endpoint for retry only. */
  function httpsAlternative(raw) {
    try {
      const u = new URL(raw);
      if (u.protocol !== "http:") return null;
      u.protocol = "https:";
      if (u.port === "80") u.port = "";
      return u.href;
    } catch (e) {
      return null;
    }
  }

  /** Detect classic Xtream get.php links and XUI/Xtream /playlist/user/pass/m3u_plus links. */
  function parseXtreamUrl(raw) {
    let u;
    try {
      u = new URL(raw);
    } catch (e) {
      return null;
    }
    if (/\/(get|panel_api|player_api)\.php$/i.test(u.pathname)) {
      const username = u.searchParams.get("username"),
        password = u.searchParams.get("password");
      if (!username || !password) return null;
      const dir = u.pathname.replace(/\/[^/]*$/, "");
      return {
        base: u.origin + dir,
        username,
        password,
        output: (u.searchParams.get("output") || "ts").toLowerCase(),
      };
    }
    // XUI One commonly publishes playlists as /playlist/{username}/{password}/m3u_plus.
    // If the M3U endpoint is unavailable or returns no channels, use the same account via player_api.php.
    const xui = u.pathname.match(
      /^(.*)\/playlist\/([^/]+)\/([^/]+)\/(?:m3u_plus|m3u|m3u_plus\.php|m3u\.php)\/?$/i,
    );
    if (xui) {
      let username, password;
      try {
        username = decodeURIComponent(xui[2]);
        password = decodeURIComponent(xui[3]);
      } catch (e) {
        username = xui[2];
        password = xui[3];
      }
      if (!username || !password) return null;
      return {
        base: u.origin + (xui[1] || ""),
        username,
        password,
        output: "ts",
      };
    }
    return null;
  }

  /** Build an M3U from player_api.php live categories + streams. */
  function xtreamToM3U(x, cats, streams, vodCats, vods) {
    const names = {};
    (Array.isArray(cats) ? cats : []).forEach((c) => {
      names[c.category_id] = c.category_name;
    });
    const ext = x.output === "m3u8" || x.output === "hls" ? "m3u8" : "ts";
    const q = (v) =>
      String(v == null ? "" : v)
        .replace(/"/g, "'")
        .replace(/[\r\n]+/g, " ");
    const lines = ["#EXTM3U"];
    (Array.isArray(streams) ? streams : []).forEach((st) => {
      if (st.stream_id == null) return;
      lines.push(
        `#EXTINF:-1 tvg-id="${q(st.epg_channel_id)}" group-title="${q(names[st.category_id] || "")}",${q(st.name)}`,
      );
      lines.push(
        `${x.base}/live/${encodeURIComponent(x.username)}/${encodeURIComponent(x.password)}/${st.stream_id}.${ext}`,
      );
    });
    const vnames = {};
    (Array.isArray(vodCats) ? vodCats : []).forEach((c) => {
      vnames[c.category_id] = c.category_name;
    });
    (Array.isArray(vods) ? vods : []).forEach((st) => {
      if (st.stream_id == null) return;
      lines.push(
        `#EXTINF:-1 group-title="${q(vnames[st.category_id] || "Movies")}",${q(st.name)}`,
      );
      lines.push(
        `${x.base}/movie/${encodeURIComponent(x.username)}/${encodeURIComponent(x.password)}/${st.stream_id}.${q(st.container_extension) || "mp4"}`,
      );
    });
    return lines.join("\n");
  }

  /** Download through the native plugin (streams big playlists, delivers them in chunks). */
  async function fetchViaPlugin(plugin, url, kind, uas) {
    const r = await plugin.fetchStart({
      url,
      kind: kind || "playlist",
      userAgents: uas,
    });
    if (r && r.big)
      return { big: true, total: r.total, groups: r.groups || [] };
    let text = "",
      offset = 0;
    try {
      for (let i = 0; i < 400; i++) {
        const c = await plugin.fetchRead({ id: r.id, offset, length: 400000 });
        text += c.text;
        offset += c.text.length;
        if (c.done) break;
      }
    } finally {
      try {
        await plugin.fetchDone({ id: r.id });
      } catch (e) {
        /* ignore */
      }
    }
    return text;
  }

  // Android's injected bridge exposes Plugins/nativePromise even when the
  // optional @capacitor/core JavaScript registry has not been loaded.
  async function callNativeMethod(cap, pluginName, methodName, options = {}) {
    if (!cap || typeof cap.isNativePlatform !== "function" || !cap.isNativePlatform())
      throw new Error("Use the installed Android app.");
    let plugin = cap.Plugins && cap.Plugins[pluginName];
    if (plugin && typeof plugin[methodName] === "function")
      return plugin[methodName](options);
    if (typeof cap.registerPlugin === "function") {
      plugin = cap.registerPlugin(pluginName);
      if (plugin && typeof plugin[methodName] === "function")
        return plugin[methodName](options);
    }
    if (typeof cap.nativePromise === "function")
      return cap.nativePromise(pluginName, methodName, options);
    throw new Error(pluginName + " native plugin is unavailable. Please rebuild the Android app.");
  }

  /** A saved playlist is reusable only for the exact server-authorized revision. */
  function savedCacheMatches(meta, grant) {
    return !!meta && !!grant &&
      Number(meta.cacheFormat) === SAVED_CACHE_FORMAT &&
      Number(meta.subscriptionId) === Number(grant.subscription_id) &&
      Number(meta.playlistVersion) === Number(grant.playlist_version) &&
      normalizeUrl(meta.source) === normalizeUrl(grant.playlist_url);
  }

  const api = {
    callNativeMethod,
    fetchViaPlugin,
    parseXtreamUrl,
    httpsAlternative,
    xtreamToM3U,
    parseM3U,
    parseExtInf,
    parseHeaderString,
    isHlsManifest,
    normalizeUrl,
    nameFromUrl,
    headerValue,
    httpGet,
    savedCacheMatches,
    mediaKind,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof document === "undefined") return; // Node (tests): stop here

  /* =====================================================================
   * App
   * ===================================================================== */
  const $ = (id) => document.getElementById(id);
  const els = {
    msgText: $("msgText"),
    msgClose: $("msgClose"),
    webVideo: $("webVideo"),
    tapzone: $("tapzone"),
    zap: $("zap"),
    spinner: $("spinner"),
    msg: $("msg"),
    overlay: $("overlay"),
    audioWiz: $("audioWiz"),
    awList: $("awList"),
    awTitle: $("awTitle"),
    btnSearch: $("btnSearch"),
    btnRecord: $("btnRecord"),
    recBadge: $("recBadge"),
    btnOpen: $("btnOpen"),
    btnRefresh: $("btnRefresh"),
    btnInfo: $("btnInfo"),
    groupList: $("groupList"),
    columnProgress: $("columnProgress"),
    columnProgressThumb: $("columnProgressThumb"),
    listWrap: $("listWrap"),
    list: $("list"),
    emptyList: $("emptyList"),
    emptyText: $("emptyText"),
    welcome: $("welcome"),
    btnWelcomeAdd: $("btnWelcomeAdd"),
    dlg: $("dlg"),
    dlgStatus: $("dlgStatus"),
    toast: $("toast"),
  };

  const PAGE = 100;
  const HIDE_AFTER_MS = 15000;
  // A dead first channel must never leave the full-screen startup layer above
  // the channel browser forever. The native 5-second watchdog remains intact;
  // this longer UI timeout gives slow providers time while keeping navigation usable.
  const STARTUP_PLAY_TIMEOUT_MS = 12000;
  const KEY = {
    history: "m3u.history",
    cache: "m3u.cache",
    last: "m3u.last",
    big: "m3u.big",
    lastItem: "m3u.lastItem",
  };

  const store = {
    get(k, d) {
      try {
        const v = localStorage.getItem(k);
        return v == null ? d : JSON.parse(v);
      } catch (e) {
        return d;
      }
    },
    set(k, v) {
      try {
        localStorage.setItem(k, JSON.stringify(v));
        return true;
      } catch (e) {
        return false;
      }
    },
    del(k) {
      try {
        localStorage.removeItem(k);
      } catch (e) {
        /* ignore */
      }
    },
  };

  const FREE_TRIAL_EXPIRED_MESSAGE = "Subscription inactive. Contact your vendor.";
  const API_BASE = window.ACTIVE_CODE_CONFIG.apiBase;
  let trialResult = {allowed:false, verification_failed:false, message:"Enter your activation code."};
  let currentAccess = null, accessLoading = false, activationBusy = false;
  let playlistEpoch = 0;
  const savedOpenRequests = new Set();
  let startupLoading = document.documentElement.classList.contains("has-saved-activation");
  function startupProgress(phase) {
    startupLoading = true;
    const loader = $("startupLoader");
    if (loader) loader.classList.remove("playlist-load-failed");
    const title = $("startupTitle"); if (title) title.textContent = "Loading! Please wait.";
    const recovery = $("startupRecovery"); if (recovery) recovery.hidden = true;
    closeDialog();
    $("startupStage").textContent = phase || "Checking subscription…";
    document.documentElement.classList.add("has-saved-activation");
  }
  function finishStartupLoading() {
    startupLoading = false;
    document.documentElement.classList.remove("has-saved-activation");
  }
  async function deviceIdentity() {
    const cap = root.Capacitor;
    if (!cap?.isNativePlatform?.()) throw Error("Install the Android app to activate this device.");
    const r = await callNativeMethod(cap, "TrialIdentity", "getId");
    if (!/^[a-f0-9]{32}$/.test(r.deviceId||"")) throw Error("Device identification failed.");
    return r.deviceId;
  }
  async function activationRequest(action, body) {
    if (!/^https:\/\//i.test(API_BASE) || API_BASE.includes("YOUR-DOMAIN")) throw Error("Configure the website HTTPS API address in app-config.js before building the APK.");
    const cap = root.Capacitor;
    if (!cap?.isNativePlatform?.()) throw Error("Use the installed Android app.");
    const r = await withTimeout(callNativeMethod(cap, "CapacitorHttp", "request", {url:API_BASE+"?action="+action,method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},data:body,responseType:"text",connectTimeout:10000,readTimeout:10000}),15000,"Access verification timed out.");
    let j;try{j=typeof r.data==="string"?JSON.parse(r.data.replace(/^\uFEFF/,"")):r.data;}catch(_){throw Error("Invalid website response. Check hosting/API configuration.");}
    if(r.status<200||r.status>=300||!j?.ok){const error=Error(j?.error||"Subscription verification failed.");error.activationRequired=r.status===403;throw error;}
    return j;
  }
  function accessBlocked(message) {
    finishStartupLoading();
    ++playRequest;
    cancelPlaybackWait();
    ui.playbackPending=false;
    ui.playbackFailed=false;
    currentAccess = null;
    const needsCode=!accessClient.token;
    trialResult={allowed:false,verification_failed:!needsCode,message};
    const n=$("subscriptionNotice");if(n)n.textContent=needsCode?"No active subscription.":"";
    try {nativePlugin()?.accessGrant?.({seconds:0})?.catch?.(()=>{});}catch(_){}
    try { const result=engine.stop(); if(result?.catch)result.catch(()=>{}); } catch(_){}
    if(typeof rec!=="undefined" && rec.on)stopRecording().catch(()=>{});
    setBusy(false);
    if(needsCode)setMsg("");
    else if(els.dlg.open)setStatus(message,true);
    else setMsg(message,true);
    syncWelcome();
  }
  // A WebView may suspend JavaScript timers while the app is in the background.
  // When the short playback lease is due, re-check the server instead of showing
  // a stale "expired" message before that check has even run.
  let playbackLeaseDue = false;
  const accessClient = new root.ActivationClient({
    request: activationRequest,
    identity: deviceIdentity,
    storage: localStorage,
    onBlock: accessBlocked,
    onLeaseDue: () => {
      playbackLeaseDue = true;
      if (!document.hidden) syncSubscription();
    },
  });
  function isCurrentPlaylistGrant(j, epoch = playlistEpoch) {
    const live=accessClient.value;
    return epoch === playlistEpoch && !!j && !!live
      && Number(j.subscription_id) === Number(live.subscription_id)
      && Number(j.playlist_version) === Number(live.playlist_version)
      && normalizeUrl(j.playlist_url) === normalizeUrl(live.playlist_url);
  }
  async function acceptAccess(j, epoch = playlistEpoch) {
    if (!isCurrentPlaylistGrant(j, epoch)) return false;
    const native=nativePlugin();
    if(native?.accessGrant)await native.accessGrant({seconds:Math.max(0,(accessClient.deadline-performance.now())/1000)});
    if (!isCurrentPlaylistGrant(j, epoch)) return false;
    currentAccess=j;
    trialResult={allowed:true,verification_failed:false,message:""};
    $("subscriptionNotice").textContent=j.label+" · "+j.days_left+" day(s) remaining";
    setMsg("");
    return true;
  }
  async function checkTrial(force=false) {
    const j=await accessClient.verify(force);
    if(j)await acceptAccess(j);
    return trialResult;
  }
  async function ensureAccess() {await checkTrial();return !!currentAccess&&accessClient.deadline>performance.now();}

  const state = {
    items: [],
    view: [],
    rendered: 0,
    current: -1,
    big: null,
    winTotal: 0,
    label: "",
    source: "",
    group: "all",
    groups: [],
  };
  const ui = {
    pane: "channels",
    gSel: 0,
    cSel: 0,
    bSel: 0,
    hideTimer: 0,
    zapTimer: 0,
    vod: false,
    toastTimer: 0,
  };

  /* ---------- small helpers ---------- */
  const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
  function toast(msg, ms) {
    els.toast.textContent = msg;
    els.toast.hidden = false;
    clearTimeout(ui.toastTimer);
    ui.toastTimer = setTimeout(() => {
      els.toast.hidden = true;
    }, ms || 3500);
  }
  function setStatus(msg, isError) {
    const text = msg || "";
    const isPlaylistProgress =
      /^(?:Loading playlist|Downloading|Reading playlist|Importing channels|Playlist download failed)/i.test(text);
    // Playlist progress used to be written only into the activation dialog.
    // Once a code is accepted that dialog is closed, so show the same useful
    // text in the full-screen startup stage or the normal player message area.
    if (!isError && isPlaylistProgress) {
      if (startupLoading) startupProgress(text.replace(/\.{3}/g, "…"));
      else if (!dialogOpen()) setMsg(text);
    }
    if (isError) finishStartupLoading();

    els.dlgStatus.textContent = text;
    els.dlgStatus.classList.toggle("playlist-progress", isPlaylistProgress);
    if (msg) {
      try {
        els.dlgStatus.scrollIntoView({ block: "nearest" });
      } catch (e) {
        /* ignore */
      }
    }
    els.dlgStatus.classList.toggle("error", !!isError);
  }
  function withTimeout(promise, ms, message) {
    let timer;
    const t = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(message)), ms);
    });
    return Promise.race([promise, t]).finally(() => clearTimeout(timer));
  }
  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = src;
      s.onload = resolve;
      s.onerror = () => reject(new Error("Failed to load " + src));
      document.head.appendChild(s);
    });
  }

  /* ---------- native bridge ---------- */
  let fetchProgress = null;
  function nativePlugin() {
    const cap = root.Capacitor;
    if (!cap || !(cap.isNativePlatform && cap.isNativePlatform())) return null;
    try {
      if (cap.isPluginAvailable && !cap.isPluginAvailable("NativePlayer"))
        return null;
      const p = cap.registerPlugin
        ? cap.registerPlugin("NativePlayer")
        : cap.Plugins && cap.Plugins.NativePlayer;
      return p && p.fetchStart ? p : null;
    } catch (e) {
      return null;
    }
  }
  /** Leave a note in native storage so we can tell what happened if the app stops unexpectedly. */
  function crumb(text) {
    try {
      const p = nativePlugin();
      if (p && p.crumb) p.crumb({ text });
    } catch (e) {
      /* ignore */
    }
  }
  let progressHooked = false;
  function hookProgress(p) {
    if (progressHooked) return;
    progressHooked = true;
    try {
      p.addListener("fetchProgress", (e) => {
        if (fetchProgress && e) fetchProgress(e);
      });
    } catch (err) {
      /* ignore */
    }
  }

  function nativeCall() {
    const cap = root.Capacitor;
    if (!cap || !(cap.isNativePlatform && cap.isNativePlatform())) return null;
    const p = cap.Plugins && cap.Plugins.CapacitorHttp;
    if (p && p.request) return (o) => p.request(o);
    if (cap.nativePromise)
      return (o) => cap.nativePromise("CapacitorHttp", "request", o);
    return null;
  }

  /* =====================================================================
   * Playback engines
   * ===================================================================== */
  function createNativeEngine() {
    const cap = root.Capacitor;
    if (!cap || !(cap.isNativePlatform && cap.isNativePlatform())) return null;
    let plugin = null;
    try {
      if (cap.isPluginAvailable && !cap.isPluginAvailable("NativePlayer"))
        return null;
      plugin = cap.registerPlugin
        ? cap.registerPlugin("NativePlayer")
        : cap.Plugins && cap.Plugins.NativePlayer;
    } catch (e) {
      return null;
    }
    if (!plugin) return null;
    return {
      native: true,
      onState(cb) {
        plugin.addListener("state", cb);
      },
      onAudioTracks(cb) {
        plugin.addListener("audioTracks", cb);
      },
      setAudioTrack(id) {
        return plugin.setAudioTrack({ id });
      },
      recordStart(mode, name) {
        return plugin.recordStart({ mode, name });
      },
      recordStop() {
        return plugin.recordStop();
      },
      play(item, requestId) {
        return plugin.play({ url: item.url, headers: item.headers || {}, requestId });
      },
      recover(requestId) {
        return plugin.tryFallback({ requestId });
      },
      stop() {
        return plugin.stop();
      },
      setAspect(mode) {
        return plugin.setResizeMode({ mode });
      },
      seek(seconds) {
        return plugin.seekBy({ seconds });
      },
      async info() {
        const r = await plugin.info();
        return (r && r.text) || "No information yet.";
      },
    };
  }

  function createWebEngine() {
    const v = els.webVideo;
    let hls = null;
    let cb = () => {};
    v.hidden = false;
    v.addEventListener("waiting", () => cb({ state: "buffering" }));
    v.addEventListener("playing", () => cb({ state: "playing" }));
    v.addEventListener("ended", () => cb({ state: "ended" }));
    v.addEventListener("error", () =>
      cb({
        state: "error",
        message: "media error " + (v.error ? v.error.code : ""),
      }),
    );
    function stop() {
      if (hls) {
        try {
          hls.destroy();
        } catch (e) {
          /* ignore */
        }
        hls = null;
      }
      v.pause();
      v.removeAttribute("src");
      v.load();
    }
    return {
      native: false,
      onState(f) {
        cb = f;
      },
      onAudioTracks() {
        /* browser preview has no audio track choice */
      },
      setAudioTrack() {
        return Promise.resolve();
      },
      recordStart() {
        return Promise.reject(
          new Error("Recording works only in the Android app."),
        );
      },
      recordStop() {
        return Promise.resolve({});
      },
      async play(item) {
        stop();
        cb({ state: "buffering" });
        const wantHls =
          HLS_URL_RE.test(item.url) || !MEDIA_FILE_RE.test(item.url);
        if (wantHls && !root.Hls) {
          try {
            await loadScript(HLS_CDN);
          } catch (e) {
            /* offline */
          }
        }
        if (wantHls && root.Hls && root.Hls.isSupported()) {
          hls = new root.Hls();
          hls.on(root.Hls.Events.ERROR, (e, d) => {
            if (d.fatal) cb({ state: "error", message: d.details });
          });
          hls.loadSource(item.url);
          hls.attachMedia(v);
        } else {
          v.src = item.url;
        }
        try {
          await v.play();
        } catch (e) {
          /* autoplay blocked: user can tap */
        }
      },
      stop() {
        stop();
        return Promise.resolve();
      },
      seek(seconds) {
        v.currentTime = Math.max(0, v.currentTime + seconds);
        return Promise.resolve();
      },
      info() {
        return Promise.resolve(
          "Browser preview mode: no native player details.",
        );
      },
      setAspect(mode) {
        v.style.objectFit =
          mode === "zoom" ? "cover" : mode === "fill" ? "fill" : "contain";
        return Promise.resolve();
      },
    };
  }

  const engine = createNativeEngine() || createWebEngine();

  /* ---------- fetching playlists ---------- */
  const FETCH_UAS = [
    "IPTVSmartersPro",
    DEFAULT_UA,
    "VLC/3.0.18 LibVLC/3.0.18",
    "okhttp/4.12.0",
    "Lavf/60.16.100",
  ];
  async function fetchPlaylistNative(call, url) {
    let lastErr = "";
    for (const ua of FETCH_UAS.slice(0, 3)) {
      try {
        const res = await withTimeout(
          httpGet(call, url, { "User-Agent": ua }, "text", 6000),
          7000,
          "Timed out waiting for the server",
        );
        const body =
          typeof res.data === "string"
            ? res.data
            : JSON.stringify(res.data || "");
        if (res.status >= 400) {
          lastErr = "Server answered HTTP " + res.status;
          continue;
        }
        if (!body.trim()) {
          lastErr =
            "Server sent an empty reply (account expired, too many connections, or blocked)";
          continue;
        }
        if (/^\s*<(!doctype|html)/i.test(body)) {
          lastErr =
            "Server sent a web page instead of a playlist: " +
            body
              .replace(/<[^>]+>/g, " ")
              .replace(/\s+/g, " ")
              .trim()
              .slice(0, 120);
          continue;
        }
        return { text: body };
      } catch (err) {
        lastErr = (err && err.message) || String(err);
      }
    }
    return { error: lastErr };
  }
  async function fetchJsonNative(call, url) {
    let lastErr = "";
    for (const ua of FETCH_UAS.slice(0, 2)) {
      try {
        const res = await withTimeout(
          httpGet(call, url, { "User-Agent": ua }, "text", 7000),
          8000,
          "Timed out waiting for the server",
        );
        if (res.status >= 400) {
          lastErr = "HTTP " + res.status;
          continue;
        }
        const json =
          typeof res.data === "string" ? JSON.parse(res.data) : res.data;
        return { json };
      } catch (err) {
        lastErr = (err && err.message) || String(err);
      }
    }
    return { error: lastErr };
  }
  /** Many IPTV servers only answer to player-like User-Agents, so try several before giving up. */
  async function fetchText(url) {
    const plugin = nativePlugin();
    if (plugin) {
      hookProgress(plugin);
      fetchProgress = (e) =>
        setStatus(
          e.entries != null
            ? "Reading playlist..., please don't do anything. " + Number(e.entries).toLocaleString()
            : "Downloading..., please don't do anything. " + (e.bytes / 1048576).toFixed(1) + " MB",
        );
      try {
        let firstErr = "";
        // Preserve the provider's exact scheme and port. IPTV servers often
        // expose plaintext HTTP on :8080; upgrading to TLS produces
        // "Unable to parse TLS packet header" even when the URL is valid.
        const playlistAttempts = [url];
        for (const candidate of playlistAttempts) {
          try {
            const direct = await fetchViaPlugin(
              plugin,
              candidate,
              "playlist",
              FETCH_UAS,
            );
            if (direct && typeof direct === "object" && direct.big) {
              // Keep per-entry delivery types; category names can also label live channels.
              return direct;
            }
            if (
              typeof direct === "string" &&
              (isHlsManifest(direct) || parseM3U(direct, candidate).length > 0)
            )
              return direct;
            firstErr = "XUI playlist endpoint returned no playable channels";
          } catch (err) {
            firstErr = (err && err.message) || String(err);
          }
        }
        let x = parseXtreamUrl(url);
        if (x && typeof plugin.xtreamImport === "function") {
          try {
            setStatus("Importing channels to local storage...");
            const imported = await plugin.xtreamImport({
              base: x.base, username: x.username, password: x.password,
            });
            if (imported && imported.big) return imported;
            throw new Error("Xtream API returned no playable entries");
          } catch (importError) {
            // Native import already tried the useful account endpoints within
            // one total budget. Repeating every endpoint again in JavaScript
            // used to turn one failure into another several-minute wait.
            throw new Error(firstErr + "; Xtream import: " +
              ((importError && importError.message) || String(importError)));
          }
        }
        if (x) {
          setStatus(
            "Playlist download failed (" +
              firstErr +
              "). Trying account login…",
          );
          const accountAttempts = [x];
          let accountErr = "no live channels returned";
          for (const account of accountAttempts) {
            const api =
              account.base +
              "/player_api.php?username=" +
              encodeURIComponent(account.username) +
              "&password=" +
              encodeURIComponent(account.password);
            try {
              const cats = JSON.parse(
                await fetchViaPlugin(
                  plugin,
                  api + "&action=get_live_categories",
                  "json",
                  FETCH_UAS,
                ),
              );
              const streams = JSON.parse(
                await fetchViaPlugin(
                  plugin,
                  api + "&action=get_live_streams",
                  "json",
                  FETCH_UAS,
                ),
              );
              let vodCats = [],
                vods = [];
              try {
                vodCats = JSON.parse(
                  await fetchViaPlugin(
                    plugin,
                    api + "&action=get_vod_categories",
                    "json",
                    FETCH_UAS,
                  ),
                );
                vods = JSON.parse(
                  await fetchViaPlugin(
                    plugin,
                    api + "&action=get_vod_streams",
                    "json",
                    FETCH_UAS,
                  ),
                );
              } catch (e3) {
                /* movies are optional */
              }
              if (
                (Array.isArray(streams) && streams.length) ||
                (Array.isArray(vods) && vods.length)
              )
                {
                  // Avoid generating a huge M3U in the WebView after native disk parsing fails.
                  // The direct download error is more useful than a misleading text-size error.
                  const count = (Array.isArray(streams) ? streams.length : 0) +
                    (Array.isArray(vods) ? vods.length : 0);
                  if (count > 3000) {
                    throw new Error("Xtream account has " + count +
                      " entries; native playlist download/parse failed: " + firstErr +
                      ". Large playlists must be loaded from the provider M3U URL on disk.");
                  }
                  return xtreamToM3U(account, cats, streams, vodCats, vods);
                }
              throw new Error("no live channels returned");
            } catch (err2) {
              accountErr = (err2 && err2.message) || String(err2);
              if (accountErr.includes("native playlist download/parse failed:")) break;
            }
          }
          if (accountErr.includes("native playlist download/parse failed:"))
            throw new Error(accountErr);
          throw new Error(
            firstErr + ". Account login also failed: " + accountErr,
          );
        }
        throw new Error(
          firstErr +
            ". If this link is a live stream and not a playlist, contact your subscription vendor.",
        );
      } finally {
        fetchProgress = null;
        crumb("ok (download finished)");
      }
    }
    return withTimeout(
      fetchTextLegacy(url),
      120000,
      "Playlist import timed out after 120 seconds.",
    );
  }
  async function fetchTextLegacy(url) {
    const call = nativeCall();
    if (call) {
      const first = await fetchPlaylistNative(call, url);
      if (first.text) return first.text;
      const x = parseXtreamUrl(url);
      if (x) {
        const api =
          x.base +
          "/player_api.php?username=" +
          encodeURIComponent(x.username) +
          "&password=" +
          encodeURIComponent(x.password);
        const cats = await fetchJsonNative(
          call,
          api + "&action=get_live_categories",
        );
        const streams = await fetchJsonNative(
          call,
          api + "&action=get_live_streams",
        );
        if (streams.json && Array.isArray(streams.json) && streams.json.length)
          return xtreamToM3U(x, cats.json, streams.json);
        throw new Error(
          first.error +
            ". Logging in with the account (player API) also failed: " +
            (streams.error || "no live channels returned") +
            ".",
        );
      }
      throw new Error(
        first.error +
          ". If this link is a live stream and not a playlist, contact your subscription vendor.",
      );
    }
    const ctrl = typeof AbortController === "function" ? new AbortController() : null;
    const request = (async () => {
      const res = await fetch(url, ctrl ? {signal:ctrl.signal} : {});
      if (!res.ok) throw new Error("Server answered HTTP " + res.status);
      return res.text();
    })();
    try { return await withTimeout(request,30000,"Playlist download timed out."); }
    finally { if(ctrl)ctrl.abort(); }
  }

  /* =====================================================================
   * Playlist state
   * ===================================================================== */
  function setPlaylist(items, meta) {
    // Do not retain the old decoder while constructing the new playlist.
    // Stop asynchronously and invalidate any pending play request first.
    ++playRequest;
    try {
      const stopping = engine.stop();
      if (stopping && stopping.catch) stopping.catch(() => {});
    } catch (_) { /* old playback must not block playlist replacement */ }
    if (!items.length)
      throw new Error(
        "No playable entries found. If this link is a stream (not a playlist), contact your subscription vendor.",
      );
    state.big = null;
    store.del(KEY.big);
    state.items = items;
    state.label = meta.label || "Playlist";
    state.source = meta.source || "";
    state.group = "all";
    buildGroups();
    applyFilter();
    els.btnRefresh.hidden = !state.source;

    // Always start at the first playlist entry; never restore the previously playing item.
    state.current = -1;
    store.del(KEY.last);
    store.del(KEY.lastItem);

    // Remember the playlist for the next start (small streams are stored as a tiny playlist of their own).
    const cacheText =
      meta.text || (items.length <= 20 ? itemsToM3U(items) : "");
    if (
      cacheText &&
      cacheText.length < 2500000 &&
      store.set(KEY.cache, {
        label: state.label,
        source: state.source,
        text: cacheText,
      })
    ) {
      /* saved */
    } else store.del(KEY.cache);

  }

  function itemsToM3U(items) {
    const lines = ["#EXTM3U"];
    for (const it of items) {
      lines.push(
        `#EXTINF:-1${it.kindHint ? ' stream-type="' + String(it.kindHint).replace(/"/g, "'") + '"' : ""} group-title="${(it.group || "").replace(/"/g, "'")}",${it.name}`,
      );
      if (it.headers) {
        if (it.headers["User-Agent"])
          lines.push("#EXTVLCOPT:http-user-agent=" + it.headers["User-Agent"]);
        if (it.headers.Referer)
          lines.push("#EXTVLCOPT:http-referrer=" + it.headers.Referer);
      }
      lines.push(it.url);
    }
    return lines.join("\n");
  }

  // Large pasted M3U payloads can block the Android WebView UI thread and
  // exhaust its heap. URLs use the native streaming/on-disk playlist loader.
  const MAX_INLINE_PLAYLIST_CHARS = 1000000;
  function loadFromText(text, meta) {
    meta = meta || {};
    if (typeof text === "string" && text.length > MAX_INLINE_PLAYLIST_CHARS && !meta.source) {
      throw new Error("Playlist text is too large for direct transfer. Send its M3U URL instead so TV2U can load it safely.");
    }
    if (text && typeof text === "object" && text.big)
      return { single: false, big: true, pending: loadBig(text, meta) };
    if (isHlsManifest(text)) {
      if (!meta.source)
        throw new Error(
          "This is a single stream manifest, not a channel list. Ask your vendor to use its stream URL.",
        );
      const name = nameFromUrl(meta.source);
      setPlaylist([{ name, url: meta.source, group: "" }], {
        label: name,
        source: meta.source,
      });
      return { single: true };
    }
    const items = parseM3U(text, meta.source);
    setPlaylist(items, {
      label:
        meta.label ||
        (meta.source ? nameFromUrl(meta.source) : "Pasted playlist"),
      source: meta.source,
      text,
    });
    return { single: false };
  }

  function playSingle(url) {
    const name = nameFromUrl(url);
    setPlaylist([{ name, url, group: "" }], { label: name, source: url });
    closeDialog();
    closeOverlay();
    play(0);
  }

  async function loadFromUrl(raw, asStream, propagateError = false) {
    if (!(await ensureAccess()) || raw !== currentAccess.playlist_url) throw Error("Activate this playlist with a valid code first.");
    const url = normalizeUrl(raw);
    if (!url) return;
    if (asStream || (MEDIA_FILE_RE.test(url) && !HLS_URL_RE.test(url))) {
      playSingle(url);
      return;
    }
    setStatus("Loading playlist..., please don't do anything.");

    try {
      const text = await fetchText(url);
      if (!(await ensureAccess()) || url !== normalizeUrl(currentAccess.playlist_url)) throw Error("Subscription changed or expired during download.");
      if (typeof text === "string") {
        setStatus(
          "Reading playlist..., please don't do anything. " + Math.round(text.length / 1024) + " KB",
        );
        crumb("Reading the channel list (" + text.length + " characters)");
        await new Promise((r) => setTimeout(r, 30));
      }
      const out = loadFromText(text, { source: url });
      if (out.pending) await out.pending;
      crumb(
        "Showing " +
          (state.big ? state.big.total : state.items.length) +
          " channels",
      );
      closeDialog();
      crumb("ok");
      // Start the first playable item as soon as the playlist has been downloaded and parsed.
      // This avoids leaving the player on a black screen until the user manually selects a channel.
      if (state.items.length) {
        closeOverlay();
        play(0);
      } else if (out.single) {
        closeOverlay();
        play(0);
      } else {
        finishStartupLoading();
        setMsg("No playable channels found.", true);
        openOverlay();
      }
    } catch (err) {
      if (HLS_URL_RE.test(url)) {
        try {
          playSingle(url);
          toast("Couldn't read it as a playlist, playing it as a stream…");
          return;
        } catch (e2) {
          /* fall through */
        }
      }
      crumb("ok (failed: " + ((err && err.message) || err) + ")");
      // The authorized loader owns retries and its persistent error screen.
      // Do not dismiss the full-screen loader between failed attempts.
      if (propagateError) throw err;
      setStatus("Couldn't load: " + (err && err.message ? err.message : err), true);
    } finally {

    }
  }

  /* =====================================================================
   * Groups + channel list
   * ===================================================================== */
  /* ---------- very large playlists: channels live in a native on-disk database ---------- */
  let bigSeq = 0,
    bigTimer = 0,
    bigLoading = false;
  const BIG_PAGE = 500;

  function bigPlugin() {
    return nativePlugin();
  }

  function bigGroupsFrom(list) {
    return (list || []).map((g) => ({
      key: g.key,
      label: g.label,
      count: g.count,
    }));
  }

  function bigListPage(offset) {
    return bigPlugin().bigListPage({
      group: state.group,
      offset,
      limit: BIG_PAGE,
    });
  }

  function loadBig(info, meta) {
    state.big = { total: info.total, groupList: info.groups || [] };
    state.label =
      meta.label || (meta.source ? nameFromUrl(meta.source) : "Playlist");
    state.source = meta.source || "";
    state.group = "all";
    state.items = [];
    state.view = [];
    state.groups = bigGroupsFrom(state.big.groupList);
    syncWelcome();
    renderGroups();
    els.btnRefresh.hidden = !state.source;
    store.del(KEY.cache);
    const previous = store.get(KEY.big, null);
    const cacheRecord = { label: state.label, source: state.source };
    if (previous && normalizeUrl(previous.source) === normalizeUrl(state.source)) {
      cacheRecord.subscriptionId = previous.subscriptionId;
      cacheRecord.playlistVersion = previous.playlistVersion;
      cacheRecord.savedAt = previous.savedAt;
    }
    store.set(KEY.big, cacheRecord);

    return bigApply(0);
  }

  function rememberAuthorizedCache(j) {
    const identity = {
      cacheFormat: SAVED_CACHE_FORMAT,
      subscriptionId: Number(j.subscription_id),
      playlistVersion: Number(j.playlist_version),
      source: normalizeUrl(j.playlist_url),
      label: j.label || state.label || "Playlist",
      savedAt: Date.now(),
    };
    if (state.big) {
      store.set(KEY.big, identity);
      store.del(KEY.cache);
      return;
    }
    const cached = store.get(KEY.cache, null);
    if (cached && cached.text) store.set(KEY.cache, Object.assign({}, cached, identity));
  }

  /** Start opening the disk index while the HTTPS subscription check is in flight. */
  function prepareSavedRestore(grant) {
    if (state.items.length || state.big) return null;
    const bigMeta = store.get(KEY.big, null);
    const smallMeta = store.get(KEY.cache, null);
    const plugin = bigPlugin();
    let bigOpen = null;
    if (bigMeta && (!grant || savedCacheMatches(bigMeta, grant)) && plugin && typeof plugin.bigOpen === "function") {
      bigOpen = Promise.resolve(plugin.bigOpen()).catch(() => null);
      savedOpenRequests.add(bigOpen);
      bigOpen.then(() => savedOpenRequests.delete(bigOpen));
    }
    return { bigMeta, smallMeta, bigOpen };
  }

  async function startRestoredPlaylist(j, epoch = playlistEpoch) {
    if (!isCurrentPlaylistGrant(j, epoch)) return false;
    loadedVersion = Number(j.playlist_version);
    loadedSubscription = Number(j.subscription_id);
    rememberAuthorizedCache(j);
    closeDialog();
    crumb("ok (opened saved playlist)");
    if (state.items.length) {
      closeOverlay();
      play(0);
    } else {
      finishStartupLoading();
      return false;
    }
    return true;
  }

  /** Reuse the exact authorized revision; fall back to a network import on any mismatch/corruption. */
  async function restoreAuthorized(j, prepared) {
    const epoch=playlistEpoch;
    if (!isCurrentPlaylistGrant(j, epoch)) return false;
    if (state.source === normalizeUrl(j.playlist_url) &&
        loadedVersion === Number(j.playlist_version) &&
        loadedSubscription === Number(j.subscription_id) &&
        state.items.length) {
      closeDialog(); closeOverlay(); play(state.current >= 0 ? state.current : 0);
      return true;
    }
    const saved = prepared || prepareSavedRestore();
    if (!saved) return false;
    if (savedCacheMatches(saved.bigMeta, j) && saved.bigOpen) {
      startupProgress("Opening saved playlist…");
      const info = await saved.bigOpen;
      if (!isCurrentPlaylistGrant(j, epoch)) return false;
      if (info && Number(info.total) > 0) {
        await loadBig(info, { label: j.label, source: normalizeUrl(j.playlist_url) });
        return startRestoredPlaylist(j, epoch);
      }
    }
    if (savedCacheMatches(saved.smallMeta, j) && saved.smallMeta.text) {
      startupProgress("Opening saved playlist…");
      const out = loadFromText(saved.smallMeta.text, {
        label: j.label,
        source: normalizeUrl(j.playlist_url),
      });
      if (out.pending) await out.pending;
      return startRestoredPlaylist(j, epoch);
    }
    return false;
  }

  function bigApply(delay) {
    clearTimeout(bigTimer);
    // Invalidate old pages immediately, including during the debounce delay.
    const seq = ++bigSeq;
    bigLoading = false;
    const run = async () => {
      setBusy(true);
      try {
        const res = await bigListPage(0);
        if (seq !== bigSeq) return;
        state.items = res.items || [];
        state.view = state.items.map((_, i) => i);
        state.winTotal = res.total || 0;
        state.bigLoadedCount = state.items.length;
        // Big playlists also start from their first entry, never the previously playing channel.
        state.current = -1;
        store.del(KEY.last);
        store.del(KEY.lastItem);
        state.rendered = 0;
        els.list.textContent = "";
        els.listWrap.scrollTop = 0;
        renderMore();
        const empty = state.items.length === 0;
        els.emptyList.hidden = !empty;
        if (empty) els.emptyText.textContent = "No channels here.";
        ui.cSel = state.current < 0 ? 0 : state.current;
        paintCursor();
      } catch (err) {
        if (seq !== bigSeq) return;
        setMsg(
          "Could not load channels: " + ((err && err.message) || err),
          true,
          6000,
        );
      } finally {
        if (seq === bigSeq) setBusy(false);
      }
    };
    if (delay === 0) return run();
    bigTimer = setTimeout(run, delay == null ? 120 : delay);
    return Promise.resolve();
  }

  async function bigLoadMore() {
    if (bigLoading || !state.big || (state.bigLoadedCount || 0) >= state.winTotal)
      return;
    bigLoading = true;
    const seq = bigSeq;
    try {
      const res = await bigListPage(state.bigLoadedCount || 0);
      if (seq !== bigSeq) return;
      state.bigLoadedCount = (state.bigLoadedCount || 0) + (res.items || []).length;
      for (const it of res.items || []) {
        state.view.push(state.items.length);
        state.items.push(it);
      }
      renderMore();
    } catch (err) {
      /* ignore */
    } finally {
      if (seq === bigSeq) bigLoading = false;
    }
  }

  function buildGroups() {
    const counts = new Map();
    const kindCounts = { live: 0, movie: 0, series: 0 };
    for (const it of state.items) {
      const g = it.group || "";
      counts.set(g, (counts.get(g) || 0) + 1);
      kindCounts[mediaKind(it)]++;
    }
    const groups = [
      { key: "k:live", label: "Live TV", count: kindCounts.live },
      { key: "k:movie", label: "Movies", count: kindCounts.movie },
      { key: "k:series", label: "Series", count: kindCounts.series },
    ];
    for (const [g, n] of counts)
      if (g && !/^(?:live tv|movies|series)$/i.test(g))
        groups.push({ key: "g:" + g, label: g, count: n });
    if (counts.has(""))
      groups.push({ key: "g:", label: "Ungrouped", count: counts.get("") });
    state.groups = groups;
    renderGroups();
  }

  function renderGroups() {
    els.groupList.textContent = "";
    state.groups.forEach((g, i) => {
      const li = document.createElement("li");
      li.className = "row group" + (g.key === state.group ? " active" : "");
      li.dataset.g = String(i);
      li.tabIndex = -1;
      const name = document.createElement("div");
      name.className = "name";
      name.textContent = g.label;
      const n = document.createElement("div");
      n.className = "count-badge";
      n.textContent = String(g.count);
      li.append(name, n);
      els.groupList.appendChild(li);
    });
    const idx = state.groups.findIndex((g) => g.key === state.group);
    ui.gSel = idx < 0 ? 0 : idx;
  }

  function applyFilter() {
    syncWelcome();
    if (state.big) {
      bigApply();
      return;
    }
    const g = state.group;
    const view = [];
    for (let i = 0; i < state.items.length; i++) {
      const it = state.items[i];
      if (g === "k:live" && mediaKind(it) !== "live") continue;
      if (g === "k:movie" && mediaKind(it) !== "movie") continue;
      if (g === "k:series" && mediaKind(it) !== "series") continue;
      if (g.startsWith("g:") && (it.group || "") !== g.slice(2)) continue;
      view.push(i);
    }
    state.view = view;
    state.rendered = 0;
    els.list.textContent = "";
    els.listWrap.scrollTop = 0;
    renderMore();

    const empty = view.length === 0;
    els.emptyList.hidden = !empty;
    if (empty) {
      els.emptyText.textContent = "No channels here.";
    }
    const pos = state.view.indexOf(state.current);
    ui.cSel = pos < 0 ? 0 : pos;
  }

  function rowEl(viewPos) {
    const idx = state.view[viewPos];
    const it = state.items[idx];
    const li = document.createElement("li");
    li.className = "row" + (idx === state.current ? " active" : "");
    li.dataset.i = String(idx);
    li.dataset.v = String(viewPos);
    li.tabIndex = -1;

    // Channel rows intentionally show text only; no logo or logo placeholder.
    const meta = document.createElement("div");
    meta.className = "meta";
    const name = document.createElement("div");
    name.className = "name";
    name.textContent = it.name;
    const grp = document.createElement("div");
    grp.className = "grp";
    grp.textContent = it.group || "";
    meta.append(name, grp);

    li.append(meta);
    return li;
  }

  function renderMore() {
    if (state.big && state.rendered >= state.view.length - 40) bigLoadMore();
    const frag = document.createDocumentFragment();
    const end = Math.min(state.rendered + PAGE, state.view.length);
    for (let i = state.rendered; i < end; i++) frag.appendChild(rowEl(i));
    els.list.appendChild(frag);
    state.rendered = end;
    // Keep filling while the list is visible but shorter than its box.
    const w = els.listWrap;
    if (
      w.clientHeight > 0 &&
      w.scrollHeight <= w.clientHeight + 80 &&
      state.rendered < state.view.length
    )
      renderMore();
    updateColumnProgress(false);
  }
  function updateColumnProgress(fromScroll) {
    if (!els.columnProgress || !els.columnProgressThumb) return;
    const onGroups = ui.pane === "groups";
    const total = onGroups
      ? state.groups.length
      : Math.max(0, Number(state.big ? state.winTotal : state.view.length) || 0);
    const scroller = onGroups ? els.groupList.parentElement : els.listWrap;
    const selected = onGroups ? ui.gSel : ui.cSel;
    const trackHeight = Math.max(1, els.columnProgress.clientHeight || scroller.clientHeight || 1);
    // CSS pixels are density independent in Android WebView.  This produces
    // an approximately one-inch marker on a TV and a proportionally compact
    // marker on a phone, while leaving the existing separator untouched.
    const thumbPx = clamp(
      Math.round(Math.min(root.innerHeight * 0.09, root.innerWidth * 0.055)),
      56,
      Math.min(96, trackHeight),
    );
    els.columnProgressThumb.style.height = thumbPx + "px";
    if (!total) {
      els.columnProgressThumb.style.top = "0px";
      return;
    }
    let ratio = total <= 1 ? 0 : clamp(selected / (total - 1), 0, 1);
    if (fromScroll && scroller.scrollHeight > scroller.clientHeight)
      ratio = clamp(scroller.scrollTop / (scroller.scrollHeight - scroller.clientHeight), 0, 1);
    els.columnProgressThumb.style.top = Math.round(ratio * Math.max(0, trackHeight - thumbPx)) + "px";
  }
  function ensureRendered(viewPos) {
    if (state.big && viewPos >= state.view.length - 40) bigLoadMore();
    while (state.rendered <= viewPos && state.rendered < state.view.length)
      renderMore();
  }

  /* ---------- cursor (remote control / keyboard focus) ---------- */
  const barItems = () =>
    [els.btnSearch, els.btnOpen, els.btnRecord, els.btnRefresh, els.btnInfo].filter(
      (b) => !b.hidden,
    );

  function paintCursor(scroll) {
    document.querySelectorAll(".sel").forEach((n) => n.classList.remove("sel"));
    if (els.overlay.hidden) return;
    if (ui.pane === "bar") {
      const items = barItems();
      ui.bSel = clamp(ui.bSel, 0, items.length - 1);
      if (items[ui.bSel]) {
        items[ui.bSel].classList.add("sel");
        // Synchronize real DOM focus with the virtual TV remote cursor.
        if (document.activeElement !== items[ui.bSel]) items[ui.bSel].focus({preventScroll:true});
      }
    } else if (ui.pane === "groups") {
      const el = els.groupList.children[ui.gSel];
      if (el) {
        el.classList.add("sel");
        if (scroll) el.scrollIntoView({ block: "nearest" });
        if (document.activeElement !== el) el.focus({preventScroll:true});
      }
    } else {
      ensureRendered(ui.cSel);
      const el = els.list.querySelector(`.row[data-v="${ui.cSel}"]`);
      if (el) {
        el.classList.add("sel");
        if (scroll) el.scrollIntoView({ block: "nearest" });
        if (document.activeElement !== el) el.focus({preventScroll:true});
      }
    }
    updateColumnProgress(false);
  }

  function selectGroup(i) {
    const g = state.groups[i];
    if (!g) return;
    ui.gSel = i;
    state.group = state.group === g.key ? "all" : g.key;
    applyFilter();
    for (const li of els.groupList.children)
      li.classList.toggle(
        "active",
        state.groups[Number(li.dataset.g)].key === state.group,
      );
  }

  let previousListPane = "channels";
  function focusMenuBar() {
    if (ui.pane !== "bar") previousListPane = ui.pane;
    ui.pane = "bar";
    paintCursor(true);
  }
  function returnFromMenuBar() {
    ui.pane = previousListPane;
    paintCursor(true);
  }
  function moveHorizontal(d) {
    if (ui.pane === "bar") {
      if (d < 0 && ui.bSel === 0) { returnFromMenuBar(); return; }
      ui.bSel = clamp(ui.bSel + d, 0, Math.max(0, barItems().length - 1));
    } else if (d > 0 && ui.pane === "channels") {
      focusMenuBar(); return;
    } else if (d < 0 && ui.pane === "channels") {
      ui.pane = "groups";
    } else if (d > 0 && ui.pane === "groups") {
      enterChannels(); return;
    } else if (d < 0 && ui.pane === "groups") {
      focusMenuBar(); return;
    }
    paintCursor(true);
  }
  function moveCursor(d) {
    if (ui.pane === "groups") {
      if (d < 0 && ui.gSel === 0) { focusMenuBar(); return; }
      const i = clamp(ui.gSel + d, 0, Math.max(0, state.groups.length - 1));
      if (i !== ui.gSel) selectGroup(i);
      
    } else if (ui.pane === "channels") {
      if (d < 0 && ui.cSel === 0) { focusMenuBar(); return; }
      ui.cSel = clamp(ui.cSel + d, 0, Math.max(0, state.view.length - 1));
    } else if (ui.pane === "bar" && d > 0) {
      ui.pane = previousListPane;
    }
    paintCursor(true);
  }

  /* =====================================================================
   * Overlay (groups + channels over the video)
   * ===================================================================== */
  const overlayOpen = () => !els.overlay.hidden;

  function armHide() {
    clearTimeout(ui.hideTimer);
    if (!overlayOpen() || !state.items.length || dialogOpen()) return;
    ui.hideTimer = setTimeout(() => {
      // Hidden by the timer, not by the user: ignore Up/Down for a moment so a key press that was meant for the
      // lists can't zap to another channel.
      ui.noZapUntil = Date.now() + 2500;
      closeOverlay();
    }, HIDE_AFTER_MS);
  }
  function openOverlay() {
    // Menu/OK on a TV remote is an explicit request to browse channels. If the
    // automatically selected first channel is still buffering, reveal the
    // already imported group/channel UI instead of leaving it behind the loader.
    if (startupLoading && (state.big || state.items.length)) {
      cancelStartupPlayTimer();
      finishStartupLoading();
      setBusy(false);
    }
    if (!state.big && !state.items.length) {
      syncWelcome();
      document.body.classList.add("channel-menu-open");
      els.overlay.hidden = false;
      els.zap.hidden = true;
      return;
    }
    document.body.classList.add("channel-menu-open");
    els.overlay.hidden = false;
    els.zap.hidden = true;
    // Every menu opening starts on the channel-name column. Group/category is
    // reached deliberately with Left; Right returns from groups to channels.
    ui.pane = "channels";
    previousListPane = "channels";
    const pos = state.view.indexOf(state.current);
    ui.cSel = pos < 0 ? 0 : pos;
    renderGroups();
    paintCursor(true);
    armHide();
  }
  function closeOverlay() {
    clearTimeout(ui.hideTimer);
    els.overlay.hidden = true;
    document.body.classList.remove("channel-menu-open");
    if (document.activeElement && document.activeElement.blur)
      document.activeElement.blur();
    paintCursor();
  }
  function toggleOverlay() {
    if (overlayOpen()) closeOverlay();
    else openOverlay();
  }

  function dialogOpen() {
    return els.dlg.open;
  }

  function openDialog() {
    if (startupLoading) return;
    els.dlg.hidden = false;
    clearTimeout(ui.hideTimer);
    setStatus(
      trialResult.verification_failed ? trialResult.message : "",
      !!trialResult.verification_failed,
    );
    if (!els.dlg.open) els.dlg.showModal();
    // Hide the starting-page logo/button while the translucent wizard is open.
    if (typeof document !== "undefined" && document.body) {
      document.body.classList.add("add-wizard-open");
    }
    setTimeout(()=>$("activationCode").focus(),0);
  }
  function closeDialog() {
    if (els.dlg.open) els.dlg.close();
    els.dlg.hidden = true;
    document.body.classList.remove("add-wizard-open");
    armHide();
  }

  // The existing menu icon now opens only the activation input.
  function openActivation() {openDialog();}

  /** The picture always fills the whole screen (stretch), so it fits every phone and TV. */
  function applyAspect() {
    try {
      const p = engine.setAspect("fill");
      if (p && p.catch) p.catch(() => {});
    } catch (e) {
      /* ignore */
    }
  }

  /* =====================================================================
   * Playback control
   * ===================================================================== */
  function setBusy(on) {
    els.spinner.hidden = !on;
  }
  function setMsg(text, isError, ms, closable) {
    if (isError) finishStartupLoading();
    // Playback events must not replace an explicitly opened Info panel.
    if (ui.infoVisible && !closable) return;
    clearTimeout(ui.msgTimer);
    if (text && ms) ui.msgTimer = setTimeout(() => setMsg(""), ms);
    els.msgText.textContent = text || "";
    els.msg.hidden = !text;
    els.msg.classList.toggle("error", !!isError);
    els.msg.classList.toggle("no-signal", text === "No signal!");
    els.msg.classList.toggle("closable", !!closable && !!text);
    els.msgClose.hidden = !(closable && text);
  }
  /** Movies and series episodes: Left = back 10 s, Right = forward 30 s (no on-screen controller). */
  function seekVod(seconds) {
    Promise.resolve(engine.seek(seconds))
      .then((r) => {
        clearTimeout(ui.zapTimer);
        els.zap.textContent =
          (seconds < 0 ? "◀ " : "▶ ") +
          Math.abs(seconds) +
          " s" +
          (r && r.position != null
            ? "   " +
              fmtTime(r.position) +
              (r.duration ? " / " + fmtTime(r.duration) : "")
            : "");
        els.zap.hidden = false;
        ui.zapTimer = setTimeout(() => {
          els.zap.hidden = true;
        }, 2000);
      })
      .catch(() => {
        /* ignore */
      });
  }
  function fmtTime(sec) {
    sec = Math.max(0, Math.floor(sec));
    const h = Math.floor(sec / 3600),
      m = Math.floor((sec % 3600) / 60),
      s2 = sec % 60;
    return (
      (h ? h + ":" + String(m).padStart(2, "0") : m) +
      ":" +
      String(s2).padStart(2, "0")
    );
  }
  function showZap(item, pos, total) {
    clearTimeout(ui.zapTimer);
    if (overlayOpen()) {
      els.zap.hidden = true;
      return;
    }
    els.zap.textContent = `${pos} / ${total}  ·  ${item.name}`;
    els.zap.hidden = false;
    ui.zapTimer = setTimeout(() => {
      els.zap.hidden = true;
    }, 3000);
  }

  /* ---------- audio language wizard (channels with several audio tracks) ---------- */
  const LANG_NAMES = {
    eng: "English",
    en: "English",
    ben: "Bengali",
    bn: "Bengali",
    hin: "Hindi",
    hi: "Hindi",
    tam: "Tamil",
    ta: "Tamil",
    tel: "Telugu",
    te: "Telugu",
    urd: "Urdu",
    ur: "Urdu",
    pan: "Punjabi",
    pa: "Punjabi",
    mal: "Malayalam",
    ml: "Malayalam",
    kan: "Kannada",
    kn: "Kannada",
    mar: "Marathi",
    mr: "Marathi",
    guj: "Gujarati",
    gu: "Gujarati",
    ori: "Odia",
    or: "Odia",
    asm: "Assamese",
    as: "Assamese",
    nep: "Nepali",
    ne: "Nepali",
    ara: "Arabic",
    ar: "Arabic",
    spa: "Spanish",
    es: "Spanish",
    fra: "French",
    fre: "French",
    fr: "French",
    deu: "German",
    ger: "German",
    de: "German",
    ita: "Italian",
    it: "Italian",
    por: "Portuguese",
    pt: "Portuguese",
    rus: "Russian",
    ru: "Russian",
    jpn: "Japanese",
    ja: "Japanese",
    kor: "Korean",
    ko: "Korean",
    chi: "Chinese",
    zho: "Chinese",
    zh: "Chinese",
    tur: "Turkish",
    tr: "Turkish",
    fas: "Persian",
    per: "Persian",
    fa: "Persian",
  };
  let awTracks = [],
    awSel = 0,
    awTimer = 0,
    awUrl = "",
    awDone = false,
    awCb = null;
  const audioWizOpen = () => !els.audioWiz.hidden;

  function audioName(t, i) {
    const lang = (t.lang || "").toLowerCase();
    const base =
      t.label ||
      LANG_NAMES[lang] ||
      (lang ? lang.toUpperCase() : "Track " + (i + 1));
    const ch =
      t.channels === 1
        ? "mono"
        : t.channels === 2
          ? "stereo"
          : t.channels > 2
            ? t.channels + " ch"
            : "";
    return base + (ch ? "  ·  " + ch : "");
  }
  function paintAudioWiz() {
    els.awList
      .querySelectorAll(".aw-row")
      .forEach((li, i) => li.classList.toggle("aw-cur", i === awSel));
  }
  function armAudioWizHide() {
    clearTimeout(awTimer);
    awTimer = setTimeout(hideAudioWiz, 15000);
  }
  function hideAudioWiz() {
    clearTimeout(awTimer);
    els.audioWiz.hidden = true;
  }
  /** Small choice panel at the bottom right (used for the audio language and for the Record choice). */
  function showWizard(title, labels, cursor, on, cb) {
    awCb = cb;
    awTracks = labels;
    awSel = Math.max(0, cursor | 0);
    els.awTitle.textContent = title;
    els.awList.textContent = "";
    labels.forEach((text, i) => {
      const li = document.createElement("li");
      li.className = "aw-row" + (i === on ? " on" : "");
      li.dataset.i = String(i);
      li.textContent = text;
      els.awList.appendChild(li);
    });
    els.audioWiz.hidden = false;
    paintAudioWiz();
    armAudioWizHide();
  }
  function showAudioWiz(tracks) {
    const cur = Math.max(
      0,
      tracks.findIndex((t) => t.selected),
    );
    showWizard("Audio language", tracks.map(audioName), cur, cur, (i) => {
      const t = tracks[i];
      if (!t) return;
      awDone = true;
      const p = engine.setAudioTrack(t.id);
      if (p && p.catch) p.catch(() => {});
      els.zap.textContent = "♪ " + audioName(t, i);
      els.zap.hidden = false;
      clearTimeout(ui.zapTimer);
      ui.zapTimer = setTimeout(() => {
        els.zap.hidden = true;
      }, 2500);
    });
  }
  function pickAudio(i) {
    const cb = awCb;
    hideAudioWiz();
    if (cb && awTracks[i] != null) cb(i);
  }
  els.awList.addEventListener("click", (e) => {
    const li = e.target.closest(".aw-row");
    if (li) pickAudio(Number(li.dataset.i));
  });

  /* ---------- recording: video as MP4, audio only; saved on the device by the native side ---------- */
  const rec = { on: false, t0: 0, timer: 0, url: "", mode: "" };
  const two = (n) => String(n).padStart(2, "0");
  function recClock() {
    const s = Math.floor((Date.now() - rec.t0) / 1000);
    return two(Math.floor(s / 60)) + ":" + two(s % 60);
  }
  function paintRec() {
    // Preserve the icon-only menu while recording; never replace its SVG with text.
    els.btnRecord.innerHTML = rec.on
      ? '<svg class="menu-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="1" fill="currentColor" stroke="none"/></svg>'
      : '<svg class="menu-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="3"/></svg>';
    els.btnRecord.setAttribute('aria-label', rec.on ? 'Stop recording' : 'Record');
    els.btnRecord.title = rec.on ? 'Stop recording' : 'Record';
    els.btnRecord.classList.toggle("recording", rec.on);
    els.recBadge.hidden = !rec.on;
    els.recBadge.textContent = "● REC " + recClock();
  }
  async function startRecording(mode) {
    if (rec.on || rec.starting || rec.saving) return;
    const item = state.items[state.current];
    if (!item) { toast("Play a channel first, then press Record."); return; }
    const request = playRequest;
    rec.starting = true;
    try {
      await engine.recordStart(mode, item.name);
      if (request !== playRequest || state.items[state.current]?.url !== item.url || !currentAccess) {
        await engine.recordStop();
        return;
      }
      rec.on = true;
      rec.t0 = Date.now();
      rec.url = item.url;
      clearInterval(rec.timer);
      rec.timer = setInterval(paintRec, 1000);
      paintRec();
    } catch (err) {
      if (request === playRequest) setMsg("Can't record: " + ((err && err.message) || err), true, 6000);
    } finally { rec.starting = false; }
  }
  async function stopRecording() {
    if (!rec.on || rec.saving) return;
    rec.on = false;
    rec.saving = true;
    clearInterval(rec.timer);
    paintRec();
    setMsg("Saving the recording…");
    try {
      const r = (await engine.recordStop()) || {};
      if (r.error) setMsg("Recording failed: " + r.error, true, 9000);
      else if (r.path) setMsg("Saved: " + r.path + (r.note ? "\n" + r.note : ""), false, 9000);
      else setMsg("");
    } catch (err) {
      setMsg("Recording failed: " + ((err && err.message) || err), true, 9000);
    } finally { rec.saving = false; }
  }
  els.btnRecord.addEventListener("click", () => {
    if (rec.on) {
      closeOverlay();
      stopRecording();
      return;
    }
    closeOverlay();
    startRecording("video");
  });

  engine.onAudioTracks((e) => {
    const list = (e && e.tracks) || [];
    if (list.length < 2) {
      if (!audioWizOpen()) awDone = false;
      hideAudioWiz();
      return;
    }
    // The picture or sound can report again after the user chose (the choice itself causes an update); keep the choice.
    if (awDone || audioWizOpen()) return;
    showAudioWiz(list);
  });

  engine.onState((e) => {
    if (!e) return;
    if (e.requestId != null && e.requestId !== playRequest) return;
    if (e.state === "fallback-queued" || e.state === "fallback-starting") {
      if (ui.playbackFailed) return;
      ui.playbackPending = true;
      ui.playbackEngine = "vlc";
      ui.fallbackRequested = true;
      cancelStartupPlayTimer();
      cancelPlaybackWait();
      armPlaybackWait(e.state === "fallback-queued" ? 90000 : 45000);
      setMsg("");
      setBusy(true);
    } else if (e.state === "buffering") {
      if (ui.playbackFailed) return;
      ui.playbackPending = true;
      armPlaybackWait();
      setBusy(true);
    }
    else if (e.state === "paused") {
      cancelPlaybackWait();
      ui.playbackPending = false;
      setBusy(false);
    }
    else if (e.state === "playing") {
      // Ignore a delayed player event after access has already been revoked.
      if (!currentAccess || accessClient.deadline <= performance.now()) return;
      cancelStartupPlayTimer();
      cancelPlaybackWait();
      ui.playbackFailed = false;
      ui.playbackPending = false;
      finishStartupLoading();
      setBusy(false);
      setMsg("");
      ui.vod = !!e.vod;
    } else if (e.state === "warning") {
      cancelStartupPlayTimer();
      finishStartupLoading();
      setBusy(false);
      setMsg(e.message || "Warning", true, 12000);
    } else if (e.state === "error") {
      const revealChannels = startupLoading;
      ui.playbackFailed = true;
      ui.playbackPending = false;
      cancelPlaybackWait();
      hideAudioWiz();
      cancelStartupPlayTimer();
      setBusy(false);
      setMsg("No signal!", true);
      if (revealChannels && (state.items.length || state.big)) openOverlay();
    } else if (e.state === "ended") {
      if (ui.playbackFailed) return;
      const item = state.items[state.current];
      if (!item) return;
      if (ui.vod) {
        // A movie outside the visible group must not jump into that group.
        if (state.view.indexOf(state.current) >= 0) step(1);
      } else {
        // Search can play an item outside state.view; it still needs live recovery.
        const now = Date.now();
        ui.reconnects = (ui.reconnects || []).filter((t) => now - t < 30000);
        if (ui.reconnects.length < 3) {
          ui.reconnects.push(now);
          play(state.current);
        } else {
          ui.playbackFailed = true;
          ui.playbackPending = false;
          cancelPlaybackWait();
          cancelStartupPlayTimer();
          hideAudioWiz();
          setBusy(false);
          setMsg("No signal!", true);
        }
      }
    }
  });

  let playRequest = 0;
  let startupPlayTimer = 0;
  let playbackWaitTimer = 0;
  function cancelPlaybackWait() {
    clearTimeout(playbackWaitTimer);
    playbackWaitTimer = 0;
  }
  function armPlaybackWait(timeout = ui.playbackEngine === "vlc" || !engine.recover ? 45000 : 7000) {
    if (playbackWaitTimer) return;
    const request = playRequest;
    playbackWaitTimer = setTimeout(async () => {
      playbackWaitTimer = 0;
      if (request !== playRequest || !ui.playbackPending) return;
      if (engine.recover && ui.playbackEngine !== "vlc" && !ui.fallbackRequested) {
        ui.fallbackRequested = true;
        try {
          const response = await engine.recover(request);
          if (request !== playRequest || !ui.playbackPending) return;
          if (response?.started) { ui.playbackEngine = "vlc"; armPlaybackWait(); return; }
        } catch (_) { if (request !== playRequest || !ui.playbackPending) return; }
      }
      ui.playbackFailed = true;
      ui.playbackPending = false;
      cancelStartupPlayTimer();
      hideAudioWiz();
      setBusy(false);
      setMsg("No signal!", true);
      try { const stopped = engine.stop(); if (stopped?.catch) stopped.catch(() => {}); } catch (_) {}
    }, timeout);
  }
  function cancelStartupPlayTimer() {
    clearTimeout(startupPlayTimer);
    startupPlayTimer = 0;
  }
  async function play(idx, promptAccess = true) {
    const request = ++playRequest;
    const selected = state.items[idx];
    if (!selected) return;
    if (!(await ensureAccess(promptAccess))) {
      if (!promptAccess)
        toast(trialResult.message || FREE_TRIAL_EXPIRED_MESSAGE, 8000);
      return;
    }
    if (request !== playRequest || state.items[idx] !== selected) return;
    cancelPlaybackWait();
    ui.playbackFailed = false;
    ui.playbackPending = true;
    ui.playbackEngine = "exo";
    ui.fallbackRequested = false;
    armPlaybackWait();
    ui.vod = false;
    const item = state.items[idx];
    if (!item) return;
    if (ui.reconnectUrl !== item.url) { ui.reconnectUrl = item.url; ui.reconnects = []; }
    if (item.url !== awUrl) {
      awUrl = item.url;
      awDone = false;
    }
    hideAudioWiz();
    if (rec.on && item.url !== rec.url) stopRecording();
    state.current = idx;
    // Do not persist the playing item; next app start begins at playlist item one.
    store.del(KEY.last);
    store.del(KEY.lastItem);
    for (const row of els.list.querySelectorAll(".row.active"))
      row.classList.remove("active");
    const row = els.list.querySelector(`.row[data-i="${idx}"]`);
    if (row) row.classList.add("active");
    const pos = state.view.indexOf(idx);
    showZap(
      item,
      (pos < 0 ? idx : pos) + 1,
      pos < 0 ? state.items.length : state.view.length,
    );

    if (UNSUPPORTED_RE.test(item.url)) {
      cancelPlaybackWait();
      ui.playbackPending = false;
      ui.playbackFailed = true;
      const revealChannels = startupLoading;
      cancelStartupPlayTimer();
      setBusy(false);
      setMsg(
        "This channel uses " +
          item.url.split(":")[0] +
          ":// which this player can't open.",
        true,
      );
      try {
        const p = engine.stop();
        if (p && p.catch) p.catch(() => {});
      } catch (e) {
        /* ignore */
      }
      if (revealChannels && (state.items.length || state.big)) openOverlay();
      return;
    }
    setMsg("");
    cancelStartupPlayTimer();
    if (startupLoading) {
      startupProgress("Starting playback…");
      startupPlayTimer = setTimeout(() => {
        if (request !== playRequest || !startupLoading) return;
        startupPlayTimer = 0;
        finishStartupLoading();
        setMsg("");
        if (state.items.length || state.big) openOverlay();
        setBusy(true);
      }, STARTUP_PLAY_TIMEOUT_MS);
    }
    setBusy(true);
    try {
      const p = engine.play(item, request);
      if (p && p.catch)
        p.catch((err) => {
          if (request !== playRequest) return;
          cancelPlaybackWait();
          ui.playbackPending = false;
          ui.playbackFailed = true;
          const revealChannels = startupLoading;
          cancelStartupPlayTimer();
          setBusy(false);
          setMsg("No signal!", true);
          if (revealChannels && (state.items.length || state.big)) openOverlay();
        });
    } catch (err) {
      cancelPlaybackWait();
      ui.playbackPending = false;
      ui.playbackFailed = true;
      const revealChannels = startupLoading;
      cancelStartupPlayTimer();
      setBusy(false);
      setMsg("No signal!", true);
      if (revealChannels && (state.items.length || state.big)) openOverlay();
    }
  }

  function step(dir) {
    if (!state.view.length) return;
    const pos = state.view.indexOf(state.current);
    let next = pos < 0 ? (dir > 0 ? 0 : state.view.length - 1) : pos + dir;
    if (next < 0) next = state.view.length - 1;
    if (next >= state.view.length) next = 0;
    ensureRendered(next);
    ui.cSel = next;
    play(state.view[next]);
    if (overlayOpen()) paintCursor(true);
  }

  /* =====================================================================
   * Input: touch, keyboard, TV remote, Android back button
   * ===================================================================== */
  els.tapzone.addEventListener("click", toggleOverlay);
  els.overlay.addEventListener("click", (e) => {
    if (e.target === els.overlay || e.target.id === "panes") closeOverlay();
  });
  ["pointerdown", "keydown", "wheel", "touchmove"].forEach((evt) =>
    els.overlay.addEventListener(evt, armHide, { passive: true }),
  );

  els.list.addEventListener("click", (e) => {
    const row = e.target.closest(".row");
    if (!row) return;
    ui.cSel = Number(row.dataset.v);
    closeOverlay();
    play(Number(row.dataset.i));
  });
  els.groupList.addEventListener("click", (e) => {
    const row = e.target.closest(".row");
    if (!row) return;
    ui.pane = "groups";
    selectGroup(Number(row.dataset.g));
    paintCursor();
  });
  els.listWrap.addEventListener(
    "scroll",
    () => {
      const w = els.listWrap;
      if (w.scrollTop + w.clientHeight > w.scrollHeight - 700) renderMore();
      updateColumnProgress(true);
    },
    { passive: true },
  );
  els.groupList.parentElement.addEventListener(
    "scroll",
    () => updateColumnProgress(true),
    { passive: true },
  );

  /* Full-playlist search. Native storage searches all entries, not just loaded pages. */
  const searchDlg = $("searchDlg"), searchInput = $("searchInput"),
    searchResults = $("searchResults"), searchStatus = $("searchStatus"),
    searchMore = $("searchMore");
  let searchSeq = 0, searchOffset = 0, searchQuery = "";
  function searchFocusResult(index) {
    const rows = [...searchResults.querySelectorAll('li[tabindex]')];
    if (!rows.length) return false;
    const row = rows[Math.max(0, Math.min(rows.length - 1, index))];
    row.focus({preventScroll:true}); row.scrollIntoView({block:'nearest'});
    return true;
  }
  searchDlg.addEventListener('keydown', e => {
    const rows = [...searchResults.querySelectorAll('li[tabindex]')];
    const index = rows.indexOf(document.activeElement);
    if (e.key === 'ArrowDown' || e.keyCode === 20) {
      if (index >= 0) {e.preventDefault(); if (index === rows.length-1 && !searchMore.hidden) {searchMore.focus();} else searchFocusResult(index+1);}
      else if (document.activeElement === searchInput || document.activeElement === $('searchVoice') || document.activeElement === $('searchClose')) {if(rows.length){e.preventDefault();searchFocusResult(0);}}
    } else if (e.key === 'ArrowUp' || e.keyCode === 19) {
      if (index >= 0) {e.preventDefault();if(index === 0) searchInput.focus();else searchFocusResult(index-1);}
      else if(document.activeElement === searchMore && rows.length){e.preventDefault();searchFocusResult(rows.length-1);}
    } else if ((e.key === 'Enter' || e.keyCode === 23 || e.keyCode === 66) && index >= 0) {e.preventDefault(); rows[index].click();}
  });
  async function searchRun(append = false) {
    const q = searchInput.value.trim();
    const seq = ++searchSeq;
    if (!append) { searchOffset = 0; searchResults.textContent = ""; }
    searchQuery = q;
    searchMore.hidden = true;
    searchMore.disabled = true;
    if (!q) { searchStatus.textContent = "Enter a name or category to search all entries."; return; }
    searchStatus.textContent = "Searching entire playlist…";
    try {
      let matches, total;
      if (state.big) {
        const result = await bigPlugin().bigSearchPage({query:q, offset:searchOffset});
        matches = result.items || []; total = result.total || 0;
      } else {
        const term = q.toLocaleLowerCase();
        const all = state.items.filter(it => [it.name, it.group, it.url].some(v => String(v || "").toLocaleLowerCase().includes(term)));
        total = all.length; matches = all.slice(searchOffset, searchOffset + 100);
      }
      if (seq !== searchSeq || searchQuery !== q) return;
      const frag = document.createDocumentFragment();
      for (const it of matches) {
        const li = document.createElement("li"); li.tabIndex = 0;
        const label = document.createElement("span"); label.textContent = it.name || "Unnamed";
        const group = document.createElement("small"); group.textContent = it.group || "Ungrouped";
        li.append(label, group);
        li.addEventListener("click", () => {
          searchDlg.close();
          // Play the actual search result, regardless of the currently selected group.
          const index = state.items.findIndex(x => x.url === it.url);
          let target = index;
          if (target < 0) { target = state.items.length; state.items.push(it); }
          play(target);
        });
        li.addEventListener("keydown", e => { if (e.key === "Enter") li.click(); });
        frag.append(li);
      }
      searchResults.append(frag);
      searchOffset += matches.length;
      searchStatus.textContent = `${total} matching entries (showing ${searchOffset}).`;
      searchMore.hidden = searchOffset >= total;
    } catch (e) { if (seq === searchSeq) searchStatus.textContent = "Search failed: " + (e.message || e); }
    finally { if (seq === searchSeq) searchMore.disabled = false; }
  }
  let searchDebounce;
  els.btnSearch.addEventListener("click", () => {
    closeOverlay();
    // Search is a player action, never part of first-run Add playlist.
    if (!state.big && !state.items.length) { openDialog(); return; }
    if (!searchDlg.open) searchDlg.showModal();
    searchInput.focus(); searchRun();
  });
  $("searchClose").addEventListener("click", () => searchDlg.close());
  searchInput.addEventListener("input", () => {
    ++searchSeq; // Discard in-flight old results as soon as the text changes.
    searchMore.hidden = true;
    clearTimeout(searchDebounce);
    searchDebounce = setTimeout(() => searchRun(), 250);
  });
  searchDlg.addEventListener("close", () => { ++searchSeq; clearTimeout(searchDebounce); });
  searchMore.addEventListener("click", () => searchRun(true));
  $("searchVoice").addEventListener("click", async () => {
    const voiceButton = $("searchVoice");
    const seq = ++searchSeq;
    clearTimeout(searchDebounce);
    searchMore.hidden = true;
    const current = () => seq === searchSeq;
    voiceButton.disabled = true;
    searchStatus.textContent = "Listening…";
    try {
      let alternatives = [];
      const native = window.Capacitor?.isNativePlatform?.() && bigPlugin();
      if (native?.voiceSearch) {
        const response = await native.voiceSearch();
        alternatives = response.alternatives || [response.text || ""];
      } else {
        const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!Speech) throw new Error("Voice recognition is unavailable. Use the keyboard.");
        alternatives = await new Promise((resolve, reject) => {
          const recognition = new Speech();
          recognition.lang = navigator.language || "en-US";
          recognition.maxAlternatives = 5;
          recognition.interimResults = false;
          let settled = false;
          recognition.onresult = e => {
            settled = true;
            resolve(Array.from(e.results[0], result => result.transcript));
          };
          recognition.onerror = e => reject(new Error(e.error || "Voice recognition failed"));
          recognition.onend = () => { if (!settled) reject(new Error("No speech was recognized. Please try again.")); };
          recognition.start();
        });
      }
      if (!current()) return;
      searchStatus.textContent = "Matching channel names…";
      const resolved = await window.ChannelVoiceSearch.resolve(alternatives, async query => {
        if (state.big) return (await bigPlugin().bigSearchPage({query, offset:0})).items || [];
        const term = query.toLocaleLowerCase();
        return state.items.filter(it => String(it.name || "").toLocaleLowerCase().includes(term));
      }, current);
      if (!current() || !resolved) return;
      if (!resolved.query) throw new Error("No speech was recognized. Please try again.");
      searchInput.value = resolved.query;
      const render = searchRun();
      const renderSeq = searchSeq;
      await render;
      if (renderSeq === searchSeq && resolved.corrected)
        searchStatus.textContent += ` Heard “${resolved.heard}”; matched “${resolved.query}”.`;
    } catch (e) {
      if (current()) searchStatus.textContent = "Voice search: " + (e.message || e);
    } finally { voiceButton.disabled = false; }
  });

  els.btnOpen.addEventListener("click", () => {
    if (state.items.length || state.big) closeOverlay();
    openActivation(true);
  });
  els.btnWelcomeAdd.addEventListener("click", (event) => {
    event.preventDefault(); event.stopPropagation();
    // Open the activation input directly.
    openDialog();
  });
  function syncWelcome() {
    const empty = !state.items.length && !state.big;
    document.body.classList.toggle("empty", empty);
    // A remembered activation awaiting its server check is not a first installation.
    document.body.classList.toggle("restoring-subscription", empty && !!accessClient.token && !accessClient.activationRequired);
  }
  els.btnInfo.addEventListener("click", () => {
    closeOverlay();
    showInfo();
  });
  els.btnRefresh.addEventListener("click", async () => {
    closeOverlay();
    if(accessLoading || activationBusy)return;
    els.btnRefresh.disabled=true;
    try {
      if(!(await ensureAccess())){openDialog();return;}
      resetPlaylistRecovery(currentAccess);
      await loadAuthorized(currentAccess);
      setMsg("Playlist reloaded.",false,3500);
    } catch(err){setMsg("Reload failed: "+(err.message||err),true,6000);}
    finally{els.btnRefresh.disabled=false;}
  });

  function beginPlaylistSwitch() {
    ++playlistEpoch;
    ++bigSeq;
    clearTimeout(bigTimer);
    bigLoading=false;
    ++searchSeq;
    clearTimeout(searchDebounce);
    ++playRequest;
    cancelStartupPlayTimer();
    cancelPlaybackWait();
    ui.playbackPending=false;
    ui.playbackFailed=false;
    return playlistEpoch;
  }
  function clearActivatedPlaylist() {
    for (const key of [KEY.cache,KEY.big,KEY.history,KEY.last,KEY.lastItem]) store.del(key);
    state.source=""; state.label=""; state.items=[]; state.view=[]; state.groups=[];
    state.big=null; state.current=-1; state.rendered=0; state.group="all";
    state.bigLoadedCount=0; state.winTotal=0;
    loadedVersion=null; loadedSubscription=null;
    els.list.textContent=""; els.groupList.textContent="";
    searchResults.textContent=""; searchInput.value="";
    ui.cSel=0; ui.gSel=0; ui.pane="channels";
  }

  const activationForm = $("activationForm");
  const activationCode = $("activationCode");
  let autoActivationTimer = null;
  activationCode.addEventListener("input", () => {
    clearTimeout(autoActivationTimer);
    if (activationBusy || accessLoading) return;
    const code = activationCode.value.trim();
    if (!/^[0-9]{10}$/.test(code)) return;
    autoActivationTimer = setTimeout(() => {
      if (els.dlg.open && !activationBusy && !accessLoading)
        if (typeof activationForm.requestSubmit === "function") activationForm.requestSubmit();
        else activationForm.dispatchEvent(new Event("submit", {bubbles:true,cancelable:true}));
    }, 300);
  });
  activationForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearTimeout(autoActivationTimer);
    if (activationBusy || accessLoading) return;
    const code = activationCode.value.trim();
    if (!/^[0-9]{10}$/.test(code)) return;
    activationBusy=true;
    const activationEpoch=beginPlaylistSwitch();
    activationCode.readOnly=true;
    let acceptedAndLoading=false;
    let retryDelay=30000;
    try {
      const j=await accessClient.activate(code);
      resetPlaylistRecovery(j);
      acceptedAndLoading=true;
      activationCode.value="";
      startupProgress("Downloading playlist…");
      if (!(await acceptAccess(j, activationEpoch))) return;
      // The code has already been accepted. Remove the input wizard before any
      // provider download/import begins and give that whole operation one clear,
      // full-screen progress view. This also prevents dialog status, the global
      // spinner and the activation digits from being drawn on top of each other.
      acceptedAndLoading=true;
      startupProgress("Downloading playlist…");
      closeDialog();
      closeOverlay();
      // Let any old native disk-open finish before a new import can replace its files.
      await Promise.all([...savedOpenRequests]);
      if (!isCurrentPlaylistGrant(j, activationEpoch)) return;
      const savedRestore = prepareSavedRestore(j);
      // A regenerated code for the same authorized revision reuses its local
      // index. A different subscription/revision gets a clean network import.
      if (!(await restoreAuthorized(j, savedRestore))) {
        clearActivatedPlaylist();
        await loadAuthorized(j);
      }
      activationCode.value="";
    } catch(err) {
      const message=err.message||String(err);
      if (acceptedAndLoading) {
        // The download failure UI already preserves the accepted activation.
        if (!playlistRecovery.error) showPlaylistFailure(err, currentAccess);
        retryDelay = playlistRecovery.paused ? 30000 : 5000;
      } else {
        setStatus(message,true);
      }
    }
    finally {activationBusy=false;activationCode.readOnly=false;scheduleSubscriptionSync(retryDelay);}
  });
  els.dlg.addEventListener("close", () => {
    clearTimeout(autoActivationTimer);
    document.body.classList.remove("add-wizard-open");
    armHide();
  });

  /** From the group column into the channel list; picks the highlighted group if it is not the active one. */
  function enterChannels() {
    const g = state.groups[ui.gSel];
    if (g && g.key !== state.group) selectGroup(ui.gSel);
    ui.pane = "channels";
    paintCursor(true);
  }

  function activateCursor() {
    if (ui.pane === "bar") {
      const el = barItems()[ui.bSel];
      if (!el) return;
      el.click();
    } else if (ui.pane === "groups") {
      enterChannels();
    } else {
      const idx = state.view[ui.cSel];
      if (idx != null) {
        closeOverlay();
        play(idx);
      }
    }
  }

  const infoOpen = () => !!ui.infoVisible;
  async function showInfo() {
    const generation = (ui.infoGeneration || 0) + 1;
    ui.infoGeneration = generation;
    ui.infoVisible = true;
    clearTimeout(ui.infoTimer);
    setMsg("Loading information…", false, 0, true);
    async function refresh() {
      try {
        const text = await engine.info();
        if (!ui.infoVisible || generation !== ui.infoGeneration) return;
        setMsg(text, false, 0, true);
      } catch (err) {
        if (!ui.infoVisible || generation !== ui.infoGeneration) return;
        setMsg("Info unavailable: " + (err.message || err), true, 0, true);
      }
      ui.infoTimer = setTimeout(refresh, 1000);
    }
    await refresh();
  }
  function closeInfo() {
    ui.infoVisible = false;
    ui.infoGeneration = (ui.infoGeneration || 0) + 1;
    clearTimeout(ui.infoTimer);
    setMsg(ui.playbackFailed ? "No signal!" : "", !!ui.playbackFailed);
  }
  els.msgClose.addEventListener("click", (e) => {
    e.stopPropagation();
    closeInfo();
  });

  function handleBack() {
    if (searchDlg.open) { searchDlg.close(); return; }
    if (infoOpen()) {
      closeInfo();
      return;
    }
    if (dialogOpen()) {
      closeDialog();
      return;
    }
    // During automatic first-channel startup, Back means "show my channel
    // list". Do not exit the app while a valid imported playlist is available.
    if (startupLoading && (state.items.length || state.big)) {
      openOverlay();
      return;
    }
    if (overlayOpen() && (state.items.length || state.big)) {
      closeOverlay();
      return;
    }
    // Back on a failed/stalled channel opens its channel list; it must never
    // fall through to exitApp simply because the video did not start.
    if ((ui.playbackFailed || ui.playbackPending) && (state.items.length || state.big)) {
      openOverlay();
      return;
    }
    const App =
      root.Capacitor && root.Capacitor.Plugins && root.Capacitor.Plugins.App;
    if (App && App.exitApp) App.exitApp();
  }

  document.addEventListener(
    "keydown",
    (e) => {
      if (searchDlg.open) {
        if (["Escape", "GoBack"].includes(e.key) || (e.key === "Backspace" && document.activeElement !== searchInput) || e.keyCode === 4 || e.keyCode === 111) {
          e.preventDefault(); searchDlg.close();
        }
        return;
      }
      if (dialogOpen()) return;
      if (handleStartupRecoveryKey(e)) return;
      // On first launch the remote OK key belongs to Add playlist, not the hidden menu.
      if (!state.big && !state.items.length && (e.key === "Enter" || e.key === " " || e.keyCode === 23 || e.keyCode === 66)) {
        e.preventDefault(); openActivation(); return;
      }
      if (overlayOpen()) armHide(); // every remote key counts as activity: keep the lists open while browsing
      if (
        infoOpen() &&
        (e.key === "Escape" ||
          e.key === "Backspace" ||
          e.key === "GoBack" ||
          e.keyCode === 4 ||
          e.key === "ArrowLeft" ||
          e.key === "Enter" ||
          e.key === " " ||
          e.keyCode === 23)
      ) {
        e.preventDefault();
        closeInfo();
        return;
      }
      const k = e.key;
      const kc = e.keyCode;
      if (overlayOpen() && e.target && e.target.closest && e.target.closest("#barItems") && !["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.key) && ![19,20,21,22].includes(e.keyCode)) {
        ui.pane = "bar";
        const at = barItems().indexOf(e.target.closest("button"));
        if (at >= 0) ui.bSel = at;
      }
      const typing =
        e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName);
      if (typing) {
        if (k === "Escape" || k === "ArrowDown" || k === "ArrowUp") {
          e.preventDefault();
          e.target.blur();
          ui.pane = k === "ArrowUp" ? "bar" : "channels";
          paintCursor(true);
        } else if (k === "Enter") {
          e.preventDefault();
          e.target.blur();
          ui.pane = "channels";
          paintCursor(true);
        }
        return;
      }
      // Android TV remotes do not all expose the same DOM `key` string. Some WebViews
      // report only Android keyCode values, so accept both forms for D-pad and OK.
      const up = k === "ArrowUp" || kc === 19;
      const down = k === "ArrowDown" || kc === 20;
      const left = k === "ArrowLeft" || kc === 21;
      const right = k === "ArrowRight" || kc === 22;
      const ok = k === "Enter" || k === " " || kc === 23 || kc === 66;
      const chUp =
        k === "ChannelUp" || k === "PageUp" || kc === 166 || kc === 92;
      const chDown =
        k === "ChannelDown" || k === "PageDown" || kc === 167 || kc === 93;
      const back =
        k === "Escape" ||
        k === "Backspace" ||
        k === "GoBack" ||
        kc === 4 ||
        kc === 111;

      // Audio wizard open: Up/Down choose, OK selects, Back closes. Channel keys still work.
      if (audioWizOpen()) {
        if (up || down) {
          e.preventDefault();
          awSel = clamp(awSel + (up ? -1 : 1), 0, awTracks.length - 1);
          paintAudioWiz();
          armAudioWizHide();
          return;
        }
        if (ok) {
          e.preventDefault();
          pickAudio(awSel);
          return;
        }
        if (back) {
          e.preventDefault();
          hideAudioWiz();
          return;
        }
      }

      if (!overlayOpen()) {
        if ((up || down) && Date.now() < (ui.noZapUntil || 0)) {
          e.preventDefault();
        } else if (up || chUp) {
          e.preventDefault();
          step(-1);
        } else if (down || chDown) {
          e.preventDefault();
          step(1);
        } else if (ui.vod && (left || right)) {
          e.preventDefault();
          seekVod(left ? -10 : 30);
        } else if (
          ok ||
          left ||
          right ||
          k === "ContextMenu" ||
          k === "m" ||
          k === "Menu" ||
          kc === 82
        ) {
          e.preventDefault();
          openOverlay();
        } else if (back) {
          e.preventDefault();
          handleBack();
        }
        return;
      }

      if (document.body.classList.contains("empty") && !overlayOpen()) {
        e.preventDefault();
        if (back) handleBack();
        else if (ok) openDialog();
        return;
      }
      if (back) {
        e.preventDefault();
        handleBack();
        return;
      }
      if (chUp) {
        e.preventDefault();
        step(-1);
        return;
      }
      if (chDown) {
        e.preventDefault();
        step(1);
        return;
      }
      if (k === "ContextMenu" || k === "m" || k === "Menu" || kc === 82) {
        e.preventDefault();
        if (ui.pane === "bar") returnFromMenuBar();
        else focusMenuBar();
        return;
      }
      if (up) {
        e.preventDefault();
        moveCursor(-1);
        return;
      }
      if (down) {
        e.preventDefault();
        moveCursor(1);
        return;
      }
      if (left || right) {
        e.preventDefault();
        moveHorizontal(left ? -1 : 1);
        return;
      }
      if (ok) {
        e.preventDefault();
        activateCursor();
      }
    },
    true,
  );

  // Android hardware / remote Back button (Capacitor App plugin)
  (function bindBack() {
    const App =
      root.Capacitor && root.Capacitor.Plugins && root.Capacitor.Plugins.App;
    if (App && App.addListener) App.addListener("backButton", handleBack);
  })();

  /* =====================================================================
   * Start-up: restore the last playlist and play its first item
   * ===================================================================== */
  applyAspect();

  // Show unexpected script errors instead of failing silently.
  function reportProblem(text) {
    if (dialogOpen()) setStatus(text, true);
    else toast(text, 8000);
  }
  window.addEventListener("error", (e) =>
    reportProblem("Problem: " + (e.message || "unknown error")),
  );
  window.addEventListener("unhandledrejection", (e) =>
    reportProblem(
      "Problem: " +
        ((e.reason && e.reason.message) || e.reason || "unknown error"),
    ),
  );

  // If the app stopped in the middle of loading last time, say where.
  (async function reportLastStop() {
    const p = nativePlugin();
    if (!p || !p.lastCrumb) return;
    try {
      const r = await p.lastCrumb();
      const t = r && r.text;
      if (t && !/^ok/.test(t)) {
        p.crumb({ text: "ok (reported)" });
        setStatus(
          "The app stopped unexpectedly last time. Last step: " +
            t +
            ". Please send this text to the developer.",
          true,
        );
      }
    } catch (e) {
      /* ignore */
    }
  })();

  const MAX_PLAYLIST_ATTEMPTS = 2;
  let playlistRecovery = {key:"", attempts:0, paused:false, error:""};
  function playlistRevisionKey(j) {
    return j ? [j.subscription_id,j.playlist_version,normalizeUrl(j.playlist_url)].join("|") : "";
  }
  function resetPlaylistRecovery(j) {
    playlistRecovery = {key:playlistRevisionKey(j), attempts:0, paused:false, error:""};
  }
  function showPlaylistFailure(error, j) {
    const key = playlistRevisionKey(j);
    if (playlistRecovery.key !== key) resetPlaylistRecovery(j);
    playlistRecovery.attempts++;
    playlistRecovery.error = String(error?.message || error || "Playlist server did not answer.");
    playlistRecovery.paused = playlistRecovery.attempts >= MAX_PLAYLIST_ATTEMPTS;
    startupProgress(playlistRecovery.error + (playlistRecovery.paused ? "" : " — Retrying once…"));
    setBusy(false);
    setMsg("");
    closeOverlay();
    if (playlistRecovery.paused) {
      $("startupTitle").textContent = "Could not load playlist";
      $("startupLoader").classList.add("playlist-load-failed");
      $("startupRecovery").hidden = false;
      $("startupRetry").focus({preventScroll:true});
    }
  }
  function handleStartupRecoveryKey(e) {
    if (!playlistRecovery.paused || !startupLoading) return false;
    const k=e.key, c=e.keyCode;
    const buttons=[$("startupRetry"),$("startupActivate")];
    if (["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(k) || [19,20,21,22].includes(c)) {
      e.preventDefault();
      buttons[document.activeElement === buttons[0] ? 1 : 0].focus();
      return true;
    }
    if (k === "Enter" || k === " " || c === 23 || c === 66) {
      e.preventDefault();
      (buttons.includes(document.activeElement) ? document.activeElement : buttons[0]).click();
      return true;
    }
    return false;
  }
  $("startupRetry").addEventListener("click", () => {
    resetPlaylistRecovery(currentAccess || accessClient.value);
    startupProgress("Retrying playlist…");
    setBusy(true);
    if (subscriptionSyncPending) subscriptionSyncPending.finally(syncSubscription);
    else syncSubscription();
  });
  $("startupActivate").addEventListener("click", () => {
    finishStartupLoading();
    openActivation();
  });
  async function loadAuthorized(j) {
    if (accessLoading) return;
    if (playlistRecovery.key !== playlistRevisionKey(j)) resetPlaylistRecovery(j);
    if (playlistRecovery.paused) return;
    accessLoading=true;
    playlistRecovery.error="";
    if (startupLoading || (!state.items.length && !state.big)) startupProgress("Downloading playlist…");
    try {
      setMsg("Downloading playlist…");
      await loadFromUrl(j.playlist_url,false,true);
      resetPlaylistRecovery(j);
      loadedVersion=Number(j.playlist_version);
      loadedSubscription=Number(j.subscription_id);
      rememberAuthorizedCache(j);
      setMsg("");
    } catch (error) {
      showPlaylistFailure(error,j);
      throw error;
    } finally {accessLoading=false;}
  }
  let loadedVersion=null, loadedSubscription=null;
  let subscriptionSyncTimer = null, subscriptionSyncPending = null;
  function scheduleSubscriptionSync(delay) {
    clearTimeout(subscriptionSyncTimer);
    if (accessClient.token) subscriptionSyncTimer = setTimeout(syncSubscription, delay);
  }
  function syncSubscription() {
    clearTimeout(subscriptionSyncTimer);
    // Resume, online and timer events share one verification/download operation.
    if (subscriptionSyncPending) return subscriptionSyncPending;
    if (activationBusy || accessLoading) {scheduleSubscriptionSync(1000); return Promise.resolve();}
    if (!accessClient.token) {openOverlay(); return Promise.resolve();}
    if (document.hidden) return Promise.resolve();
    let nextCheck = 5000;
    const epoch=playlistEpoch;
    subscriptionSyncPending = (async () => {
      try {
        const wasBlocked = !currentAccess;
        const shouldResumePlayback = playbackLeaseDue;
        // Disk index opening and server verification happen in parallel.
        const savedRestore = (!state.items.length && !state.big) ? prepareSavedRestore() : null;
        if (!state.items.length && !state.big && !playlistRecovery.paused) {
          syncWelcome();
          startupProgress("Checking subscription…");
          setBusy(true);
          setMsg("Checking subscription…");
        }
        const j = await accessClient.verify(true);
        if (epoch !== playlistEpoch) return;
        if (!j) {openOverlay(); return;}
        if (!(await acceptAccess(j, epoch))) return;
        playbackLeaseDue = false;
        if (playlistRecovery.key !== playlistRevisionKey(j)) resetPlaylistRecovery(j);
        if (playlistRecovery.paused) { nextCheck=30000; return; }
        if (state.source !== normalizeUrl(j.playlist_url) || loadedVersion !== Number(j.playlist_version) || loadedSubscription !== Number(j.subscription_id)) {
          const restored=await restoreAuthorized(j, savedRestore);
          if (!isCurrentPlaylistGrant(j, epoch)) return;
          if (!restored) await loadAuthorized(j);
        } else if ((wasBlocked || shouldResumePlayback) && state.current >= 0 && state.items[state.current]) {
          closeDialog();
          closeOverlay();
          await play(state.current, false);
        }
        nextCheck = 30000;
      } catch (err) {
        if (epoch !== playlistEpoch) return;
        const message = err.message || String(err);
        if (playlistRecovery.error) { nextCheck=playlistRecovery.paused ? 30000 : 5000; return; }
        if (currentAccess && startupLoading) {
          startupProgress(message + " — Retrying playlist…");
        } else if (els.dlg.open) setStatus(message, true);
        else setMsg(message, true);
        openOverlay();
      } finally {
        if (epoch === playlistEpoch) { setBusy(false); syncWelcome(); }
      }
    })().finally(() => {
      subscriptionSyncPending = null;
      if (epoch === playlistEpoch) scheduleSubscriptionSync(nextCheck);
    });
    return subscriptionSyncPending;
  }
  function resumeSubscription() {
    if (document.hidden || !accessClient.token) return;
    // Native playback may have paused or its short lease may have elapsed while
    // Android suspended the WebView. Keep the token and show progress until the
    // fresh server result arrives.
    if (accessClient.deadline <= performance.now()) playbackLeaseDue = true;
    if ((!currentAccess || playbackLeaseDue) && !playlistRecovery.paused) {
      startupProgress("Checking subscription…");
      setBusy(true);
      setMsg("Checking subscription…");
    }
    syncSubscription();
  }
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) resumeSubscription();
  });
  window.addEventListener("online", resumeSubscription);
  const lifecycleApp = root.Capacitor?.Plugins?.App;
  if (lifecycleApp?.addListener) {
    try {
      const listener = lifecycleApp.addListener("appStateChange", ({isActive}) => {
        if (isActive) resumeSubscription();
      });
      listener?.catch?.(() => {});
    } catch (_) { /* DOM visibility/online handlers remain available. */ }
  }
  openOverlay();
  syncSubscription();
})(typeof window !== "undefined" ? window : globalThis);
