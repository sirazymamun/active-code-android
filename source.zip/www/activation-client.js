/* Device access lease: no offline grant, no client-clock based subscription expiry. */
(function(root){
'use strict';
class ActivationClient {
 constructor({request,identity,storage,now=()=>performance.now(),onBlock=()=>{},onLeaseDue=null}){this.request=request;this.identity=identity;this.storage=storage;this.now=now;this.onBlock=onBlock;this.onLeaseDue=typeof onLeaseDue==='function'?onLeaseDue:()=>this.block('Access verification expired. Connect to the internet and try again.');this.token='';this.storageError=false;try{this.token=storage.getItem('active-code.device-token')||'';}catch(_){this.storageError=true;}this.value=null;this.deadline=0;this.timer=null;this.epoch=0;this.pending=null;this.activationRequired=false;}
 block(message){clearTimeout(this.timer);this.deadline=0;this.value=null;this.onBlock(message);}
 accept(j){if(j.ok!==true||j.allowed!==true||!/^https?:\/\//i.test(j.playlist_url||'')||!Number.isFinite(j.remaining_seconds)||j.remaining_seconds<=0)throw Error('Subscription inactive or invalid server response.');this.activationRequired=false;this.value=j;this.deadline=this.now()+Math.min(j.remaining_seconds,65)*1000;clearTimeout(this.timer);this.timer=setTimeout(()=>{this.onLeaseDue();},Math.min(j.remaining_seconds,65)*1000);return j;}
 async activate(code){if(!/^[0-9]{10}$/.test(code))throw Error('Enter exactly 10 digits.');const epoch=++this.epoch;this.block('Checking activation code…');const device_id=await this.identity();if(epoch!==this.epoch)throw Error('Activation replaced by a newer request.');const j=await this.request('activate',{code,device_id});if(epoch!==this.epoch)throw Error('Activation replaced by a newer request.');if(!/^[a-f0-9]{64}$/.test(j.device_token||''))throw Error('Invalid activation response.');this.accept(j);this.token=j.device_token;try{this.storage.setItem('active-code.device-token',this.token);this.storageError=false;}catch(_){this.storageError=true;}return j;}
 async verify(force=false){
  if(!this.token){this.block('Enter the 10-digit code supplied by your vendor.');return null;}
  if(!force&&this.value&&this.deadline-this.now()>55000)return this.value;
  const epoch=this.epoch,token=this.token;
  if(this.pending&&this.pending.epoch===epoch)return this.pending.promise;
  const pending={epoch,promise:null};this.pending=pending;
  pending.promise=(async()=>{
   try{const device_id=await this.identity();if(epoch!==this.epoch)return this.value;const j=await this.request('device-check',{device_id,device_token:token});if(epoch!==this.epoch)return this.value;return this.accept(j);}
   catch(e){if(epoch!==this.epoch)return this.value;this.activationRequired=e.activationRequired===true;this.block(e.message||'Cannot verify subscription.');return null;}
   finally{if(this.pending===pending)this.pending=null;}
  })();
  return pending.promise;
 }

}
if(typeof module!=='undefined'&&module.exports)module.exports={ActivationClient};else root.ActivationClient=ActivationClient;
})(typeof window!=='undefined'?window:globalThis);
