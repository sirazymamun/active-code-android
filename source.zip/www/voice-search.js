/* Channel-aware correction after system speech recognition. No audio leaves this module. */
(function(root) {
  "use strict";
  function clean(value) {
    return String(value || "").toLowerCase().normalize("NFKC")
      .replace(/^[a-z]{2,3}\s*[:|]\s*/i, "")
      .replace(/\b(?:uhd|fhd|hd|sd|4k|1080p|720p)\b/g, "")
      .replace(/[^a-z0-9\u0980-\u09ff]+/g, " ").trim().replace(/\s+/g, " ");
  }
  function key(value) { return clean(value).replace(/\s/g, ""); }
  function distance(a, b) {
    let row = Array.from({length:b.length + 1}, (_, i) => i);
    for (let i = 0; i < a.length; i++) {
      const next = [i + 1];
      for (let j = 0; j < b.length; j++)
        next.push(Math.min(next[j] + 1, row[j + 1] + 1, row[j] + (a[i] === b[j] ? 0 : 1)));
      row = next;
    }
    return row[b.length];
  }
  // Known transliterations/recognizer confusions; every correction requires a catalog hit.
  const somoy = /^(?:show my|show moi|so moy|shomoy|somoy|somai|সময়|সময়)(?:\s*(?:tv|টিভি|news|নিউজ))?$/;
  function probes(text) {
    const term = clean(text);
    const out = [term];
    if (somoy.test(term)) out.push("somoy", "shomoy", "সময়", "সময়");
    // A distinctive word can retrieve a slightly misspelled multiword channel.
    const words = term.split(" ").filter(w => w.length >= 3 && !/^(channel|news|sports|television)$/.test(w));
    out.push(...words.slice(0, 1));
    return Array.from(new Set(out.filter(Boolean)));
  }
  async function resolve(alternatives, lookup, current = () => true) {
    const spoken = Array.from(new Set((alternatives || []).filter(x => typeof x === "string" && x.trim()).map(x => x.trim()))).slice(0, 5);
    const original = spoken[0] || "";
    if (!original) return {query:"", heard:"", corrected:false};
    const entries = new Map(), seen = new Set();
    let calls = 0;
    // Check all full hypotheses first, then aliases and distinctive-word probes.
    const queries = [...spoken, ...[].concat(...spoken.map(probes))];
    for (const query of queries) {
      if (!current()) return null;
      if (!query || seen.has(query) || calls >= 8) continue;
      seen.add(query); calls++;
      const results = await lookup(query);
      if (!current()) return null;
      for (const item of (results || [])) {
        const name = typeof item === "string" ? item : item.name;
        if (name) entries.set(key(name), name.trim());
      }
      // Respect an exact match to the user's first hypothesis.
      if (entries.has(key(original))) return {query:entries.get(key(original)), heard:original, corrected:key(original) !== key(entries.get(key(original)))};
      for (const text of spoken) {
        if (entries.has(key(text))) return {query:entries.get(key(text)), heard:original, corrected:key(text) !== key(original)};
      }
      if (spoken.some(text => somoy.test(clean(text)))) {
        for (const name of entries.values()) {
          if (/^(?:somoy|shomoy|সময়|সময়)(?:\s|$)/.test(clean(name)))
            return {query:name, heard:original, corrected:key(name) !== key(original)};
        }
      }
    }
    // Only a unique close name is eligible. Ambiguous/short utterances remain unchanged.
    const ranked = [];
    for (const [candidate, name] of entries) {
      if (candidate.length > 80) continue;
      let score = Infinity;
      for (const text of spoken) {
        const needle = key(text);
        if (needle.length < 5 || needle.length > 80) continue;
        const edits = distance(needle, candidate);
        if (edits <= (needle.length >= 9 ? 2 : 1)) score = Math.min(score, edits / Math.max(needle.length, candidate.length));
      }
      if (score <= 0.2) ranked.push({name, score});
    }
    ranked.sort((a,b) => a.score - b.score);
    if (ranked.length && (ranked.length === 1 || ranked[1].score - ranked[0].score >= 0.08))
      return {query:ranked[0].name, heard:original, corrected:true};
    return {query:original, heard:original, corrected:false};
  }
  const api = {resolve, clean, probes};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.ChannelVoiceSearch = api;
})(typeof window !== "undefined" ? window : globalThis);
