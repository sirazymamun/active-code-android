/* Promise.finally is absent from Chrome 60; preserve original settlement. */
(function () {
  'use strict';
  if (!Promise.prototype.finally) {
    Object.defineProperty(Promise.prototype, 'finally', {
      configurable: true, writable: true,
      value: function (callback) {
        var C = this.constructor;
        if (typeof callback !== 'function') return this.then(callback, callback);
        return this.then(function (value) {
          return C.resolve(callback()).then(function () { return value; });
        }, function (reason) {
          return C.resolve(callback()).then(function () { throw reason; });
        });
      }
    });
  }
})();
