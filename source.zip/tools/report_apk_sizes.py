"""Report actual built APK sizes and packaged ABIs, without estimated promises."""
import pathlib, sys, zipfile

def report(folder):
    rows = []
    for apk in sorted(pathlib.Path(folder).glob('active-code-*.apk')):
        with zipfile.ZipFile(apk) as archive:
            native = [entry for entry in archive.infolist() if entry.filename.startswith('lib/') and entry.filename.endswith('.so')]
            abis = sorted({entry.filename.split('/')[1] for entry in native})
            rows.append((apk.name, apk.stat().st_size, abis, sum(entry.file_size for entry in native)))
    if not rows:
        raise RuntimeError('No built app APKs found')
    return rows

if __name__ == '__main__':
    print('Actual APK sizes (MiB = 1048576 bytes). One app APK supports both ARM32 and ARM64.\n')
    for name, size, abis, native in report(sys.argv[1]):
        print(f'{name}: {size / 1048576:.2f} MiB; ABI={",".join(abis)}; native uncompressed={native / 1048576:.2f} MiB')
