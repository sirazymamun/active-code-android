"""Run this build's smoke APKs using a disposable AVD with explicit discovery paths."""
import contextlib
import os
import pathlib
import re
import shutil
import subprocess
import sys
import time

AVD_NAME = 'active-code-test'
# Android Emulator enforces a 6 GiB userdata minimum for API 24+ images.
DATA_PARTITION_MB = 6144
DEVICE_APPEAR_TIMEOUT = 360
INSTRUMENTATION_TIMEOUT = 180
TEST_RUNNER = 'com.netcolink.activecode.test/androidx.test.runner.AndroidJUnitRunner'
TEST_CLASS = 'com.netcolink.activecode.AndroidCompatTest'

def select_emulator_apk(art):
    matches = sorted(art.glob('*-x86_64-debug.apk'))
    if len(matches) == 1:
        return matches[0]
    legacy = [p for p in art.glob('*-debug.apk')
              if not any(abi in p.name for abi in ['arm64-v8a', 'armeabi-v7a', 'x86'])]
    if not matches and len(legacy) == 1:
        return legacy[0]
    raise RuntimeError('Exactly one x86_64 debug APK is required for this emulator')


def prepare_avd_environment(art, inherited):
    """Keep SDK tools and the emulator on the same preference/AVD directories."""
    work = art.resolve().parent / 'active-code-emulator'
    preferences = work / 'user'
    avds = preferences / 'avd'
    avds.mkdir(parents=True, exist_ok=True)
    env = dict(inherited)
    # Do not let a legacy preference location override the explicit directories.
    env.pop('ANDROID_SDK_HOME', None)
    env.update(ANDROID_USER_HOME=str(preferences),
               ANDROID_EMULATOR_HOME=str(preferences), ANDROID_AVD_HOME=str(avds))
    return env, avds / (AVD_NAME + '.avd')


def register_avd(avd, env, api):
    """Write the small discovery index beside the actual, already-created AVD."""
    if not (avd / 'config.ini').is_file():
        raise RuntimeError('AVD creation did not produce config.ini at ' + str(avd))
    index = pathlib.Path(env['ANDROID_AVD_HOME']) / (AVD_NAME + '.ini')
    index.write_text('avd.ini.encoding=UTF-8\npath=' + str(avd.resolve()) +
                     '\ntarget=android-' + api + '\n', encoding='utf-8')
    return index


def configure_avd_storage(avd):
    """Keep the disposable AVD small enough for GitHub-hosted runners."""
    config = avd / 'config.ini'
    lines = config.read_text(encoding='utf-8').splitlines()
    replacements = {
        'disk.dataPartition.size': f'{DATA_PARTITION_MB}M',
        'disk.cachePartition.size': '512M',
    }
    seen = set()
    output = []
    for line in lines:
        # Recent system images write some config keys as "key = value".
        # Strip spacing so the storage override is not silently missed.
        key = line.split('=', 1)[0].strip()
        if key in replacements:
            output.append(key + '=' + replacements[key])
            seen.add(key)
        else:
            output.append(line)
    for key, value in replacements.items():
        if key not in seen:
            output.append(key + '=' + value)
    config.write_text('\n'.join(output) + '\n', encoding='utf-8')
    configured = {}
    for line in config.read_text(encoding='utf-8').splitlines():
        if '=' in line:
            key, value = line.split('=', 1)
            configured[key.strip()] = value.strip()
    for key, value in replacements.items():
        if configured.get(key) != value:
            raise RuntimeError('AVD storage override failed for ' + key)


def instrumentation_passed(output, returncode):
    """Accept a skipped old-WebView test while requiring at least one pass."""
    return returncode == 0 and bool(re.search(r'OK \([1-9]\d* tests?\)', output))


def run_instrumentation(adb, env, art, api, label, selector, attempts=2):
    """Run one required test selection and retain useful output for every try."""
    combined = []
    for attempt in range(1, attempts + 1):
        command = adb + ['shell', 'am', 'instrument', '-w', '-r', '-e',
                         'class', selector, TEST_RUNNER]
        result = subprocess.run(command, text=True, capture_output=True,
                                timeout=INSTRUMENTATION_TIMEOUT, env=env)
        output = result.stdout + ('\n' + result.stderr if result.stderr else '')
        combined.append('=== attempt ' + str(attempt) + ' ===\n' + output)
        print('Instrumentation ' + label + ' attempt ' + str(attempt) + ':', flush=True)
        print(output, flush=True)
        if instrumentation_passed(output, result.returncode):
            (art / f'instrumentation-{label}-api-{api}.txt').write_text(
                '\n'.join(combined), encoding='utf-8')
            return output
        if attempt < attempts:
            # A freshly booted API 24 image occasionally loses its first test
            # process while Package Manager/WebView finishes settling.
            subprocess.run(adb + ['shell', 'am', 'force-stop',
                                  'com.netcolink.activecode'],
                           capture_output=True, timeout=20, env=env, check=False)
            time.sleep(5)
    (art / f'instrumentation-{label}-api-{api}.txt').write_text(
        '\n'.join(combined), encoding='utf-8')
    raise RuntimeError('Android ' + label + ' instrumentation failed; full output printed above')


def parse_page_size(output):
    """Return a byte page size from getconf or /proc/self/smaps output."""
    value = output.strip()
    if re.fullmatch(r'\d+', value):
        size = int(value)
    else:
        # A process may map large pages as well. The smallest reported kernel
        # page is the base-page candidate, never an assumed 16 KB environment.
        matches = re.findall(r'^KernelPageSize:\s+(\d+)\s+kB\s*$', output,
                             flags=re.MULTILINE | re.IGNORECASE)
        if not matches:
            return None
        size = min(int(value) * 1024 for value in matches)
    if size < 4096 or size > 65536 or size & (size - 1):
        return None
    return str(size)


def detect_page_size(adb, env):
    """Detect Android page size without assuming a getconf executable exists."""
    commands = [
        adb + ['shell', 'getconf', 'PAGE_SIZE'],
        adb + ['shell', 'getconf', 'PAGESIZE'],
        adb + ['shell', 'toybox', 'getconf', 'PAGE_SIZE'],
        adb + ['shell', 'toybox', 'getconf', 'PAGESIZE'],
        adb + ['shell', 'cat', '/proc/self/smaps'],
    ]
    failures = []
    for command in commands:
        result = subprocess.run(command, text=True, capture_output=True,
                                timeout=20, env=env, check=False)
        # Android 7 cat/adb can return 255 after printing valid procfs data.
        # Only the structured smaps fallback may recover a non-zero status;
        # failed getconf output and empty/error-only smaps must still fail.
        smaps = command[-1] == '/proc/self/smaps'
        structured_smaps = smaps and bool(re.search(r'^KernelPageSize:', result.stdout,
                                                    flags=re.MULTILINE | re.IGNORECASE))
        page_size = parse_page_size(result.stdout) if result.returncode == 0 or structured_smaps else None
        if page_size:
            if result.returncode != 0:
                print('Recovered page size ' + page_size + ' from valid smaps output; '
                      'procfs command exit status was ' + str(result.returncode), flush=True)
            return page_size
        failures.append('$ ' + ' '.join(command) + '\nreturncode=' +
                        str(result.returncode) + '\n' + result.stdout + result.stderr)
    raise RuntimeError('Unable to detect emulator page size\n' + '\n'.join(failures))


def wait_for_emulator_device(adb, process, log_path, env,
                             timeout=DEVICE_APPEAR_TIMEOUT):
    """Wait for a slow first boot while noticing emulator crashes immediately."""
    deadline = time.monotonic() + timeout
    last_status = ''
    while time.monotonic() < deadline:
        if process.poll() is not None:
            print(log_path.read_text(errors='replace')[-16000:], flush=True)
            raise RuntimeError('Emulator exited before adb device appeared; boot log printed above')
        try:
            result = subprocess.run(adb + ['get-state'], text=True, capture_output=True,
                                    timeout=10, env=env, check=False)
            last_status = (result.stdout + result.stderr).strip()
            if result.returncode == 0 and result.stdout.strip() == 'device':
                return
        except subprocess.TimeoutExpired:
            last_status = 'adb get-state timed out'
        time.sleep(3)
    print(log_path.read_text(errors='replace')[-16000:], flush=True)
    raise RuntimeError('Emulator did not appear in adb within ' + str(timeout) +
                       ' seconds. Last adb status: ' + last_status)


def select_api(requested, listing):
    tag = 'google_apis_ps16k' if requested == 'latest-16k' else 'google_apis'
    if requested not in ['latest', 'latest-16k']:
        return requested, tag
    versions = re.findall(r'system-images;android-(\d+(?:\.\d+)?);' +
                          re.escape(tag) + r';x86_64', listing)
    if not versions:
        raise RuntimeError('No stable ' + tag + ' emulator image available')
    api = max(versions, key=lambda value: tuple(map(int, value.split('.'))))
    if int(api.split('.')[0]) < 36:
        raise RuntimeError('No current stable API 36+ image available')
    return api, tag


SDK_INSTALL_ATTEMPTS = 3
SDK_INSTALL_TIMEOUT = 900


def clear_failed_sdk_downloads(sdk, env):
    """Only clear installer scratch on an isolated GitHub runner, never SDK tools/images."""
    scratch = sdk / '.temp'
    if env.get('GITHUB_ACTIONS') == 'true' and scratch.is_dir() and not scratch.is_symlink():
        shutil.rmtree(scratch)


def install_sdk_package(package, sdk, env, art, label, verify_emulator=False):
    """Retry actual SDK installs; retain errors and never accept a failed download."""
    logfile = art / ('sdk-install-' + label + '.txt')
    logs = []
    for attempt in range(1, SDK_INSTALL_ATTEMPTS + 1):
        command = ['sdkmanager', '--sdk_root=' + str(sdk), '--channel=0', package]
        lines = ['=== attempt ' + str(attempt) + '/' + str(SDK_INSTALL_ATTEMPTS) + ' ===',
                 '$ ' + ' '.join(command)]
        success = False
        try:
            result = subprocess.run(command, text=True, capture_output=True,
                                    timeout=SDK_INSTALL_TIMEOUT, env=env, check=False)
            lines.extend(['returncode=' + str(result.returncode), result.stdout or '', result.stderr or ''])
            success = result.returncode == 0
            if success and verify_emulator:
                check = subprocess.run([str(sdk / 'emulator/emulator'), '-version'],
                                       text=True, capture_output=True, timeout=30, env=env, check=False)
                version = (check.stdout or '') + (check.stderr or '')
                lines.extend(['Emulator version probe: returncode=' + str(check.returncode), version])
                success = check.returncode == 0 and 'Android emulator version' in version
        except (OSError, subprocess.TimeoutExpired) as error:
            success = False
            lines.append(type(error).__name__ + ': ' + str(error))
        logs.append('\n'.join(lines))
        logfile.write_text('\n'.join(logs), encoding='utf-8')
        print(logs[-1], flush=True)
        if success:
            return
        if attempt < SDK_INSTALL_ATTEMPTS:
            clear_failed_sdk_downloads(sdk, env)
            print('SDK install failed; retrying a fresh stable-channel download in ' +
                  str(attempt * 5) + ' seconds. Full log: ' + str(logfile), flush=True)
            time.sleep(attempt * 5)
    raise RuntimeError('SDK package ' + package + ' failed after ' +
                       str(SDK_INSTALL_ATTEMPTS) + ' attempts; see ' + logfile.name)


def main(argv):
    requested, directory = argv
    art = pathlib.Path(directory).resolve()
    art.mkdir(parents=True, exist_ok=True)
    sdk_value = os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT')
    if not sdk_value:
        raise RuntimeError('ANDROID_HOME must identify the Android SDK')
    sdk = pathlib.Path(sdk_value)
    env, avd = prepare_avd_environment(art, os.environ)
    install_sdk_package('emulator', sdk, env, art, 'emulator', verify_emulator=True)
    listing = subprocess.check_output(['sdkmanager', '--list', '--channel=0'],
                                     text=True, env=env) if requested.startswith('latest') else ''
    api, tag = select_api(requested, listing)
    if requested.startswith('latest'):
        print('Latest stable ' + tag + ' emulator image available: API ' + api, flush=True)
        if int(api.split('.')[0]) < 37:
            print('::warning::API 37 image unavailable; Android 17 runtime coverage remains pending.')
    image = f'system-images;android-{api};{tag};x86_64'
    install_sdk_package(image, sdk, env, art, 'system-image-api-' + api)
    subprocess.run(['avdmanager', 'create', 'avd', '--force', '--name', AVD_NAME,
                    '--package', image, '--device', 'pixel_2', '--path', str(avd)],
                   input='no\n', text=True, check=True, env=env)
    configure_avd_storage(avd)
    index = register_avd(avd, env, api)
    emulator = str(sdk / 'emulator/emulator')
    visible = subprocess.check_output([emulator, '-list-avds'], text=True, env=env)
    diagnostics = ('AVD directory: ' + str(avd) + '\nIndex: ' + str(index) +
                   '\nVisible AVDs:\n' + visible)
    (art / f'avd-api-{api}.txt').write_text(diagnostics, encoding='utf-8')
    print(diagnostics, flush=True)
    if AVD_NAME not in visible.splitlines():
        raise RuntimeError('Created AVD is not discoverable; inspect AVD diagnostics')
    log_path = art / f'emulator-api-{api}.log'
    adb = ['adb', '-s', 'emulator-5554']
    with log_path.open('w', encoding='utf-8') as log:
        process = subprocess.Popen([emulator, '-avd', AVD_NAME, '-port', '5554',
                                    '-no-window', '-no-metrics', '-no-audio', '-no-boot-anim',
                                    '-no-snapshot', '-wipe-data', '-partition-size', str(DATA_PARTITION_MB),
                                    '-gpu', 'swiftshader_indirect',
                                    '-memory', '3072', '-cores', '2'],
                                   stdout=log, stderr=log, env=env)
        try:
            subprocess.run(['adb', 'start-server'], check=True, env=env, timeout=30)
            wait_for_emulator_device(adb, process, log_path, env)
            for attempt in range(120):
                if process.poll() is not None:
                    print(log_path.read_text(errors='replace')[-16000:], flush=True)
                    raise RuntimeError('Emulator exited; boot log printed above')
                try:
                    result = subprocess.run(adb + ['shell', 'getprop', 'sys.boot_completed'],
                                            text=True, capture_output=True, timeout=10, env=env)
                    if result.stdout.strip() == '1':
                        break
                except subprocess.TimeoutExpired:
                    pass
                time.sleep(3)
            else:
                print(log_path.read_text(errors='replace')[-16000:], flush=True)
                raise RuntimeError('Android emulator boot timed out')
            page_size = detect_page_size(adb, env)
            print('Emulator page size:', page_size, flush=True)
            if requested == 'latest-16k' and page_size != '16384':
                raise RuntimeError('16 KB test did not boot a 16 KB environment')
            subprocess.run(adb + ['shell', 'input', 'keyevent', '82'], check=True, env=env, timeout=20)
            apk = select_emulator_apk(art)
            for file in [apk, art / 'android-test.apk']:
                subprocess.run(adb + ['install', '-r', str(file)], check=True, timeout=120, env=env)
            # Native playback support is mandatory on every tested Android API.
            run_instrumentation(adb, env, art, api, 'native',
                                TEST_CLASS + '#vlcNativeLibraryLoads')
            # Keep the UI test separate so an old Android 7 WebView assumption
            # cannot hide or invalidate the mandatory native result.
            ui_output = run_instrumentation(adb, env, art, api, 'webview-ui',
                                            TEST_CLASS + '#firstRunAndCodeDialogRender')
            if any(value in ui_output for value in ['INSTRUMENTATION_STATUS_CODE: -3',
                    'INSTRUMENTATION_STATUS_CODE: -4', 'AssumptionViolatedException']):
                print('::warning::WebView UI assumption skipped; updated-WebView UI coverage remains pending.')
            print('PASS Android API', api, 'WebView UI/native library smoke tests')
        except Exception as error:
            summary = (str(error).splitlines() or [type(error).__name__])[0]
            print('::error::Android API ' + api + ' smoke test: ' +
                  summary.replace('%', '%25').replace('\r', '%0D'), flush=True)
            diagnostic = ['error=' + repr(error)]
            for args in [adb + ['get-state'], adb + ['shell', 'getprop', 'sys.boot_completed'],
                         adb + ['shell', 'toybox', 'getconf', 'PAGE_SIZE'],
                         adb + ['shell', 'dumpsys', 'webviewupdate'],
                         adb + ['logcat', '-d', '-t', '600']]:
                try:
                    probe = subprocess.run(args, text=True, capture_output=True,
                                           timeout=20, env=env, check=False)
                    diagnostic.append('$ ' + ' '.join(args))
                    diagnostic.append('returncode=' + str(probe.returncode))
                    diagnostic.append(probe.stdout + probe.stderr)
                except Exception as probe_error:
                    diagnostic.append('probe error=' + repr(probe_error))
            (art / f'failure-api-{api}.txt').write_text('\n'.join(diagnostic), encoding='utf-8')
            print('\n'.join(diagnostic), flush=True)
            raise
        finally:
            with contextlib.suppress(subprocess.SubprocessError, OSError):
                subprocess.run(adb + ['emu', 'kill'], capture_output=True, timeout=15, env=env)
            try:
                process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)


def run(argv):
    """Keep diagnostics even when SDK installation fails before an AVD exists."""
    try:
        return main(argv)
    except Exception as error:
        if len(argv) == 2:
            art = pathlib.Path(argv[1]).resolve()
            art.mkdir(parents=True, exist_ok=True)
            if not list(art.glob('failure-api-*.txt')):
                (art / ('failure-preparation-api-' + argv[0] + '.txt')).write_text(
                    'error=' + repr(error) + '\nSDK install/AVD preparation failed before smoke tests.\n',
                    encoding='utf-8')
                summary = (str(error).splitlines() or [type(error).__name__])[0]
                print('::error::Android SDK preparation: ' + summary.replace('%', '%25'), flush=True)
        raise


if __name__ == '__main__':
    run(sys.argv[1:])
