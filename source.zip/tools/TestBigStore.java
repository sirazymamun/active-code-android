import java.nio.file.*;
import java.net.URLClassLoader;
import javax.tools.ToolProvider;
import java.util.Comparator;
public class TestBigStore {
 public static void main(String[] args)throws Exception {
  Path root=Path.of("").toAbsolutePath();
  Path temp=Files.createTempDirectory("active-code-store-tests-");
  try {
   Path store=temp.resolve("BigStore.java");
   Files.writeString(store,Files.readString(root.resolve("native/java/BigStore.java.tpl")).replace("__PACKAGE__","com.tv2u.app"));
   Path detector=temp.resolve("StreamFormatDetector.java");
   Files.writeString(detector,Files.readString(root.resolve("native/java/StreamFormatDetector.java.tpl")).replace("__PACKAGE__","com.tv2u.app"));
   var compiler=ToolProvider.getSystemJavaCompiler();
   if(compiler==null)throw new IllegalStateException("A JDK is required");
   int result=compiler.run(null,System.out,System.err,"-d",temp.toString(),store.toString(),root.resolve("test/BigStorePageTest.java").toString(),root.resolve("test/BigStoreSearchTest.java").toString(),root.resolve("test/BigStoreFormatsTest.java").toString(),detector.toString(),root.resolve("test/StreamFormatTest.java").toString());
   if(result!=0)throw new IllegalStateException("Store test compilation failed");
   try(var loader=new URLClassLoader(new java.net.URL[]{temp.toUri().toURL()})) {
    for(String test:new String[]{"BigStorePageTest","BigStoreSearchTest","BigStoreFormatsTest","StreamFormatTest"})
     loader.loadClass("com.tv2u.app."+test).getMethod("main",String[].class).invoke(null,(Object)new String[0]);
   }
  } finally {
   try(var files=Files.walk(temp)){for(Path p:files.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}
  }
 }
}
