import java.nio.file.*;
import java.util.*;
import javax.tools.*;
/** Compile production field initializers in their real declaration order. */
public class TestFieldInitializers {
 static String block(String s,String marker){int a=s.indexOf(marker),j=s.indexOf('{',a)+1,d=1;for(;d>0;j++)d+=(s.charAt(j)=='{'?1:0)-(s.charAt(j)=='}'?1:0);return s.substring(a,j)+";";}
 static void compile(Path root,String name,String text,boolean expectForward)throws Exception{
  Path file=root.resolve(name+".java");Files.writeString(file,text);JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
  try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,null,null)){
   boolean ok=compiler.getTask(null,manager,diagnostics,List.of("-d",root.toString()),null,manager.getJavaFileObjects(file.toFile())).call();
   if(expectForward){if(ok||diagnostics.getDiagnostics().stream().noneMatch(d->d.getCode().equals("compiler.err.illegal.forward.ref")))throw new AssertionError("Negative control did not reproduce illegal forward reference: "+diagnostics.getDiagnostics());}
   else if(!ok)throw new AssertionError("Production field compilation failed: "+diagnostics.getDiagnostics());
  }
 }
 public static void main(String[]args)throws Exception{
  String source=Files.readString(Path.of("native/java/NativePlayerPlugin.java.tpl"));Path temp=Files.createTempDirectory("native-fields-");
  try{
   List<String> fields=new ArrayList<>(List.of("private ExoPlayer player;","private boolean playbackFailed = false;","private boolean vlcActive = false;","private boolean exoRenderedFrame = false;","private String videoMime = \"\";","private String lastError = \"\";",block(source,"private final Runnable videoStartupWatchdog")));
   for(String field:fields)if(!source.contains(field))throw new AssertionError("Production field missing: "+field);
   fields.sort(Comparator.comparingInt(source::indexOf));String declarations=String.join("\n",fields);
   String adapters="static class Player{static final int STATE_READY=3;}static class ExoPlayer{boolean getPlayWhenReady(){return true;}int getPlaybackState(){return 3;}Object getVideoFormat(){return null;}}void checkExoDeadline(){}boolean hasAccess(){return true;}boolean tryVlc(String why){return true;}void failPlayback(String why){}";
   String broken=declarations.replace("private boolean vlcActive = false;","")+"\nprivate boolean vlcActive = false;";
   compile(temp,"BrokenFieldOrderProbe","class BrokenFieldOrderProbe{"+broken+adapters+"}",true);
   compile(temp,"FieldOrderProbe","class FieldOrderProbe{"+declarations+adapters+"}",false);
   System.out.println("PASS production watchdog initializer compilation in source order; previous late vlcActive declaration reproduces illegal forward reference; corrected declarations compile (focused JVM check, not full Android compilation)");
  }finally{try(var paths=Files.walk(temp)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
 }
}
