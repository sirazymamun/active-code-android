import java.nio.file.*;import java.net.URLClassLoader;import java.util.*;import javax.tools.ToolProvider;
/** Exercise the production save/finally code with deterministic extractor/publisher failures. */
public class TestRecordingLifecycle {
 static String block(String s,String m){int a=s.indexOf(m),j=s.indexOf('{',a)+1,d=1;for(;d>0;j++)d+=(s.charAt(j)=='{'?1:0)-(s.charAt(j)=='}'?1:0);return s.substring(a,j);}
 public static void main(String[]args)throws Exception{
  Path tmp=Files.createTempDirectory("record-save-test-");try{
   String s=Files.readString(Path.of("native/java/RecordingSaver.java.tpl"));
   String h="""
import java.io.*;
public class RecordingSaveHarness {
 static int scenario,created,released;static File cache;
 static class Context{File getCacheDir(){return cache;}}
 static class MediaFormat{static final String KEY_MIME="mime";String getString(String key){return scenario==2?"audio/mpeg":"audio/mp4a-latm";}}
 static class MediaExtractor{MediaExtractor(){created++;}void setDataSource(String path)throws IOException{if(scenario==1)throw new IOException("extractor failed");}int getTrackCount(){return 1;}MediaFormat getTrackFormat(int i){return new MediaFormat();}void release(){released++;}}
 static Result keepOriginal(Context c,File f,boolean video,String base,Result r,String note){r.path="original.ts";return r;}
 static boolean mux(MediaExtractor e,File f,int v,MediaFormat vf,int a,MediaFormat af){return scenario!=4;}
 static void rawFrames(MediaExtractor e,int a,File f)throws IOException{throw new IOException("export failed");}
 static String publish(Context c,File f,String n,String mime,boolean video)throws IOException{if(scenario==3)throw new IOException("storage full");return n;}
"""+block(s,"static final class Result")+"\n"+block(s,"static Result save(")+"\n"+"""
 public static void main(String[]args)throws Exception{
  File input=File.createTempFile("record-input-",".ts");cache=new File(input.getAbsolutePath()+".work");cache.mkdirs();try{
   try(FileOutputStream out=new FileOutputStream(input)){out.write(new byte[8192]);}
   for(int mode=0;mode<=4;mode++){scenario=mode;created=released=0;Result r=save(new Context(),input,false,"saved");if(created!=1||released!=1)throw new AssertionError("extractor leaked or double released for mode "+mode+": "+created+"/"+released);if((mode==2||mode==3)&&r.error.isEmpty())throw new AssertionError("failure hidden for mode "+mode);if(mode==0&&r.path.isEmpty())throw new AssertionError("successful recording lost");}
   created=released=0;Result empty=save(new Context(),null,true,"empty");if(created!=0||empty.error.isEmpty())throw new AssertionError("empty input created extractor");
   System.out.println("PASS production recording save: extractor released exactly once on success, invalid input, extractor/export/mux/publish failures (JVM adapters, not device MediaStore)");
  }finally{input.delete();for(File f:cache.listFiles())f.delete();cache.delete();}
 }
}
""";
   Path file=tmp.resolve("RecordingSaveHarness.java");Files.writeString(file,h);if(ToolProvider.getSystemJavaCompiler().run(null,System.out,System.err,"-d",tmp.toString(),file.toString())!=0)throw new IllegalStateException("Recording save adapter compilation failed");
   try(var loader=new URLClassLoader(new java.net.URL[]{tmp.toUri().toURL()})){loader.loadClass("RecordingSaveHarness").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}
  }finally{try(var paths=Files.walk(tmp)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
 }
}
