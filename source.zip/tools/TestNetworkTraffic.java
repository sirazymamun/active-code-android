import java.nio.file.*;
import java.util.*;
import javax.tools.ToolProvider;
public class TestNetworkTraffic {
 public static void main(String[]args)throws Exception{
  Path temp=Files.createTempDirectory("active-code-network-");
  try{
   String source=Files.readString(Path.of("native/java/NativePlayerPlugin.java.tpl"));
   int a=source.indexOf("    public void getNetworkTraffic(PluginCall call) {"),b=source.indexOf("\n    }",a)+6;
   String method=source.substring(a,b);
   Map<String,String> files=Map.of(
    "android/net/TrafficStats.java","package android.net; public class TrafficStats { public static final long UNSUPPORTED=-1; public static long bytes; public static long getUidRxBytes(int uid){if(uid!=123)throw new AssertionError();return bytes;} }",
    "android/os/Process.java","package android.os; public class Process {public static int myUid(){return 123;} }",
    "android/os/SystemClock.java","package android.os; public class SystemClock {public static long elapsedRealtime(){return 12345;} }",
    "TrafficHarness.java","import java.util.*; public class TrafficHarness {static class JSObject extends HashMap<String,Object>{} static class PluginCall{JSObject value;void resolve(JSObject v){value=v;}} "+method+" public static void main(String[]a){TrafficHarness h=new TrafficHarness();PluginCall c=new PluginCall();android.net.TrafficStats.bytes=123456;h.getNetworkTraffic(c);if(!c.value.get(\"supported\").equals(true)||!c.value.get(\"receivedBytes\").equals(123456L)||!c.value.get(\"elapsedMs\").equals(12345L))throw new AssertionError();android.net.TrafficStats.bytes=-1;h.getNetworkTraffic(c);if(!c.value.get(\"supported\").equals(false))throw new AssertionError();System.out.println(\"PASS real native bridge method: own UID bytes, monotonic time, unsupported counters\");}}"
   );
   List<String> compilerArgs=new ArrayList<>(List.of("-d",temp.toString()));
   for(var e:files.entrySet()){Path f=temp.resolve(e.getKey());Files.createDirectories(f.getParent());Files.writeString(f,e.getValue());compilerArgs.add(f.toString());}
   if(ToolProvider.getSystemJavaCompiler().run(null,System.out,System.err,compilerArgs.toArray(String[]::new))!=0)throw new AssertionError("Compilation failed");
   try(var loader=new java.net.URLClassLoader(new java.net.URL[]{temp.toUri().toURL()})){loader.loadClass("TrafficHarness").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}
  }finally{try(var paths=Files.walk(temp)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
 }
}
