import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {transform} from 'esbuild';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'web-build');
// Rebuild only current www assets; removed files must not survive in the APK.
await fs.rm(out,{recursive:true,force:true});
await fs.mkdir(out,{recursive:true});
await fs.cp(path.join(root,'www'),out,{recursive:true});
for(const name of await fs.readdir(out)){
 if(!name.endsWith('.js'))continue;
 const result=await transform(await fs.readFile(path.join(out,name),'utf8'),{target:'chrome60',charset:'utf8',legalComments:'inline',sourcefile:name});
 await fs.writeFile(path.join(out,name),result.code);
}
console.log('Built Android web assets for Chrome/WebView 60+');
