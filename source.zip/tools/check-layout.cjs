/* Actual app geometry tests. Playwright is an optional verification dependency. */
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'www/index.html'),'utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'').replace(/<link\b[^>]*rel="stylesheet"[^>]*>/gi,'');
const css=fs.readFileSync(process.env.LAYOUT_CSS||path.join(root,'www/style.css'),'utf8');
const nativeTemplate=fs.readFileSync(path.join(root,'native/test/AndroidCompatTest.java.tpl'),'utf8');
const nativeProbe=JSON.parse(nativeTemplate.match(/web\.evaluateJavascript\(("(?:\\.|[^"\\])*"),v/)[1]);
(async()=>{
 const server=http.createServer((req,res)=>{if(req.url==='/logo.png'){res.setHeader('Content-Type','image/png');res.end(fs.readFileSync(path.join(root,'www/logo.png')))}else{res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html)}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;const rows=[];
 try{
  browser=await chromium.launch({headless:true,executablePath:process.env.LAYOUT_BROWSER_EXECUTABLE||undefined,args:['--no-sandbox']});
  for(const legacy of [false,true])for(const [width,height,safe=0] of [[1280,720],[1920,1080],[3840,2160],[854,480],[640,360],[360,800],[800,360],[320,568],[1280,720,1]]){
   const page=await browser.newPage({viewport:{width,height}});
   await page.route('**/*',r=>r.request().url().startsWith('http://127.0.0.1:')?r.continue():r.abort());
   await page.goto(`http://127.0.0.1:${server.address().port}/`);
   const styles=legacy?await page.evaluate(text=>{
    const unsupported=/\b(?:min|max|clamp|env)\(|\bdvh\b/;
    // Drop unsupported declarations BEFORE CSSOM parsing, which otherwise loses
    // earlier duplicate-property fallbacks when keeping a later modern value.
    const filtered=text.replace(/\/\*[\s\S]*?\*\//g,'').replace(/([a-zA-Z-]+)\s*:\s*([^;{}]+)(;|(?=}))/g,(all,name,value)=>name==='inset'||['gap','row-gap','column-gap'].includes(name)||unsupported.test(value)?'':all);
    const s=new CSSStyleSheet();s.replaceSync(filtered);
    function render(rules){return Array.from(rules).map(r=>{
     if(r.type===CSSRule.SUPPORTS_RULE){const bad=unsupported.test(r.conditionText)||/\binset\s*:/.test(r.conditionText);return (/^not\b/.test(r.conditionText)?bad:!bad)?render(r.cssRules):''}
     if(r.type===CSSRule.MEDIA_RULE)return '@media '+r.conditionText+'{'+render(r.cssRules)+'}';
     if(r.type!==CSSRule.STYLE_RULE)return r.cssText;
     if(r.selectorText.includes(':focus-visible'))return '';
     return r.selectorText+'{'+Array.from(r.style).filter(n=>n!=='inset'&&!['gap','row-gap','column-gap'].includes(n)&&!unsupported.test(r.style.getPropertyValue(n))).map(n=>n+':'+r.style.getPropertyValue(n)+(r.style.getPropertyPriority(n)?'!important':'')+';').join('')+'}';
    }).join('\n')}return render(s.cssRules);
   },css):css;
   await page.addStyleTag({content:styles});
   if(safe)await page.evaluate(()=>{for(const [edge,value] of [['top',12],['right',24],['bottom',18],['left',16]])document.documentElement.style.setProperty('--safe-area-'+edge,value+'px')});
   await page.evaluate(()=>{document.body.className='empty';document.getElementById('overlay').hidden=false;document.getElementById('btnWelcomeAdd').onclick=()=>{const d=document.getElementById('dlg');d.hidden=false;d.showModal()};});
   const nativeResult=await page.evaluate(nativeProbe);
   await page.evaluate(()=>{const d=document.getElementById('dlg');if(d.open)d.close()});
   const geometry=await page.evaluate(()=>{
    const $=id=>document.getElementById(id),rect=e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom}},g={};
    document.body.className='empty';$('overlay').hidden=false;
    g.font=parseFloat(getComputedStyle(document.documentElement).fontSize);g.app=rect($('app'));g.welcome=rect($('welcome'));g.logo=rect(document.querySelector('.welcome-logo'));
    document.documentElement.className='has-saved-activation';document.body.className='';$('overlay').hidden=true;
    g.loader=rect($('startupLoader'));g.loadingText=rect($('startupTitle'));
    document.documentElement.className='';document.body.className='channel-menu-open';$('overlay').hidden=false;
    $('groupList').innerHTML=['Live TV','Movies','Series','Sports'].map((n,i)=>`<li class="row group"><span class="name">${n}</span><span class="count-badge">${i+2}</span></li>`).join('');
    $('list').innerHTML=['Somoy TV','ATN Bangla','Example Sports'].map(n=>`<li class="row"><span class="name">${n}</span><span class="meta">Live TV</span></li>`).join('');
    for(const [name,selector] of [['groups','.groups'],['channels','.channels'],['menu','.bar'],['branding','.title img'],['categoryText','#groupList .name'],['channelText','#list .name']])g[name]=rect(document.querySelector(selector));
    $('dlg').hidden=false;$('dlg').showModal();g.activation=rect($('dlg'));$('dlg').close();
    $('searchDlg').showModal();g.search=rect($('searchDlg'));$('searchDlg').close();
    $('overlay').hidden=true;$('networkSpeed').hidden=false;$('networkSpeed').textContent='27.88 Mbps';$('audioWiz').hidden=false;$('awList').innerHTML=['Hindi','Tamil','Telugu','English','English · 6 ch'].map((n,i)=>`<li class="aw-row${i===3?' on aw-cur':''}">${n}</li>`).join('');
    g.audio=rect($('audioWiz'));g.speed=rect($('networkSpeed'));g.audioOutline=getComputedStyle($('awList').querySelector('.aw-cur')).outlineStyle;g.audioLongest=Math.max(...Array.from($('awList').children,e=>e.scrollWidth));return g;
   });
   const failures=[],check=(ok,why)=>{if(!ok)failures.push(why)},g=geometry;
   check(nativeResult==='ready','Android instrumentation probe: '+nativeResult);
   for(const name of ['app','welcome','loader'])check(Math.abs(g[name].width-width)<2&&Math.abs(g[name].height-height)<2,name+' must fill viewport');
   for(const name of ['logo','loadingText'])check(Math.abs(g[name].x+g[name].width/2-width/2)<3,name+' must be centered');
   check(g.logo.width>30&&g.logo.width<width*.75,'logo must fit');
   check(g.groups.width>=Math.min(width*.24,g.font*13)*.9&&g.groups.height>=height*.9,'category column visible');
   check(Math.abs(g.groups.x-3)<2,'category column keeps exactly 3px at the left edge');
   check(g.channels.width>=Math.min(width*.32,g.font*19)*.9&&g.channels.height>=height*.9,'channel column visible');
   check(g.categoryText.width>15&&g.channelText.width>20,'names have readable width');
   check(g.menu.x>=-1&&g.menu.right<=width+1,'menu stays onscreen');
   check(Math.abs(g.menu.right-(width-8-(safe?24:0)))<2&&Math.abs(g.menu.y-(safe?12:0))<2,'menu anchored at top right');
   const logoRight=(width<=680?14:18)+(safe?24:0),logoBottom=(width<=680?10:12)+(safe?18:0);
   check(g.branding.width>10&&g.branding.height>5&&Math.abs(g.branding.right-(width-logoRight))<2&&Math.abs(g.branding.bottom-(height-logoBottom))<2,'tv2u logo anchored at bottom right');
   for(const name of ['activation','search','audio'])check(g[name].width>60&&g[name].x>=-1&&g[name].right<=width+1&&g[name].y>=-1&&g[name].bottom<=height+1,name+' fits viewport');
   check(Math.abs(g.audio.right-width)<2,'audio wizard is flush with the right screen edge');
   check(g.audio.width<=g.audioLongest+g.font*1.1,'audio wizard width follows its text');
   check(g.audio.bottom<=g.speed.y-3,'audio wizard stays above the internet-speed footer');
   check(g.audioOutline==='none','audio stays borderless');
   rows.push({width,height,safeArea:!!safe,capabilities:legacy?'legacy CSS simulation':'modern Chromium',failures,nativeResult,geometry});
   if(process.env.LAYOUT_SCREENSHOT&&legacy&&width===1280&&!safe){
    await page.evaluate(()=>{document.getElementById('audioWiz').hidden=true;document.getElementById('overlay').hidden=false;document.body.className='channel-menu-open';document.documentElement.style.background='#000';});
    await page.screenshot({path:process.env.LAYOUT_SCREENSHOT});
   }
   await page.close();
  }
  if(process.env.LAYOUT_REPORT)fs.writeFileSync(process.env.LAYOUT_REPORT,JSON.stringify({browser:browser.version(),note:'Actual app markup/CSS in Chromium. Legacy cases simulate unsupported inset/math/env/flex-gap/selectors; not physical old Android WebView. Local playlist fixtures only.',cases:rows},null,2));
  const failed=rows.filter(r=>r.failures.length);for(const r of failed)console.error(`${r.width}x${r.height} ${r.capabilities}: ${r.failures.join('; ')}`);
  assert.equal(failed.length,0,`${failed.length}/${rows.length} cases failed`);
  console.log(`PASS ${rows.length} geometry cases: modern/legacy CSS, TV/mobile, welcome/loading/columns/menu/dialogs/audio`);
 }finally{if(browser)await browser.close();await new Promise(r=>server.close(r))}
})().catch(e=>{console.error(e);process.exitCode=1});
