import java.nio.file.*;import java.net.*;import javax.tools.ToolProvider;import java.util.*;
/** Offline integration test: Android JsonReader API is adapted to Gson only in this JVM test. */
public class TestCatalogueImport {
 public static void main(String[]args)throws Exception{
  Path root=Path.of("").toAbsolutePath(),temp=Files.createTempDirectory("catalogue-jvm-");
  Path gson=root.resolve("test/catalogue-libs/gson-2.11.0.jar"),json=root.resolve("test/catalogue-libs/json-20240303.jar");
  try{
   List<String> cmd=new ArrayList<>(List.of("-cp",gson+java.io.File.pathSeparator+json,"-d",temp.toString()));
   for(String f:List.of("BigStore","XtreamImport","XtreamSeries")){Path p=temp.resolve(f+".java");Files.writeString(p,Files.readString(root.resolve("native/java/"+f+".java.tpl")).replace("__PACKAGE__","com.tv2u.app"));cmd.add(p.toString());}
   cmd.add(root.resolve("test/vlc-stubs/android/os/SystemClock.java").toString());
   cmd.add(root.resolve("test/catalogue-stubs/android/util/JsonToken.java").toString());cmd.add(root.resolve("test/catalogue-stubs/android/util/JsonReader.java").toString());cmd.add(root.resolve("test/catalogue-stubs/com/tv2u/app/HttpFetch.java").toString());cmd.add(root.resolve("test/CatalogueImportTest.java").toString());
   if(ToolProvider.getSystemJavaCompiler().run(null,System.out,System.err,cmd.toArray(new String[0]))!=0)throw new AssertionError("Catalogue test compilation failed");
   try(var loader=new URLClassLoader(new URL[]{temp.toUri().toURL(),gson.toUri().toURL(),json.toUri().toURL()})){loader.loadClass("com.tv2u.app.CatalogueImportTest").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}
  }finally{try(var files=Files.walk(temp)){for(Path p:files.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
 }
}
