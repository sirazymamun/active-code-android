import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {parse} from 'acorn';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
for(const name of fs.readdirSync(path.join(root,'web-build'))){
 if(name.endsWith('.js'))parse(fs.readFileSync(path.join(root,'web-build',name),'utf8'),{ecmaVersion:2017,sourceType:'script'});
}
const html=fs.readFileSync(path.join(root,'web-build/index.html'),'utf8');
if(html.indexOf('./compat.js')>html.indexOf('./script.js')||!html.includes('./compat.js'))throw Error('Compatibility script must load first');
console.log('PASS compiled scripts parse as ES2017, compatibility script loads before app');

// Source escapes preserve playlist BOM handling without embedding BOM bytes in code.
for (const folder of ['www','native','web-build']) {
 const walk=dir=>{for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
  const file=path.join(dir,entry.name);
  if(entry.isDirectory())walk(file);
  else if(/\.(js|mjs|java|tpl|html|css|json|xml)$/.test(entry.name)&&fs.readFileSync(file,'utf8').includes('\uFEFF'))throw Error('Embedded BOM in '+path.relative(root,file));
 }};
 walk(path.join(root,folder));
}
console.log('PASS app source and compiled assets contain no embedded BOM characters');
