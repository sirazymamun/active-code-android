"""Build the full distribution while preserving Android stubs used by JVM tests."""
import argparse
import io
import json
import re
import pathlib
import zipfile

IGNORED_PARTS = {'node_modules', 'web-build', '__pycache__', '.git', 'build-reports'}
IGNORED_SUFFIXES = {'.pyc', '.class', '.apk', '.aab', '.jks', '.keystore'}
REQUIRED_STUBS = (
    'android/content/Context.java', 'android/net/Uri.java',
    'android/os/Handler.java', 'android/os/Looper.java', 'android/view/ViewGroup.java',
    'org/json/JSONArray.java', 'org/json/JSONObject.java',
    'org/videolan/libvlc/LibVLC.java', 'org/videolan/libvlc/Media.java',
    'org/videolan/libvlc/MediaPlayer.java', 'org/videolan/libvlc/util/VLCVideoLayout.java',
    'com/tv2u/app/VlcLifecycleTest.java',
    'android/view/View.java', 'android/os/SystemClock.java',
    'org/videolan/libvlc/interfaces/IMedia.java',
)

def include_source(relative):
    relative = pathlib.PurePath(relative)
    # Only the generated Android project at the source ROOT is excluded.
    # test/vlc-stubs/android is source code and must be shipped.
    return bool(relative.parts) and relative.parts[0] != 'android' and not (
        set(relative.parts) & IGNORED_PARTS or relative.suffix in IGNORED_SUFFIXES)

def write_source(source, destination):
    source = pathlib.Path(source)
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, strict_timestamps=False) as archive:
        for file in sorted(source.rglob('*')):
            relative = file.relative_to(source)
            if file.is_file() and include_source(relative):
                archive.write(file, relative.as_posix())

def validate_source(archive):
    required = ['test/vlc-stubs/' + name for name in REQUIRED_STUBS]
    missing = [name for name in required if name not in archive.namelist()]
    if missing:
        raise ValueError('Missing lifecycle test sources: ' + ', '.join(missing))
    if archive.testzip() is not None:
        raise ValueError('Source archive CRC check failed')

def validate_document_links(root):
    root = pathlib.Path(root)
    documents = [root / 'START_HERE_BN.txt', *root.glob('Tutorial_v*_BN.txt')]
    for folder in ('Tutorial', 'Signing', 'PlayStore'):
        documents.extend((root / folder).glob('*.txt'))
    for document in documents:
        if not document.is_file():
            raise ValueError('Missing guide: ' + str(document.relative_to(root)))
        for name in set(re.findall(r'(?:Tutorial/)?\d{2}_[A-Za-z0-9_.-]+\.txt', document.read_text(encoding='utf-8'))):
            target = root / name if name.startswith('Tutorial/') else root / 'Tutorial' / name
            if not target.is_file():
                raise ValueError(document.name + ' references missing guide: ' + name)


def validate_distribution(root):
    root = pathlib.Path(root)
    validate_document_links(root)
    version = (root / 'App/apk-version.txt').read_text().strip()
    if not re.fullmatch(r'\d{1,3}\.\d{1,2}\.\d{1,3}', version):
        raise ValueError('Invalid app version')
    source = root / 'source'
    if (source / 'apk-version.txt').read_text().strip() != version:
        raise ValueError('Source and App version mismatch')
    for name in ('package.json', 'package-lock.json'):
        data = json.loads((source / name).read_text())
        if data['version'] != version or (name == 'package-lock.json' and data['packages']['']['version'] != version):
            raise ValueError(name + ' version mismatch')
    for kind in ('debug', 'release'):
        workflow = root / ('App/.github/workflows/app-' + kind + '.yml')
        if ('active-code-v' + version) not in workflow.read_text():
            raise ValueError(kind + ' workflow label mismatch')
    schemas = list((root / 'Website').rglob('*.sql'))
    if schemas != [root / 'Website/hosting/mysql-schema.sql']:
        raise ValueError('Exactly one combined mysql-schema.sql must be shipped')
    if not (root / 'SETUP_ACCESS_KEY.txt').is_file():
        raise ValueError('Missing private setup access key file')
    hosting = root / 'Website/hosting'
    for page in hosting.glob('*.php'):
        for asset in re.findall(r'(?:src|href)="(assets/[^"<>]+)"', page.read_text()):
            if not (hosting / asset.split('?', 1)[0]).is_file():
                raise ValueError(page.name + ' references missing asset: ' + asset)


def build(root, destination):
    root = pathlib.Path(root)
    validate_distribution(root)
    source_zip = root / 'App/source.zip'
    write_source(root / 'source', source_zip)
    with zipfile.ZipFile(source_zip) as archive:
        validate_source(archive)
    folders = {'App', 'Website', 'Tutorial', 'Signing', 'PlayStore', 'Verification'}
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, strict_timestamps=False) as archive:
        for file in sorted(root.rglob('*')):
            relative = file.relative_to(root)
            if file.is_file() and relative.parts[0] in folders and not (
                    set(relative.parts) & IGNORED_PARTS or relative.suffix in IGNORED_SUFFIXES):
                archive.write(file, relative.as_posix())
        archive.write(root / 'START_HERE_BN.txt', 'START_HERE_BN.txt')
        if (root / 'SETUP_ACCESS_KEY.txt').is_file():
            archive.write(root / 'SETUP_ACCESS_KEY.txt', 'SETUP_ACCESS_KEY.txt')
        for tutorial in sorted(root.glob('Tutorial_v*_BN.txt')):
            archive.write(tutorial, tutorial.name)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError('Complete archive CRC check failed')
        with zipfile.ZipFile(io.BytesIO(archive.read('App/source.zip'))) as source:
            validate_source(source)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('package_root', type=pathlib.Path)
    parser.add_argument('output', type=pathlib.Path)
    args = parser.parse_args()
    build(args.package_root, args.output)
    print('PASS complete ZIP, nested source CRC, all 12 JVM test adapters packaged:', args.output.name)
