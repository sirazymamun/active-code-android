import java.nio.file.*;import java.net.URLClassLoader;import java.util.*;import javax.tools.ToolProvider;
public class TestPlaybackPolicy {
 static String block(String s,String m){int a=s.indexOf(m);if(a<0)throw new IllegalStateException(m);int i=s.indexOf('{',a),d=1,j=i+1;for(;d>0;j++)d+=(s.charAt(j)=='{'?1:0)-(s.charAt(j)=='}'?1:0);return s.substring(a,j);}
 static void write(Path r,String n,String s)throws Exception{Path p=r.resolve(n);Files.createDirectories(p.getParent());Files.writeString(p,s);}
 public static void main(String[]args)throws Exception{
 Path tmp=Files.createTempDirectory("restored-policy-");try{
 String s=Files.readString(Path.of("native/java/NativePlayerPlugin.java.tpl"));
 String seek=s.substring(s.indexOf("long target = Math.max(0, player.getCurrentPosition() + ms);"),s.indexOf("player.seekTo(target);"));
 seek=seek.replace("player.getCurrentPosition()","position").replace("player.getDuration()","duration");
 if(!s.contains(".setEnableDecoderFallback(false)"))throw new AssertionError("Exo still retries another decoder before VLC");
 String h="""
import java.util.*;
public class PlaybackPolicyHarness{ Object pendingFramePlay;
 static class Player{static final int STATE_READY=3;int state,prepares,seeks;boolean playWhenReady=true;boolean getPlayWhenReady(){return playWhenReady;}Object getVideoFormat(){return null;}int getPlaybackState(){return state;}void prepare(){prepares++;}void seekToDefaultPosition(){seeks++;}}
 static class PlaybackException{static final int ERROR_CODE_BEHIND_LIVE_WINDOW=1,ERROR_CODE_DECODING_FAILED=2,ERROR_CODE_DECODER_INIT_FAILED=3,ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES=4,ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED=5,ERROR_CODE_PARSING_MANIFEST_MALFORMED=6,ERROR_CODE_IO_NETWORK_CONNECTION_FAILED=7,ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT=8,ERROR_CODE_DECODING_RESOURCES_RECLAIMED=10;int errorCode;PlaybackException(int c){errorCode=c;}}
 static class Format{int width,height;Format(int w,int h){width=w;height=h;}}
 static class ExoPlaybackException extends PlaybackException{Format rendererFormat;ExoPlaybackException(int c,int w,int h){super(c);rendererFormat=new Format(w,h);}}
 static class StreamFormatDetector{static final int HLS=1,TEXT_ERROR=4,EMPTY_RESPONSE=5;int value;int kind(){return value;}static int next=-1;static int nextMode(int d,int t){return next;}}
 Player player=new Player(),exo=player;boolean playbackFailed,vlcActive,strictTracks,curUaFixed,vlcAvailable=true;int videoVariants,curSourceMode,curUaIndex,curTriedModes,status,fallbacks,failures,retries;String curUrl="test",tracksSummary="",lastError="",playbackPhase="",videoMime="";boolean exoRenderedFrame,access=true;boolean hasAccess(){return access;}int ended;static class Main{int queued;long delay;void removeCallbacks(Runnable r){queued=0;}void postDelayed(Runnable r,long ms){queued++;delay=ms;}}Main main=new Main();void emit(String s,String m){if(s.equals("ended"))ended++;}Map<String,String>curHeaders=Map.of();String[]USER_AGENTS={"one","two"};static final long STALL_MS=5000;StreamFormatDetector curStreamDetector=new StreamFormatDetector();
 String describeError(PlaybackException e){return "decode failure";}int httpStatusOf(PlaybackException e){return status;}void setStrictTracks(boolean b){strictTracks=b;}void postPlaybackRetry(Runnable r){r.run();}void startPlayback(String u,Map<String,String>h,int m,int a){retries++;curSourceMode=m;curUaIndex=a;}boolean tryVlc(String w){fallbacks++;return vlcAvailable;}void failPlayback(String m){failures++;playbackFailed=true;lastError=m;}static void check(boolean b,String w){if(!b)throw new AssertionError(w);}
"""+"static long seekTarget(long position,long duration,long ms){"+seek+"return target;}\n"+block(s,"public void onPlayerError(PlaybackException error)")+"\n"+block(s,"private final Runnable stallWatchdog")+";\n"+"private final Runnable videoStartupWatchdog=()->{};void clearExoDeadlines(){}\n"+block(s,"private void handleExoEnded(boolean vod)")+"\n"+"""
 public static void main(String[]a)throws Exception{
 PlaybackPolicyHarness stall=new PlaybackPolicyHarness();stall.stallWatchdog.run();check(stall.fallbacks==0&&stall.failures==0&&!stall.lastError.isEmpty(),"watchdog interrupted Exo");
 PlaybackPolicyHarness live=new PlaybackPolicyHarness();live.onPlayerError(new PlaybackException(1));check(live.exo.prepares==1&&live.exo.seeks==1&&live.fallbacks==0,"live-window retry");
 PlaybackPolicyHarness v=new PlaybackPolicyHarness();v.videoVariants=2;v.onPlayerError(new PlaybackException(2));check(v.exo.prepares==0&&v.fallbacks==1,"decoder failure did not hand off immediately");
 StreamFormatDetector.next=2;PlaybackPolicyHarness f=new PlaybackPolicyHarness();f.curStreamDetector.value=2;f.onPlayerError(new PlaybackException(5));check(f.retries==1&&f.curSourceMode==2&&f.fallbacks==0,"format retry");StreamFormatDetector.next=-1;
 PlaybackPolicyHarness u=new PlaybackPolicyHarness();u.status=403;u.onPlayerError(new PlaybackException(9));check(u.retries==1&&u.curUaIndex==1&&u.fallbacks==0,"UA retry");
 PlaybackPolicyHarness missing=new PlaybackPolicyHarness();missing.status=404;missing.onPlayerError(new PlaybackException(9));check(missing.failures==1&&missing.fallbacks==0,"HTTP rejection");
 PlaybackPolicyHarness dec=new PlaybackPolicyHarness();dec.onPlayerError(new PlaybackException(2));check(dec.fallbacks==1&&dec.failures==0,"VLC fallback");
 PlaybackPolicyHarness bad=new PlaybackPolicyHarness();bad.vlcAvailable=false;bad.onPlayerError(new PlaybackException(2));check(bad.failures==1,"VLC failed start");
 PlaybackPolicyHarness stale=new PlaybackPolicyHarness();stale.vlcActive=true;stale.onPlayerError(new PlaybackException(2));check(stale.fallbacks==0&&stale.failures==0,"stale Exo event");
 PlaybackPolicyHarness four=new PlaybackPolicyHarness();four.onPlayerError(new ExoPlaybackException(2,3840,2160));check(four.fallbacks==1&&four.failures==0,"4K error skipped VLC");
 PlaybackPolicyHarness hd=new PlaybackPolicyHarness();hd.onPlayerError(new ExoPlaybackException(2,1920,1080));check(hd.fallbacks==1&&hd.failures==0,"HD decoder fallback lost");
 PlaybackPolicyHarness reclaimed=new PlaybackPolicyHarness();reclaimed.onPlayerError(new ExoPlaybackException(10,4096,2160));check(reclaimed.fallbacks==1&&reclaimed.failures==0,"4K resource error skipped VLC");
 PlaybackPolicyHarness liveEnd=new PlaybackPolicyHarness();liveEnd.handleExoEnded(false);check(liveEnd.fallbacks==1&&liveEnd.ended==0,"live end bypassed VLC");
 PlaybackPolicyHarness movieEnd=new PlaybackPolicyHarness();movieEnd.handleExoEnded(true);check(movieEnd.fallbacks==0&&movieEnd.ended==1&&movieEnd.playbackPhase.equals("ExoPlayer ended"),"VOD end was retried or phase stale");
 check(seekTarget(0,500,30000)==0,"short clip produced negative seek");check(seekTarget(5000,10000,30000)==9000,"seek exceeded duration");check(seekTarget(5000,10000,-30000)==0,"backward seek became negative");
 System.out.println("PASS restored production policy: diagnostic-only watchdog; live-window/format/UA retries; immediate decoder handoff; HTTP rejection; VLC fallback; stale-event guard; 4K VLC handoff; live-end fallback; VOD completion; seek bounds");
 }
}
""";
 write(tmp,"PlaybackPolicyHarness.java",h);List<String> files=new ArrayList<>(List.of("-d",tmp.toString()));try(var paths=Files.walk(tmp)){paths.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toString()));}if(ToolProvider.getSystemJavaCompiler().run(null,System.out,System.err,files.toArray(new String[0]))!=0)throw new IllegalStateException("Policy compilation failed");try(var loader=new URLClassLoader(new java.net.URL[]{tmp.toUri().toURL()})){loader.loadClass("PlaybackPolicyHarness").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}
 }finally{try(var paths=Files.walk(tmp)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
 }
}
