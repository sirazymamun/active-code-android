import java.nio.file.*;
import java.net.URLClassLoader;
import javax.tools.ToolProvider;
import java.util.*;
/** Executes production lifecycle code against controlled Android/VLC adapters. */
public class TestVlcLifecycle {
 public static void main(String[] args)throws Exception {
  Path root=Path.of("").toAbsolutePath(),temp=Files.createTempDirectory("active-code-vlc-tests-");
  try {
   for(String required:List.of("android/content/Context.java", "android/net/Uri.java", "android/os/Handler.java", "android/os/Looper.java", "android/view/ViewGroup.java")) {
    if(!Files.isRegularFile(root.resolve("test/vlc-stubs").resolve(required)))
     throw new IllegalStateException("Incomplete source.zip: missing JVM test adapter test/vlc-stubs/"+required);
   }
   Path source=temp.resolve("VlcFallback.java");
   Files.writeString(source,Files.readString(root.resolve("native/java/VlcFallback.java.tpl")).replace("__PACKAGE__","com.tv2u.app"));
   List<String> files=new ArrayList<>(List.of("-d",temp.toString(),source.toString()));
   try(var paths=Files.walk(root.resolve("test/vlc-stubs"))){paths.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toString()));}
   int result=ToolProvider.getSystemJavaCompiler().run(null,System.out,System.err,files.toArray(new String[0]));
   if(result!=0)throw new IllegalStateException("Lifecycle test compilation failed");
   try(var loader=new URLClassLoader(new java.net.URL[]{temp.toUri().toURL()})){
    loader.loadClass("com.tv2u.app.VlcLifecycleTest").getMethod("main",String[].class).invoke(null,(Object)new String[0]);
   }
  } finally {
   try(var paths=Files.walk(temp)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}
  }
 }
}
