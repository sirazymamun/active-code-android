"""Fail closed on 64-bit ELF/page alignment regressions in APK/AAB/AAR artifacts."""
import argparse,struct,zipfile,subprocess,pathlib

def check_native(path, allow_32bit=False, expected_abi=None):
 count=0
 with zipfile.ZipFile(path) as z:
  abis={part for item in z.namelist() if item.endswith('.so') for part in item.split('/') if part in ['arm64-v8a','armeabi-v7a','x86','x86_64']}
  if expected_abi and abis!=set(expected_abi.split(',')):raise ValueError('Unexpected packaged ABIs: '+str(sorted(abis)))
  for item in z.infolist():
   is64=any('/'+abi+'/' in '/'+item.filename for abi in ['arm64-v8a','x86_64'])
   is32=any('/'+abi+'/' in '/'+item.filename for abi in ['armeabi-v7a','x86'])
   if not item.filename.endswith('.so') or not (is64 or (allow_32bit and is32)):continue
   d=z.read(item)
   if d[:4]!=b'\x7fELF' or d[4]!=(2 if is64 else 1):raise ValueError('Invalid '+('64' if is64 else '32')+'-bit ELF: '+item.filename)
   endian='<' if d[5]==1 else '>'
   offset=struct.unpack_from(endian+('Q' if is64 else 'I'),d,32 if is64 else 28)[0];size,num=struct.unpack_from(endian+'HH',d,54 if is64 else 42);loads=0
   page=16384 if is64 else 4096
   for i in range(num):
    pos=offset+i*size
    if struct.unpack_from(endian+'I',d,pos)[0]!=1:continue
    fileoff,vaddr=struct.unpack_from(endian+('QQ' if is64 else 'II'),d,pos+(8 if is64 else 4));alignment=struct.unpack_from(endian+('Q' if is64 else 'I'),d,pos+(48 if is64 else 28))[0]
    if alignment<page or (vaddr-fileoff)%page:raise ValueError('Not '+('16' if is64 else '4')+' KB ELF aligned: '+item.filename)
    loads+=1
   if not loads:raise ValueError('ELF has no loadable segments: '+item.filename)
   if str(path).endswith('.apk') and item.compress_type==zipfile.ZIP_STORED:
    with open(path,'rb') as f:
     f.seek(item.header_offset+26);name_len,extra_len=struct.unpack('<HH',f.read(4))
    if (item.header_offset+30+name_len+extra_len)%page:raise ValueError('APK native ZIP alignment is not '+('16' if is64 else '4')+' KB: '+item.filename)
   count+=1
 if count==0:raise ValueError('No 64-bit native libraries were checked')
 print('PASS',pathlib.Path(path).name,':',count,'native libraries; 64-bit uses 16 KB, 32-bit uses 4 KB alignment')
 return count
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('artifact');p.add_argument('--release',action='store_true');p.add_argument('--allow-32bit',action='store_true');p.add_argument('--expected-abi');p.add_argument('--aapt');p.add_argument('--zipalign');a=p.parse_args();check_native(a.artifact,a.allow_32bit,a.expected_abi)
 if a.artifact.endswith('.apk'):
  if a.zipalign:subprocess.run([a.zipalign,'-c','-P','4' if a.expected_abi in ['armeabi-v7a','x86'] else '16','-v','4',a.artifact],check=True,stdout=subprocess.DEVNULL)
  if a.aapt:
   info=subprocess.check_output([a.aapt,'dump','badging',a.artifact],text=True)
   assert "sdkVersion:'24'" in info and "targetSdkVersion:'36'" in info,'Unexpected SDK range'
   if a.release:assert 'application-debuggable' not in info,'Release must not be debuggable'
 if a.release and a.artifact.endswith('.aab'):
  result=subprocess.check_output(['jarsigner','-J-Duser.language=en','-verify',a.artifact],text=True)
  assert 'jar verified.' in result.lower(),'AAB is not signed/verified'
